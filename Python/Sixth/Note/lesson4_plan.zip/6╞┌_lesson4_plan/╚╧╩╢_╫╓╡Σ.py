'''
    字典：
        ditc:全称：dictionary（字典），是一种映射类型的数据
        声明方式：
            变量名 = {'key':'value'}:key,钥匙；vlaue，值
'''
#字典查询
# a = {'name':'小白','age':20,'faverate':'playing_basketball','mark':{'python':95,'static':80}}
#     # key    vlaue
# print(type(a))
# print(a['mark']['python'])
# #增加：
# a.setdefault('Is_beauty')
# a['Is_buity'] = '漂亮'
# print(a)
# #删除
# a.pop('faverate')
# print(a.popitem())#删除默认最后一个
# print(a)
# del a['faverate']
# print(a)
# a.clear()
# print(a)
# a = {'name':'小白','age':20,'faverate':'playing_basketball','mark':{'python':95,'static':80}}
# #修改：
# a['name'] = '江小白'
# print(a)
# a.update({'mark':{'python':100,'static':100}})
# print(a)