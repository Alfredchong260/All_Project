"""
实现一个应用需要有以下视图（只要能实现功能就用，不返回模板文件也可以）
    /index
    /login
    /logout
    /student/<user_id>（使用restful 风格实现增删改查）

    登录与退出用flask-login实现保护
    数据交互可以全部用接口实现
"""
from flask import Flask, request, jsonify, render_template

from flask_restful import Resource, Api
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)


class Config:
    SQLALCHEMY_DATABASE_URI = 'mysql+pymysql://root:root@127.0.0.1/python'
    SQLALCHEMY_TRACK_MODIFICATIONS = False


app.config.from_object(Config)
db = SQLAlchemy()
db.init_app(app)


class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(70), unique=True)
    password = db.Column(db.String(20))
    age = db.Column(db.Integer)


class Student(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(70), unique=True)
    chinese = db.Column(db.Integer)
    math = db.Column(db.Integer)
    english = db.Column(db.Integer)
