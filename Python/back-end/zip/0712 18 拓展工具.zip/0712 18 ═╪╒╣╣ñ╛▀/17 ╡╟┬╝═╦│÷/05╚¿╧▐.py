from flask import Flask, render_template, request, redirect, session, g

from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
# 1. 导入插件
from flask_login import LoginManager, UserMixin
from flask_login import login_user, logout_user, login_required
from flask_login import current_user
import os

app = Flask(__name__)


class Config:
    SQLALCHEMY_DATABASE_URI = r'sqlite:///data_01.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    # SQLALCHEMY_ECHO = True


app.secret_key = os.urandom(16)

app.config.from_object(Config)

db = SQLAlchemy()
migrate = Migrate()
# 2. 创建对象
login_manager = LoginManager()

db.init_app(app)
migrate.init_app(app, db)
# 3. 绑定对象
login_manager.init_app(app)
login_manager.login_view = 'login'  # 没有权限时,调转的视图


# 4. 在用户对象混入 flaks-login 提供的基类
class User(db.Model, UserMixin):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(length=20))

    def __repr__(self):
        return '<User {}>'.format(self.name)


@login_manager.user_loader
def load_user(user_id):
    return User.query.get(user_id)


@app.route('/', methods=['GET', "POST"])
def index():
    return render_template('index.html')


@app.route('/login', methods=['GET', "POST"])
def login():
    if request.method == 'GET':
        return render_template('login.html')
    if request.method == 'POST':
        username = request.json.get('username')
        user = User.query.filter(User.name == username).first()
        login_user(user)
        _next = request.args.get('next', '/home')
        return {'success': True, 'next': _next}


@app.route('/home')
# @login_required
def home():
    return render_template('home.html')


@app.route('/admin')
@login_required
def admin():
    return 'admin '


@app.route('/dash')
@login_required
def dash():
    return 'dash '


@app.route('/logout')
def logout():
    session['username'] = ''
    logout_user()
    return redirect('/')


@app.cli.command()
def rel():
    db.drop_all()
    db.create_all()

    user = User()
    user.name = 'zhengxin'
    db.session.add(user)
    db.session.commit()
