""""""
import functools
from flask import Flask, render_template, request, redirect, session, g

from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
import os

app = Flask(__name__)


class Config:
    SQLALCHEMY_DATABASE_URI = r'sqlite:///data_01.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    # SQLALCHEMY_ECHO = True


app.secret_key = os.urandom(16)

app.config.from_object(Config)

db = SQLAlchemy()
migrate = Migrate()

db.init_app(app)
migrate.init_app(app, db)


class User(db.Model):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(length=20))

    def __repr__(self):
        return '<User {}>'.format(self.name)


@app.route('/', methods=['GET', "POST"])
def index():
    return render_template('index.html')


@app.route('/login', methods=['GET', "POST"])
def login():
    if request.method == 'GET':
        return render_template('login.html')
    if request.method == 'POST':
        # {"username":"admin","password":"123456"}
        username = request.json.get('username')
        password = request.json.get('password')
        # 在用户登录之后,必须将用户的登录状态记录下来
        session['username'] = username
        return {'success': True, 'next': '/home'}


def login_permission(func):
    @functools.wraps(func)  # flask 的装饰器必须打一个缓存装饰器
    def wrapper(*args, **kwargs):
        # 手写装饰器里面是获取名字,然后查询用户绑定到 g 变量给模板
        username = session.get('username')
        print(username)
        g.user = User.query.filter(User.name == username).first()
        print(g.user)
        if not username:
            return '权限不够,不能访问后台页面(403 html)'
        result = func(*args, **kwargs)
        return result

    return wrapper


@app.route('/home')
@login_permission
def home():
    return render_template('home.html')


@app.route('/logout')
@login_permission
def logout():
    session['username'] = ''
    return redirect('/')


"""
不要界面敲 1
    可以把原理讲的更快,但是需要有一定的理解能力
要界面敲   2
    单纯只有逻辑,没有效果
"""


@app.cli.command()
def rel():
    db.drop_all()
    db.create_all()

    user = User()
    user.name = 'zhengxin'
    db.session.add(user)
    db.session.commit()
