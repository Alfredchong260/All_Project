from functools import wraps
from flask import abort
from flask_login import current_user
from models import Permission


# 权限装饰器
def permission_required(permission):
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if not current_user.can_permissions(permission):
                abort(403)
            return f(*args, **kwargs)

        return decorated_function

    return decorator


# 基于用户角色的权限装饰器
def role_required(role):
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if not current_user.can_role(role):
                abort(403)
            return f(*args, **kwargs)

        return decorated_function

    return decorator


def admin_required(f):
    return permission_required(Permission.ADMINISTER)(f)


"""
    权鉴系统: 基于列表的权限管理系列, 基于用户角色的权限管理系统 , ......
    基于列表的权限管理系统(权限表):  
        /blog           所有人都可以访问
        /user           会员才能访问
        /admin          管理层才能访问
        /admin/dev      开发的管理层
        /admin/test     测试的管理层
        /admin/font     前端的管理层才能访问
        
    用户(user):  外包人员/普通职员/管理层/股东
        正心     
        
        丸子

    角色(role):  
        普通用户  --> /blog 
        会员用户  --> /blog /user 
        管理人员  --> /admin
        开发&测试 --> /admin /admin/dev /admin/test
        
        新角色    
        
每一次更新权限的时候,最好是退出&重新登录一下 --> 才会更新 session 里面的权限

vip 需要用到,但是又不好将的知识点  用的比较少,特别难
"""
