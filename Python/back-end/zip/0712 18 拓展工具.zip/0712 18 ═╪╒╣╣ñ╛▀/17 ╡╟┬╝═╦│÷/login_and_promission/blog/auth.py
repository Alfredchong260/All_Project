from flask import Blueprint, render_template
from auth_decorator import permission_required, role_required
from utils import Permission

auth_bp = Blueprint('auth', __name__, url_prefix='/auth')


@auth_bp.route('/read')
@permission_required(Permission.READ)
def read():
    return render_template('auth/read.html')


@auth_bp.route('/commit')
@permission_required(Permission.COMMENT)
def commit():
    return render_template('auth/commit.html')


@auth_bp.route('/write')
@role_required('user')
def write():
    return render_template('auth/write.html')
