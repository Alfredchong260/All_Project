from flask_login import UserMixin
from extention import db
from utils import Permission


class Config:
    # 数据库链接配置参数
    SQLALCHEMY_DATABASE_URI = 'sqlite:///data.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False


class Role(db.Model):
    __tablename__ = 'roles'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(64), unique=True)
    default = db.Column(db.Boolean, default=False, index=True)
    permissions = db.Column(db.Integer)
    users = db.relationship('User', backref='role')

    def __repr__(self):
        return '<Role %r>' % self.name


class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(128))
    avatar_hash = db.Column(db.String(32))

    # 权限控制
    permissions = db.Column(db.Integer, default=0x07)
    # 角色控制
    role_id = db.Column(db.Integer, db.ForeignKey('roles.id'))

    # 创建的新用户默认是用户权限
    def __init__(self, **kwargs):
        super(User, self).__init__(**kwargs)
        self.role = Role.query.filter_by(default=True).first()
        self.permissions = self.role.permissions

    def __repr__(self):
        return '<User %r>' % self.username

    # 权限验证
    def can_permissions(self, permissions):
        return (self.permissions & permissions) == permissions

    # 角色验证
    def can_role(self, role):
        return self.role is not None and (self.role_id == Role.query.filter_by(name=role).first().id)
