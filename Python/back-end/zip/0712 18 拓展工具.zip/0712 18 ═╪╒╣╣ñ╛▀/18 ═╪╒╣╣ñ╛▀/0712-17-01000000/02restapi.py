from flask import Flask, request, jsonify, render_template
from flask.views import MethodView

from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)


class Config:
    SQLALCHEMY_DATABASE_URI = r'sqlite:///data_01.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False


app.secret_key = '123465'
app.config.from_object(Config)
db = SQLAlchemy()
db.init_app(app)


class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(70), unique=True)
    password = db.Column(db.String(20))
    age = db.Column(db.Integer)


#
# @app.route('/student', methods=['POST'])
# def student_add():
#     username = request.json.get('username')
#     password = request.json.get('password')
#     user = User()
#     user.name = username
#     user.password = password
#     db.session.add(user)
#     db.session.commit()
#     return {'status': 'success', 'message': '修改成功'}
#
#
# @app.route('/student/<int:user_id>', methods=['GET', "PUT", "DELETE"])
# def student_view(user_id):
#     user = User.query.get(user_id)
#     if request.method == 'GET':
#         return {
#             'status': 'success',
#             'message': '获取数据成功',
#             'data': {
#                 'user_id': user.id,
#                 'username': user.name,
#                 'password': user.password,
#             }
#         }
#     if request.method == 'PUT':
#         username = request.json.get('username')
#         password = request.json.get('password')
#         user.name = username
#         user.password = password
#         db.session.commit()
#         return {'status': 'success', 'message': '修改成功'}
#     if request.method == 'DELETE':
#         db.session.delete(user)
#         db.session.commit()
#         return {'status': 'success', 'message': '删除数据成功'}
class UserAPI(MethodView):

    def get(self, user_id):
        if user_id is None:
            # 返回一个包含所有用户的列表
            users = User.query.all()
            return {
                'status': 'success',
                'message': '获取数据成功',
                'data': [{
                    'user_id': user.id,
                    'username': user.name,
                    'password': user.password,
                } for user in users]
            }
        else:
            user = User.query.get(user_id)
            return {
                'status': 'success',
                'message': '获取数据成功',
                'data': {
                    'user_id': user.id,
                    'username': user.name,
                    'password': user.password,
                }
            }

    def post(self):
        username = request.json.get('username')
        password = request.json.get('password')
        user = User()
        user.name = username
        user.password = password
        db.session.add(user)
        db.session.commit()
        return {'status': 'success', 'message': '修改成功'}

    def delete(self, user_id):
        # 删除一个用户
        user = User.query.get(user_id)
        db.session.delete(user)
        db.session.commit()
        return {'status': 'success', 'message': '删除数据成功'}

    def put(self, user_id):
        user = User.query.get(user_id)
        username = request.json.get('username')
        password = request.json.get('password')
        user.name = username
        user.password = password
        db.session.commit()
        return {'status': 'success', 'message': '修改成功'}


user_view = UserAPI.as_view('user_api')
app.add_url_rule('/users/', defaults={'user_id': None},
                 view_func=user_view, methods=['GET', ])
app.add_url_rule('/users/', view_func=user_view, methods=['POST', ])
app.add_url_rule('/users/<int:user_id>', view_func=user_view,
                 methods=['GET', 'PUT', 'DELETE'])


@app.cli.command()
def create():
    db.drop_all()
    db.create_all()
