"""
实现一个应用需要有以下视图（只要能实现功能就用，不返回模板文件也可以）
    /index
    /login
    /logout
    /student/<user_id>（使用restful 风格实现增删改查）

    登录与退出用 flask-login 实现保护
    数据交互可以全部用接口实现
"""
from flask import Flask, request, jsonify, render_template

from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user

app = Flask(__name__)


class Config:
    SQLALCHEMY_DATABASE_URI = r'sqlite:///data_01.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False


app.secret_key = '123465'
app.config.from_object(Config)
db = SQLAlchemy()
login_manager = LoginManager()
db.init_app(app)
login_manager.init_app(app)


@login_manager.user_loader
def load_user(user_id):
    return User.query.get(user_id)


class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(70), unique=True)
    password = db.Column(db.String(20))
    age = db.Column(db.Integer)


class Student(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(70), unique=True)
    chinese = db.Column(db.Integer)
    math = db.Column(db.Integer)
    english = db.Column(db.Integer)


@app.route('/')
def index():
    return 'hello index !'


#     /login
#     /logout
@app.route('/login', methods=['POST'])
def logon():
    username = request.json.get('username')
    password = request.json.get('password')
    user = User.query.filter(User.name == username).first()
    print(username, password)
    login_user(user)
    return {'status': 'success', 'message': '请求成功'}


@app.route('/logout')
def logout():
    logout_user()
    return {'status': 'success', 'message': '退出成功'}


@app.route('/student', methods=['POST'])
def student_add():
    username = request.json.get('username')
    password = request.json.get('password')
    user = User()
    user.name = username
    user.password = password
    db.session.add(user)
    db.session.commit()
    return {'status': 'success', 'message': '修改成功'}


@app.route('/student/<int:user_id>', methods=['GET', "PUT", "DELETE"])
def student_view(user_id):
    user = User.query.get(user_id)
    if request.method == 'GET':
        return {
            'status': 'success',
            'message': '获取数据成功',
            'data': {
                'user_id': user.id,
                'username': user.name,
                'password': user.password,
            }
        }
    if request.method == 'PUT':
        username = request.json.get('username')
        password = request.json.get('password')
        user.name = username
        user.password = password
        db.session.commit()
        return {'status': 'success', 'message': '修改成功'}
    if request.method == 'DELETE':
        db.session.delete(user)
        db.session.commit()
        return {'status': 'success', 'message': '删除数据成功'}


@app.cli.command()
def create():
    db.create_all()
