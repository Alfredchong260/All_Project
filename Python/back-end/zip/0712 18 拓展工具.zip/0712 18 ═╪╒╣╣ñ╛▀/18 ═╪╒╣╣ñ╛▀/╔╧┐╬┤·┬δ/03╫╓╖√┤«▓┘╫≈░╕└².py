import time

import redis

r = redis.Redis(
    host="localhost",
    port=6379,
    db=0,
    decode_responses=True  # 读取数据的时候自动进行解码
)

# 观看（view），点赞（click），投币（coin），转发（share）
r.set('article:000001:click', 1)
r.set('article:000002:click', 1)
r.set('article:000003:click', 1)
r.set('article:000004:click', 1)

r.incr('article:000002:click')
print(r.get('article:000002:click'))
print(r.mget(['article:000001:click',
              'article:000002:click',
              'article:000003:click',
              'article:000004:click', ]))
