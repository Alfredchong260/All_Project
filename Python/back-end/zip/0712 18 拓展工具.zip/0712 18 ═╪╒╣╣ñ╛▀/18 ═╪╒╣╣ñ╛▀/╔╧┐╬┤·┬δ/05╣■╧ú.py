import time

import redis

r = redis.Redis(
    host="localhost",
    port=6379,
    db=0,
    decode_responses=True  # 读取数据的时候自动进行解码
)

r.flushdb()  # 清空数据库

r.hset('user1', 'name', '正心')
r.hset('user1', 'age', '18')
r.hset('user1', 'hobby', '吃肉,喝酒')

print('hkeys("user1"):\t', r.hkeys("user1"))
print('hvals("user1"):\t', r.hvals("user1"))

print(r.hget('user1', 'name'))
print(r.hget('user1', 'hobby'))
# r.hsetnx('user1', 'code', '12346')  # 只能进行新建
