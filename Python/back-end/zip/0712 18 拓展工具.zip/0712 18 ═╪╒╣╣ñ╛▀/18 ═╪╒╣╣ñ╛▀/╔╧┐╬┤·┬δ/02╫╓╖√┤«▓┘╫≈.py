import time

import redis

r = redis.Redis(
    host="localhost",
    port=6379,
    db=0,
    decode_responses=True  # 读取数据的时候自动进行解码
)
"""基础操作"""
r.set('name', '正心')
r.set('age', '18')

print(r.get('name'))
print(r.get('age'))

"""设置过期时间"""
# # r.set('code', '123456', ex=3)
# r.set('code', '123456', px=3000)
# print(r.get('code'))
# time.sleep(3)
# print('三秒钟过去了:', r.get('code'))

"""操作数据"""
r.set('gender', '男', nx=True)  # nx 只会新建数据
print(f'gender:{r.get("gender")}')

r.set('hobby', '吃', xx=True)  # nx 只会修改
print(f'hobby:{r.get("hobby")}')

"""自增操作"""
r.set('total', 10)
r.incr('total')
r.incr('total', amount=1)  # 自增数（必须是整数）
print(r.get("total"))
