import time

import redis

r = redis.Redis(
    host="localhost",
    port=6379,
    db=0,
    decode_responses=True  # 读取数据的时候自动进行解码
)

r.flushdb()  # 清空数据库

"""列表的基本操作"""
r.rpush("arr", 11, 22, 33, 44, 55)  # 表示从右向左操作
print(r.llen('arr'))  # 列表长度
print(r.lrange('arr', 0, 3))  # 切片取出值，范围是索引号 0-3

# lpushx 当列表有内容时，没有的话就不添加
r.lpushx("arr", '00')
print(r.llen("arr"))  # 0
print(r.lrange("arr", 0, -1))  # []

"""
    redis 中的基本数据操作与 python 基本数据类型的操作是相似的。
    
"""