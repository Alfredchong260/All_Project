import time

import redis

r = redis.Redis(
    host="localhost",
    port=6379,
    db=0,
    decode_responses=True  # 读取数据的时候自动进行解码
)

r.flushdb()  # 清空数据库

r.sadd('set1', *'hello world !')
print('集合的长度：\t', r.scard('set1'))
print('集合中的成员：\t', r.smembers('set1'))
print(r.sscan("set1"))