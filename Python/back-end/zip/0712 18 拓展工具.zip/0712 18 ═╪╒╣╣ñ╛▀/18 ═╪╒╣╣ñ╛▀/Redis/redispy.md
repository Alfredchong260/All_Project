## 1. redis连接

redis提供两个类Redis和StrictRedis用于实现Redis的命令，StrictRedis用于实现大部分官方的命令，并使用官方的语法和命令，Redis是StrictRedis的子类，用于向后兼容旧版本的redis-py。

redis连接实例是线程安全的，可以直接将redis连接实例设置为一个全局变量，直接使用。如果需要另一个Redis实例（or Redis数据库）时，就需要重新创建redis连接实例来获取一个新的连接。同理，python的redis没有实现select命令。

安装redis

```
pip install redis
```

连接redis，加上decode_responses=True，写入的键值对中的value为str类型，不加这个参数写入的则为字节类型。

```python
# 导入redis模块，通过python操作redis 也可以直接在redis主机的服务端操作缓存数据库
import redis

# host是redis主机，需要redis服务端和客户端都启动 redis默认端口是6379

r = redis.Redis(
    host='127.0.0.1',
    port=6379,
    decode_responses=False,  # 默认读取是二进制的
)

print(r)
```

## 2. redis基本命令 

### 2.1 String 字符串

set(name, value, ex=None, px=None, nx=False, xx=False)

在Redis中设置值，默认，不存在则创建，存在则修改

```python
import redis

r = redis.Redis(host='127.0.0.1',port=6379,decode_responses=False,)

print(r)
# key是"name" value是"正心" 将键值对存入redis缓存
r.set('name', '正心')
r.set('age', '18')

print(r.get('name'))
print(r.get('name').decode())
```

**参数：** 

ex，过期时间（秒） 这里过期时间是3秒，3秒后p，键hobby的值就变成None

px，过期时间（豪秒） 这里过期时间是3豪秒，3毫秒后，键hobby的值就变成None

```python
"""设置过期时间 ex"""
r.set('code', '123456', ex=3)
time.sleep(1)
print(r.get('code'))
time.sleep(1)
time.sleep(1)
print(r.get('code'))
```

setex(name, value, time)
参数： time，过期时间（数字秒 或 timedelta对象）

```python
r.setex('code', '123456', 3)
```

psetex(name, time_ms, value)
参数： time_ms，过期时间（数字毫秒 或 timedelta对象）

```python
r.psetex('code', '123456', 3000)
time.sleep(3)
print(r.get('name'))  # 5000毫秒后，取值就从apple变成None
```

**参数：** 

nx，如果设置为True，则只有name不存在时，当前set操作才执行 （新建）

xx，如果设置为True，则只有name存在时，当前set操作才执行 （修改）

```python
"""操作数据"""
# 如果键 age 不存在，就添加一个新的；如果键 age 已经存在，就不进行修改

# 不存在就创建，存在就不进行修改
r.set('age', '19', nx=True)  # 不存在就会创建
print(r.get('age'))

# 如果键 gender 已经存在，就进行修改；如果键不存在，就不修改
r.set('gender', '女', xx=True)
```

setnx(name, value)
 设置值，只有name不存在时，执行设置操作（添加）

```python
r.set('gender', '男', nx=True)
r.setnx('gender', '男')
```

#### 批量操作

mset(*args, **kwargs)
 批量设置值

```python
r.mset({'name': '正心', 'age': '18'})
```

mget(keys, *args)
 批量获取 如：

```python
print(r.mget(['name', 'age', 'hobby']))  # 一次取出多个键对应的值
```



#### 自增

incr(self, name, amount=1)
 自增 name对应的值，当name不存在时，则创建name＝amount，否则，则自增。
 参数：
 amount, 自增数（必须是整数）

```python
r.set('total', 10)
r.incr('total')
r.incr('total', amount=1)  # 自增数（必须是整数）
print(r.mget("total"))
```



decr(self, name, amount=1)
自减 name对应的值，当name不存在时，则创建name＝amount，否则，则自减。
 参数：
 amount,自减数（整数)

```python
r.decr("total", amount=3) # 递减3
r.decr("total", amount=1) # 递减1
print(r.mget("total"))
```

append(key, value)
 在redis name对应的值后面追加内容
 参数：
 value, 要追加的字符串

```
r.set('name', '正心')
r.append('name', ':zhengxin')
print(r.get('name'))  # 正心:zhengxin
```

#### 案例-页面点击

假定我们对一系列页面需要记录点击次数。

例如论坛的每个帖子都要记录点击次数，而点击次数比回帖的次数的多得多。如果使用关系数据库来存储点击，可能存在大量的行级锁争用。所以，点击数的增加使用redis的INCR命令最好不过了。
当redis服务器启动时，可以从关系数据库读入点击数的初始值（例如某一篇文章被访问了1次）

```python
# 观看（view），点赞（click），投币（coin），转发（share）
r.set('article:000001:click', 1)
r.set('article:000002:click', 1)
r.set('article:000003:click', 1)
r.set('article:000004:click', 1)
```

每当有一个页面点击，则使用INCR增加点击数即可。

```python
r.incr('article:000002:click')
```

页面载入的时候则可直接获取这个值

```python
print(r.mget(['article:000001:click', 'article:000002:click', 'article:000003:click', 'article:000004:click']))
```



incrbyfloat(self, name, amount=1.0)
自增 name对应的值，当name不存在时，则创建name＝amount，否则，则自增。
 参数：
 amount,自增数（浮点型）

```
r.set("foo1", "123.0")
r.set("foo2", "221.0")
print(r.mget("foo1", "foo2"))
r.incrbyfloat("foo1", amount=2.0)
r.incrbyfloat("foo2", amount=3.0)
print(r.mget("foo1", "foo2"))
```



#### 字符串其他操作

getrange(key, start, end)
获取子序列（根据字节获取，非字符）
参数：
name，Redis 的 name
start，起始位置（字节）
end，结束位置（字节）
如： "君惜大大" ，0-3表示 "君"

```python
r.set("cn_name", "君惜大大") # 汉字
# 取索引号是0-2 前3位的字节 君 切片操作 （一个汉字3个字节 1个字母一个字节 每个字节8bit）
print(r.getrange("cn_name", 0, 2))
# 取所有的字节 君惜大大 切片操作
print(r.getrange("cn_name", 0, -1)) 
# 字母
r.set("en_name","junxi") 
# 取索引号是0-2 前3位的字节 jun 切片操作 （一个汉字3个字节 1个字母一个字节 每个字节8bit）
print(r.getrange("en_name", 0, 2))
# 取所有的字节 junxi 切片操作
print(r.getrange("en_name", 0, -1))
```

setrange(name, offset, value)
修改字符串内容，从指定字符串索引开始向后替换（新值太长时，则向后添加）
参数：
offset，字符串的索引，字节（一个汉字三个字节）
value，要设置的值

```python
r.setrange("en_name", 1, "ccc")
# jccci 原始值是junxi 从索引号是1开始替换成ccc 变成 jccci
print(r.get("en_name"))   
```

strlen(name)
返回name对应值的字节长度（一个汉字3个字节）

```python
print(r.strlen("foo"))  # 4 'goo1'的长度是4
```



###  2.2 list

增加（类似于list的append，只是这里是从左边新增加）--没有就新建

lpush(name,values)

增加（从右边增加）--没有就新建

```python
r.flushdb()  # 清空数据库

"""列表的基本操作"""
r.rpush("arr", 11, 22, 33, 44, 55)  # 表示从右向左操作
print(r.llen('arr'))  # 列表长度
print(r.lrange('arr', 0, 3))  # 切片取出值，范围是索引号 0-3
```

往已经有的name的列表的左边添加元素，没有的话无法创建

lpushx(name,value)

在name对应的list中添加元素，只有name已经存在时，值添加到列表的最左边

```python
# lpushx 当列表有内容时，没有的话就不添加
r.lpushx("arr", 00)  
print(r.llen("arr"))  # 0
print(r.lrange("arr", 0, -1))  # []
```



新增（固定索引号位置插入元素）

linsert(name, where, refvalue, value))

在name对应的列表的某一个值前或后插入一个新值

参数：

where，BEFORE或AFTER

refvalue，标杆值，即：在它前后插入数据

value，要插入的数据

```
r.linsert("arr", "before", "11", "00")  # 往列表中左边第一个出现的元素"11"前插入元素"00"
print(r.lrange('arr', 0, -1))   # 切片取出值，范围是索引号0-最后一个元素
```



修改（指定索引号进行修改）

 r.lset(name, index, value)

 对name对应的list中的某一个索引位置重新赋值

 参数：

 name，redis的name

 index，list的索引位置

 value，要设置的值

```python
r.lset("arr", 0, -11)  # 把索引号是0的元素修改成-11
print(r.lrange("arr", 0, -1))
```



删除（指定值进行删除）

 r.lrem(name, value, num)

 在name对应的list中删除指定的值

参数：

name，redis的name

value，要删除的值

num， num=0，删除列表中所有的指定值；

num=2,从前到后，删除2个； num=1,从前到后，删除左边第1个

 num=-2,从后向前，删除2个

```python
r.lrem("arr", "11", 1)  # 将列表中左边第一次出现的"11"删除
print(r.lrange("arr", 0, -1))
r.lrem("arr", "99", -1)  # 将列表中右边第一次出现的"99"删除
print(r.lrange("arr", 0, -1))
r.lrem("arr", "22", 0)  # 将列表中所有的"22"删除
print(r.lrange("arr", 0, -1))
```



删除并返回

lpop(name)

在name对应的列表的左侧获取第一个元素并在列表中移除，返回值则是第一个元素

更多：

rpop(name) 表示从右向左操作

```
print(r.lpop("arr"))  # 删除列表最左边的元素，并且返回删除的元素
print(r.lrange("arr", 0, -1))
print(r.rpop("arr"))  # 删除列表最右边的元素，并且返回删除的元素
print(r.lrange("arr", 0, -1))
```



删除索引之外的值

ltrim(name, start, end)

在name对应的列表中移除没有在start-end索引之间的值

参数：

name，redis的name

start，索引的起始位置

end，索引结束位置

```
r.ltrim("arr", 0, 2)  # 删除索引号是0-2之外的元素，值保留索引号是0-2的元素
print(r.lrange("arr", 0, -1))
```



取值（根据索引号取值）

lindex(name, index)

在name对应的列表中根据索引获取列表元素

```
print(r.lindex("arr", 0))  # 取出索引号是0的值
```



### 2.3 set

**新增** 

sadd(name,values)
name对应的集合中添加元素

```python
# 往集合中添加元素
r.sadd("set1", *'hello world !')
print('集合的长度:\t', r.scard("set1"))
print('集合中所有的成员', r.smembers("set1")) 
```



**获取元素个数** 类似于len
scard(name)
获取name对应的集合中元素个数

```python
print('集合的长度:\t', r.scard("set1"))
```



获取所有成员

smembers(name)
获取name对应的集合的所有成员

```
print('集合中所有的成员', r.smembers("set1")) 
```



获取集合中所有的成员--元组形式

sscan(name, cursor=0, match=None, count=None)

```python
print(r.sscan("set1"))
```



获取集合中所有的成员--迭代器的方式

sscan_iter(name, match=None, count=None)

同字符串的操作，用于增量迭代分批获取元素，避免内存消耗太大

```python
for i in r.sscan_iter("set1"):
    print(i)
```



**差集**
sdiff(keys, *args)
在第一个name对应的集合中且不在其他name对应的集合的元素集合

```python
r.sadd("set2", 1, 2, 3)
r.sadd("set3", 2, 3, 4)
print('set2:\t', r.smembers("set2"))
print('set3:\t', r.smembers("set3"))
print('set2 - set3:\t', r.sdiff("set2", "set3"))
print('set3 - set3:\t', r.sdiff("set3", "set2"))
```



差集--差集存在一个新的集合中
sdiffstore(dest, keys, *args)
获取第一个name对应的集合中且不在其他name对应的集合，再将其新加入到dest对应的集合中

```python
r.sdiffstore("set4", "set2", "set3")
print('set4 = set2 - set3:\t', r.smembers("set4"))
```



**交集** 
sinter(keys, *args)
获取多一个name对应集合的交集

```python
print(r.sinter("set2", "set3"))  # 取2个集合的交集
```

**交集** 交集存在一个新的集合中
sinterstore(dest, keys, *args)
获取多一个name对应集合的并集，再将其加入到dest对应的集合中

```python
r.sinterstore("set4", "set2", "set3")  # 取2个集合的交集
print(r.smembers("set4"))
```



**并集** 
 sunion(keys, *args)
 获取多个name对应的集合的并集

```python
print('set2 | set3:\t', r.sunion("set2", "set3"))
```

并集--并集存在一个新的集合
 sunionstore(dest,keys, *args)
 获取多一个name对应的集合的并集，并将结果保存到dest对应的集合中

```python
"""并集"""
r.sunionstore("set4", "set3", "set2")
print('set4 = set3 | set2', r.smembers("set4"))
```

判断是否是集合的成员 类似in
sismember(name, value)
检查value是否是name对应的集合的成员，结果为True和False

```python
print('3 in set2:\t', r.sismember("set2", 3))
print('4 in set2:\t', r.sismember("set2", 4))
```



**移动**
smove(src, dst, value)
将某个成员从一个集合中移动到另外一个集合

```python
r.smove("set2", "set3", 1)
print(r.smembers("set1"))
print(r.smembers("set2"))
```



**删除** 随机删除并且返回被删除值
spop(name)
从集合移除一个成员，并将其返回,说明一下，集合是无序的，所有是随机删除的

```python
print(r.spop("set2"))   # 这个删除的值是随机删除的，集合是无序的
print(r.smembers("set2"))
```



**删除** 指定值删除
srem(name, values)
在name对应的集合中删除某些值

```python
print(r.srem("set2", 1))   # 从集合中删除指定值 11
print(r.smembers("set2"))
```



### 2.4  Zset

Set操作，Set集合就是不允许重复的列表，本身是无序的
 有序集合，在集合的基础上，为每元素排序；元素的排序需要根据另外一个值来进行比较，
 所以，对于有序集合，每一个元素有两个值，即：值和分数，分数专门用来做排序。



**新增**

zadd(name, *args, **kwargs)
在name对应的有序集合中添加元素

```python
import redis

r = redis.Redis(host='127.0.0.1', port=6379, decode_responses=True)
r.flushdb()

print('keys(*):\t', r.keys('*'))

# 添加两个有序几个
r.zadd("z_set1", {'m1': 22, 'm2': 44})

print('集合长度:\t', r.zcard("z_set1"))

# 获取有序集合中所有元素
print('z_range:\t', r.zrange("z_set1", 0, -1))

print('获取元素，不显示分数', r.zrevrange("z_set1", 0, -1))
print('获取元素和分数,分数倒序', r.zrevrange("z_set1", 0, -1, withscores=True))
```

获取有序集合元素个数 类似于len
zcard(name)
获取name对应的有序集合元素的数量

```python
print('集合长度:\t', r.zcard("z_set1"))
```



**获取所有元素** 
r.zrange( name, start, end, desc=False, withscores=False, score_cast_func=float)
按照索引范围获取name对应的有序集合的元素
参数：
name，redis的name

start，有序集合索引起始位置（非分数）

end，有序集合索引结束位置（非分数）

desc，排序规则，默认按照分数从小到大排序

withscores，是否获取元素的分数，默认只获取元素的值

score_cast_func，对分数进行数据转换的函数



从大到小排序(同zrange，集合是从大到小排序的)

 zrevrange(name, start, end, withscores=False, score_cast_func=float)

```python
# 获取有序集合中所有元素
print('z_range:\t', r.zrange("z_set1", 0, -1))

print('获取元素，不显示分数', r.zrevrange("z_set1", 0, -1))
print('获取元素和分数,分数倒序', r.zrevrange("z_set1", 0, -1, withscores=True))
```



按照分数范围获取name对应的有序集合的元素
zrangebyscore(name, min, max, start=None, num=None, withscores=False, score_cast_func=float)

```python
for i in range(1, 30):
    element = 'n' + str(i)
    r.zadd("z_set2", {element: i})
print('z_set2:\t', r.zrevrange("z_set2", 0, -1))
print(r.zrangebyscore("z_set2", 15, 25))  # 在分数是15-25之间，取出符合条件的元素
print(r.zrangebyscore("z_set2", 12, 22, withscores=True))  # 在分数是12-22之间，取出符合条件的元素（带分数）
```



按照分数范围获取有序集合的元素并排序（默认从大到小排序）
 zrevrangebyscore(name, max, min, start=None, num=None, withscores=False, score_cast_func=float)

```python
# 在分数是22-11之间，取出符合条件的元素 按照分数倒序
print(r.zrangebyscore("z_set2", 12, 22, withscores=True)) 
```



获取所有元素--默认按照分数顺序排序
zscan(name, cursor=0, match=None, count=None, score_cast_func=float)

```python
# 在分数是22-11之间，取出符合条件的元素 按照分数倒序
print(r.zscan("z_set2"))
```



**获取索引**
zrank(name, value)
获取某个值在 name对应的有序集合中的索引（从 0 开始）
更多：
zrevrank(name, value)，从大到小排序

```python
"""获取索引"""
print(r.zrank("z_set2", "n1"))  # n1的索引号是0 这里按照分数顺序（从小到大）
print(r.zrank("z_set2", "n6"))  # n6的索引号是1

print(r.zrevrank("z_set2", "n1"))  # n1的索引号是29 这里安照分数倒序（从大到小）
```



**删除指定值** 

zrem(name, values)

删除name对应的有序集合中值是values的成员

```python
# 删除指定值
r.zrem("z_set2", "n3")  # 删除有序集合中的元素n3 删除单个
print(r.zrange("z_set2", 0, -1))
```



**范围删除** 按照索引号来删除
zremrangebyrank(name, min, max)
根据排行范围删除

```python
# 删除范围
r.zremrangebyrank("z_set3", 0, 1)  # 删除有序集合中的索引号是0, 1的元素
print(r.zrange("z_set3", 0, -1))
```



删除--根据分数范围删除
zremrangebyscore(name, min, max)
根据分数范围删除

```python
# 删除范围
r.zremrangebyrank("z_set2", 0, 1)  # 删除有序集合中的索引号是0, 1的元素
print(r.zrange("z_set2", 0, -1))

```



获取值对应的分数
zscore(name, value)
获取name对应有序集合中 value 对应的分数

```python
print(r.zscore("z_set2", "n27"))   # 获取元素n27对应的分数27
```



### 2.5 hash

**单个增加--修改**

没有就新增，有的话就修改

hset(name, key, value)

name对应的hash中设置一个键值对（不存在，则创建；否则，修改）

**参数：**
name，redis的name

key，name对应的hash中的key

value，name对应的hash中的value

注：
hsetnx(name, key, value),当name对应的hash中不存在当前key时则创建（相当于添加）

```python
import redis

r = redis.Redis(host='127.0.0.1', port=6379, decode_responses=True)
r.flushdb()
print(r.keys('*'))

"""设置属性"""
r.hset("user1", "name", "正心")
r.hset("user1", "age", 16)
r.hset("user1", "hobby", '吃肉，喝酒')
print('hkeys("user1"):\t', r.hkeys("user1"))  # 取hash中所有的key
print('hvals("user1"):\t', r.hvals("user1"))  # 取hash中所有的key

print('获取单个值：\t', r.hget("user1", "name"))  # 单个取 hash 的 key 对应的值
print('获取多个值：\t', r.hmget("user1", "age", "hobby"))  # 多个取 hash 的 key 对应的值

r.hsetnx("user1", "age", 22)  # 只能新建
print(r.hget("user1", "age"))

```



批量增加（取出）

hmset(name, mapping)

在name对应的hash中批量设置键值对

**参数：** 

name，redis的name

mapping，字典，如：{'k1':'v1', 'k2': 'v2'}

如：

```python
r.hmset("user2", {"name": "张三", "age": 19, 'hobby': '赚钱'})
```



hget(name,key)

在name对应的hash中获取根据key获取value

hmget(name, keys, *args)

在name对应的hash中获取多个key的值

**参数:**

name，reids对应的name

keys，要获取key集合，如：['k1', 'k2', 'k3']

*args，要获取的key，如：k1,k2,k3

如：

```python
print(r.hmget('user2', 'name'))  # 单个取出"user2"的value
print(r.hmget('user2', 'name', 'age'))  # 批量取出"user2"的的内容 方式 1
print(r.hmget('user2', ['name', 'age']))  # 批量取出"user2"的的内容 方式 2
```



hgetall(name)
获取name对应hash的所有键值

```python
print(r.hgetall('user2'))
```

得到所有键值对的格式 hash长度



hlen(name)
获取name对应的hash中键值对的个数

```python
print(r.hlen('user2'))
```



得到所有的keys（类似字典的取所有keys）
hkeys(name)
获取name对应的hash中所有的key的值

```python
print(r.hkeys("user2"))
```



得到所有的value（类似字典的取所有value）
hvals(name)
获取name对应的hash中所有的value的值

```python
print(r.hvals("user2"))
```



判断成员是否存在（类似字典的in）
hexists(name, key)
检查name对应的hash是否存在当前传入的key

```python
print(r.hexists("user2", "gender"))  # False 不存在
print(r.hexists("user2", "hobby"))  # True 存在
```



删除键值对
hdel(name,*keys)
将name对应的hash中指定key的键值对删除

```python
print(r.hgetall("user2"))
r.hset("user2", "hobby", "贪财")  # 修改已有的 hobby
r.hset("user2", "gender", "男")  # 新增键值对 k11
r.hdel("user2", "hobby")         # 删除一个键值对
print(r.hgetall("user2"))
```



## 3. 其他常用操作

删除
delete(*names)
根据删除redis中的任意数据类型（string、hash、list、set、有序set）

```python
r.delete("gender")  # 删除key为gender的键值对
```



检查名字是否存在
exists(name)
检测redis的name是否存在，存在就是True，False 不存在

```python
print(r.exists("zset1"))
```



模糊匹配
keys(pattern='*') 根据模型获取redis的name 更多： KEYS \* 匹配数据库中所有 key 。 KEYS h?llo 匹配 hello ， hallo 和 hxllo 等。 KEYS h*llo 匹配 hllo 和 heeeeello 等。
KEYS h[ae]llo 匹配 hello 和 hallo ，但不匹配 hillo

```python
print(r.keys("foo*"))
```



设置超时时间
expire(name ,time)
为某个redis的某个name设置超时时间

```python
r.lpush("list5", 11, 22)
r.expire("list5", time=3)
print(r.lrange("list5", 0, -1))
time.sleep(3)
print(r.lrange("list5", 0, -1))
```



重命名
rename(src, dst)
对redis的name重命名

```python
r.lpush("list5", 11, 22)
r.rename("list5", "list5-1")
```



随机获取name
randomkey()
随机获取一个redis的name（不删除）

```python
print(r.randomkey())
```



获取类型
type(name)
获取name对应值的类型

```python
print(r.type("set1"))
print(r.type("hash2"))
```



查看所有元素
scan(cursor=0, match=None, count=None)

```python
print(r.hscan("hash2"))
print(r.sscan("set3"))
print(r.zscan("zset2"))
print(r.getrange("foo1", 0, -1))
print(r.lrange("list2", 0, -1))
print(r.smembers("set3"))
print(r.zrange("zset3", 0, -1))
print(r.hgetall("hash1"))
```



查看所有元素--迭代器
scan_iter(match=None, count=None)

```python
for i in r.hscan_iter("hash1"):
    print(i)

for i in r.sscan_iter("set3"):
    print(i)

for i in r.zscan_iter("zset3"):
    print(i)
```



**其他方法** 

```python
print(r.get('name'))    # 查询key为name的值
r.delete("gender")  	# 删除key为gender的键值对
print(r.keys()) 		# 查询所有的Key
print(r.dbsize())   	# 当前redis包含多少条数据
r.save()    			# 执行"检查点"操作，将数据写回磁盘。保存时阻塞
# r.flushdb()        	# 清空r中的所有数据
```

