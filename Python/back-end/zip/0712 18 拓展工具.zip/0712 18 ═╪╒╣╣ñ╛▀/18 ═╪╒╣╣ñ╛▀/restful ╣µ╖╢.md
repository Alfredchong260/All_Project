## restful API 

### 写在前面

网络应用程序，分为前端和后端两个部分。当前的发展趋势，就是前端设备层出不穷（手机、平板、桌面电脑、其他专用设备…）。因此，必须有一种统一的机制，方便不同的前端设备与后端进行通信。这导致API构架的流行，甚至出现"APIFirst"的设计思想。RESTful API是目前比较成熟的一套互联网应用程序的API设计理论。

REST（Representational State Transfer）表述性状态转换，REST指的是一组架构约束条件和原则。 如果一个架构符合REST的约束条件和原则，我们就称它为RESTful架构。REST本身并没有创造新的技术、组件或服务，而隐藏在RESTful背后的理念就是使用Web的现有特征和能力， 更好地使用现有Web标准中的一些准则和约束。虽然REST本身受Web技术的影响很深， 但是理论上REST架构风格并不是绑定在HTTP上，只不过目前HTTP是唯一与REST相关的实例。

前后端分离的核心：后台提供数据，前端负责显示

**前提** 

RESTful API 统一约束客户端和服务器之间的接口。简化和分离系统架构，使每个模块独立！

+ 请求中使用URI定位资源
+ 用HTTP Verbs[动词]（GET、POST、PUT、DELETE）描述操作（具体表现形式）
+ 数据传递（默认）采用：`Content-Type: application/json; charset=utf-8` 

### Rest

REST即表述性状态传递（英文：Representational State Transfer，简称REST）是Roy Fielding博士在2000年他的博士论文中提出来的一种软件架构风格。它是一种针对网络应用的设计和开发方式，可以降低开发的复杂性，提高系统的可伸缩性。**REST是设计风格而不是标准。**REST通常基于使用HTTP，URI，和XML（标准通用标记语言下的一个子集）以及HTML（标准通用标记语言下的一个应用）

#### 统一接口（Uniform Interface）

统一接口约束定义客户端和服务器之间的接口。它简化了分离的结构，使各部分独立发展。

#### 无状态（Stateless）

REST要求状态要么被放入资源状态中，要么保存在客户端上。或者换句话说，服务器端不能保持除了单次请求之外的，任何与其通信的客户端的通信状态。从客户端的每个请求要包含服务器所需要的所有信息。这样做的最直接的理由就是可伸缩性—— 如果服务器需要保持客户端状态，那么大量的客户端交互会严重影响服务器的内存可用空间（footprint）。

#### 缓存（Cachable）

服务器返回信息必须被标记是否可以缓存，如果缓存，客户端可能会重用之前的信息发送请求。

#### 客户-服务器（Client-Server）

客户端无需关注数据存储，服务器端无需关注用户界面，提高了前后端可移植性。

#### 分层系统（Layered System）

客户端不关心直接连接到最终服务器还是连接到中间服务器。中间服务器可以通过启用负载平衡和提供共享缓存来提高系统可扩展性。分层系统也可以执行安全策略。

#### 支持按需代码（Code on Demand，可选）

服务器可以通过传输逻辑来临时扩展或定制客户端的功能。

### Request

#### HTTP动词

| 请求方法         | 说明     |
| ---------------- | -------- |
| GET（SELECT）    | 获取资源 |
| POST（CREATE）   | 创建资源 |
| PUT（UPDATE）    | 更新资源 |
| DELETE（DELETE） | 删除资源 |

还有三个不常用的HTTP动词。

+ DELETE（DELETE）：从服务器删除资源。
+ HEAD：获取资源的元数据。
+ OPTIONS：获取信息，关于资源的哪些属性是客户端可以改变的。

下面是一些例子。

```
GET 	/todo					：列出所有任务
POST 	/todo					：新建一个任务
GET 	/todo/ID				：获取某个指定任务的信息
PUT 	/todo/ID				：更新某个指定任务的信息（提供该任务的全部信息）
PATCH 	/todo/ID				：更新某个指定任务的信息（提供该任务的部分信息）
DELETE 	/todo/ID				：删除某个任务
GET 	/category/ID/todo		：列出某个指定类别的所有任务
DELETE 	/category/ID/todo/ID	：删除某个指定类别的指定任务
```

#### 过滤信息（Filtering）

如果记录数量很多，服务器不可能都将它们返回给用户。API应该提供参数，过滤返回结果。

下面是一些常见的参数。

```
?limit=10					：指定返回记录的数量
?offset=10					：指定返回记录的开始位置。
?page=2&per_page=100		：指定第几页，以及每页的记录数。
?sortby=name&order=asc		：指定返回结果按照哪个属性排序，以及排序顺序。
?category_type_id=1			：指定筛选条件
```

参数的设计允许存在冗余，即允许API路径和URL参数偶尔有重复。比如，GET /category/ID/todo 与 GET /todo ?category_id=ID 的含义是相同的。



### Respone

#### 状态码（Status Codes）

| 状态码                    | 说明                                                       |
| ------------------------- | ---------------------------------------------------------- |
| 200 OK                    | 服务器成功返回请求的数据                                   |
| 201 CREATED               | 新建或修改数据成功                                         |
| 202 Accepted              | 表示一个请求已经进入后台排队（异步任务）                   |
| 204 NO CONTENT            | 删除数据成功                                               |
| 400 INVALID REQUEST       | 请求有错误，服务器没有进行新建或修改数据的操作（幂等操作） |
| 401 Unauthorized          | 没有权限（令牌、用户名、密码错误）                         |
| 403 Forbidden             | 得到授权（与401错误相对），但是访问是被禁止的              |
| 404 NOT FOUND             | 请求记录不存在，服务器没有进行操作（幂等操作）             |
| 406 Not Acceptable        | 请求的格式不符合（比如用户请求JSON格式，但是只有XML格式）  |
| 500 INTERNAL SERVER ERROR | 服务器发生错误，无法判断发出的请求是否成功                 |

状态码的完全列表参见[这里](https://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html)。

#### 返回结果

针对不同操作，服务器向用户返回的结果应该符合以下规范。

```
GET 	/collection				：返回资源对象的列表（数组）
GET 	/collection/resource	：返回单个资源对象
POST 	/collection				：返回新生成的资源对象
PUT 	/collection/resource	：返回完整的资源对象
PATCH 	/collection/resource	：返回完整的资源对象
DELETE 	/collection/resource	：返回一个空文档
```

#### 格式

前后端交互字段全部使用小驼峰方式

```json
{
  "code": "200", 					// HTTP响应码(好多javascript框架并不会获取http状态码，所以包装到body中便于使用)
  "status": "success/fail/error", 	// 见下述表格
  "content/data/result": []/{}, 	// 多条记录使用JSON数组，单条记录使用JSON对象
  "message": []     				// 状态为error或fail时，对应的错误信息
}
```

**status说明** 

| 状态    | 说明                        |
| ------- | --------------------------- |
| fail    | 返回码为 500-599            |
| error   | 返回码为 400-499            |
| success | 其他状态码（1xx、2xx、3xx） |

#### 示例

##### 图表、下拉列表框

图表、下拉列表框等建议统一key-name-value形式返回，这样对于图表来说可以统一处理，无需考虑业务性，增加了其复用性！

```
GET http://localhost.com/api/dashboard/se-count/
```

```json
{
  "status": "success",
  "result": [
    {
      "key": "low",   // 前后端交互使用关键字
      "name": "低级",  // 前端显示
      "value": 540
    },
    {
      "key": "medium",
      "name": "中级",
      "value": 336
    },
    {
      "key": "high",
      "name": "高级",
      "value": 92
    }
  ],
  errorCode: "",
  message: ""
}
```

##### 多条曲线

```json
{
  "status": "success",
  "result":[
    {
      "key": "firewall",
      "name": "Firewall",
      "value": [
        {
          "key": 1508083200000,
          "name": "3:00",
          "value": 23
        },
        {
          "key": 1508094000000,
          "name": "6:00",
          "value": 43
        }
      ]
    },
    {
      "key": "vpn",
      "name": "VPN",
      "value": [
        {
          "key": 1508083200000,
          "name": "3:00",
          "value": 31
        },
        {
          "key": 1508094000000,
          "name": "6:00",
          "value": 33
        }
      ]
    }
  ]
}
```

### 参考

https://www.ruanyifeng.com/blog/2011/09/restful.html

https://blog.csdn.net/qq_41606973/article/details/86352787
