## Flask

### flask介绍

<span style="font-weight: bold;font-size: 20px;line-height: 1.4;">1. 学习Flask框架的原因</span> 

Flask 与 Django 为 Python Web 开发使用最主要的两个框架。

![flask](assets/flask.png)

Flask 诞生于2010年，是Armin ronacher（人名）用 Python 语言基于 Werkzeug 工具箱编写的轻量级Web开发框架。

Flask 本身相当于一个内核，其他几乎所有的功能都要用到扩展（邮件扩展Flask-Mail，用户认证Flask-Login，数据库Flask-SQLAlchemy），都需要用第三方的扩展来实现。比如可以用 Flask 扩展加入ORM、窗体验证工具，文件上传、身份验证等。Flask 没有默认使用的数据库，你可以选择 MySQL，也可以用 NoSQL。

其 WSGI 工具箱采用 Werkzeug（路由模块），模板引擎则使用 Jinja2。这两个也是 Flask 框架的核心。

<span style="font-weight: bold;font-size: 20px;line-height: 1.4;">3. 框架对比</span> 

<span style="font-weight: bold;font-size: 16px;line-height: 1.4;">1） 框架轻重</span> 

重量级的框架：为方便业务程序的开发，提供了丰富的工具、组件，如Django

轻量级的框架：只提供Web框架的核心功能，自由、灵活、高度定制，如Flask、Tornado

<span style="font-weight: bold;font-size: 16px;line-height: 1.4;">2）与Django对比</span> 

django 提供了：

django-admin 快速创建项目工程目录

manage.py 管理项目工程

orm模型（数据库抽象层）

admin 后台管理站点

缓存机制

文件存储系统

用户认证系统

而这些，flask都没有，都需要扩展包来提供

**flask与Django对比** 

https://www.zhihu.com/question/41564604

https://www.cnblogs.com/keyou1/p/10861212.html

<span style="font-weight: bold;font-size: 20px;line-height: 1.4;">4. 常用扩展包</span> 

扩展列表：http://flask.pocoo.org/extensions/

- Flask-SQLalchemy：操作数据库；
- Flask-script：插入脚本；
- Flask-migrate：管理迁移数据库；
- Flask-Session：Session存储方式指定；
- Flask-WTF：表单；
- Flask-Mail：邮件；
- Flask-Bable：提供国际化和本地化支持，翻译；
- Flask-Login：认证用户状态；
- Flask-OpenID：认证；
- **Flask-RESTful：开发REST API的工具；**
- Flask-Bootstrap：集成前端Twitter Bootstrap框架；
- Flask-Moment：本地化日期和时间；
- Flask-Admin：简单而可扩展的管理接口的框架

<span style="font-weight: bold;font-size: 20px;line-height: 1.4;">5. Flask文档</span> 

1. 中文文档（https://dormousehole.readthedocs.io/en/latest/）
2. 英文文档（https://flask.palletsprojects.com/en/2.1.x/）



### 虚拟环境

<span style="font-weight: bold;font-size: 20px;line-height: 1.4;"> 为什么要用虚拟环境？</span> 

在实际项目开发中，我们通常会根据自己的需求去下载各种相应的框架库，如 flask、requests 等，但是可能每个项目使用的框架库并不一样，或使用框架的版本不一样，这样需要我们根据需求不断的更新或卸载相应的库。直接怼我们的 Python 环境操作会让我们的开发环境和项目造成很多不必要的麻烦，管理也相当混乱。

**场景1：** 

+ 项目A需要 flask 框架1.0版本
+ 项目B需要 flask 的2.0版本。
+ 如果没有安装虚拟环境，那么当你使用这两个项目时，你就需要来回的卸载安装了，这样很容易就给你的项目带来莫名的错误；

**场景2：**

+ 公司之前的项目需要  Python2.7 环境下运行
+ 而你接手的项目需要在  Python3 环境中运行
+ 想想就应该知道，如果不使用虚拟环境，这这两个项目可能无法同时使用，使用  Python3 则公司之前的项目可能无法运行，反正则新项目运行有麻烦。而如果虚拟环境可以分别为这两个项目配置不同的运行环境，这样两个项目就可以同时运行。



<span style="font-weight: bold;font-size: 20px;line-height: 1.4;">  什么是虚拟环境 </span> 

在 Python 中，虚拟环境（virtual enviroment）就是隔离的  Python  解释器环境。通过创建虚拟环境，可以拥有一个独立的 Python 解释器环境。

这样做的好处是可以为每一个项目创建独立的 Python 解释器环境，因为不同 的项目常常会依赖不同版本的库或 Python 版本。

使用虚拟环境可以保持全 局 Python 解释器环境的⼲净，避免包和版本的混乱，并且可以方便地区分和记录每个项目的依赖，以便在新环境下复现依赖环境。

#### venv

Python3 自带了 venv，而且可以直接代替 Virtualenv。venv 是基于 pip 的  Python  包管理工具，它让包 安装、包依赖管理和虚拟环境管理更加方便，使用它可以实现高效的  Python  项目开发工作流。

<span style="font-weight: bold;font-size: 16px;line-height: 1.4;"> 创建虚拟环境 </span> 

首先，我们先在某个目录下（最后是根目录或者是桌面，关键是下次要用能够找得到），输入：

```
$ python -m venv XXX
```

这会为当前项目创建一个文件夹，其中包含隔离的Python解释器环 境，并且安装pip、wheel、setuptools等基本的包。

<span style="font-weight: bold;font-size: 16px;line-height: 1.4;">  激活虚拟环境 </span> 

之后只需要运行这个里面的activate文件就行。Linux下的命令如下：

```shell
$ source <XXX>/bin/activate
```

Windows的cmd下是：

```shell
C:> <XXX>/Scripts/activate.bat
```

在PowerShell下是：

```shell
PS C:> <venv>/Scripts/Activate.bat
```

但是为了避免运行不信任的脚本，PowerShell下此脚本可能被禁止。此时输入命令：

```shell
set-executionpolicy remotesigned
```

然后更改执行策略就可以了。

退出环境之前输入：

```shell
$ deactivate 
```

<span style="font-weight: bold;font-size: 16px;line-height: 1.4;">pip常用命令</span> 

- 安装软件包：`pip install 包名` 

注：这里的包名，也可以是已经下载好的whl文件或tar.gz压缩包文件路径，或者包所在的URL地址。

- 升级pip自身：`pip install --upgrade pip` 
- 查看已经通过pip安装的包：`pip list` 
- 显示当前已经通过pip安装的包及版本号：`pip freeze`，显示结果示例：

- 安装本地的安装包：`pip install 目录|文件名` 

### 安装Flask

使用flask 2.0.1版本，注意需要联网

下面使用pip install命令在我们刚刚创建的虚拟环境里安装Flask：

```
$ pip install Flask==2.1.2
```

### 集成开发环境

如果你还没有顺手的文本编辑器，那么可以尝试一下IDE（Integrated Development Enviroment，集成开发环境）。对于新手来说，IDE的强大和 完善会帮助你高效开发Flask程序，等到你熟悉了整个开发流程，可以换用 更加轻量的编辑器以避免过度依赖IDE。下面我们将介绍使用PyCharm开发 Flask程序的主要准备步骤。

**下载并安装 PyCharm** 

打开PyCharm的下载页面（http://jetbrains.com/pycharm/download/ ）， 单击你使用的操作系统选项卡，然后单击下载按钮。你可以选择试用专业版（Professional Edition），或是选择免费的社区版（Community Edition）。

![1561897311618](assets/1561897311618.png)

专业版有一个⽉的免费试用时间。如果你是学生，可以申请专业版的免费授权。专业版提供了更多针对 Flask 开发的功能，比如创建 Flask 项目模板，Jinja2语法高亮，与 Flask 命令行功能集成等。做项目开发，比较推荐使用专业版。

**步骤2 创建项目** 

安装成功后，初始界面提供了多种方式创建新项目。这里可以单 击“Open”，选择我们的 helloflask 文件夹即可。

**步骤3 设置Python解释器**

单击菜单栏中的 File→Settings 打开设置，设置项目的解释器。

### 项目启动

Flask内置了一个简单的开发服务器（由依赖包Werkzeug提供），足够 在开发和测试阶段使用。

#### 运行flask

Flask 通过依赖包 Click内置了一个CLI（Command Line Interface，命令行交互界面）系统。当我们安装Flask后，会自动添加一个flask命令脚本， 我们可以通过flask命令执行内置命令、扩展提供的命令或是我们自己定义 的命令。其中，flask run命令用来启动内置的开发服务器：

```shell
(helloflask)  $ flask run
 * Environment: production
   WARNING: This is a development server. Do not use it in a production deployment.
   Use a production WSGI server instead.
 * Debug mode: off
 * Running on http://127.0.0.1:5000/ (Press CTRL+C to quit)
```

> 确保执行命令前激活了虚拟环境（virtualenv shell）

flask run命令运行的开发服务器默认会监听 http://127.0.0.1:5000/  地址 （按Crtl+C退出），并开启多线程⽀持。当我们打开浏览器访问这个地址时，会看到⽹页上显示“Hello，flask！”，如图所示。

![1561903855414](assets/1561903855414.png)

**localhost 与 127.0.0.1** 

+ http://127.0.0.1 即 localhost ，是指向本地机的IP地址，一般用来测试。 
+ Flask默认使用5000端口，上面的地址可以使 用http://localhost:5000/ 。
+ 除了地址不同外， 两者没有实际区别，即域名和IP地址的映射关系。

#### 最小的Flask程序

```python
from flask import Flask  # ⑴

app = Flask(__name__)  # ⑵


@app.route('/')  # ⑶
def index():  # ⑷
    return 'Hello flask ！'  # ⑸


if __name__ == '__main__':
    app.run()  # ⑹

```

启动服务之后，就可以在浏览器中访问了。整个请求的处理过程如下所示：

1. 当用户在浏览器地址栏访问这个地址，在这里即 <http://127.0.0.1:5000/>
2. 服务器解析请求，发现请求 URL 匹配的 URL 规则是 `/`，因此调用对应的处理函数 `index()`
3. 获取 `index()` 函数的返回值，处理后返回给客户端（浏览器）
4. 浏览器接受响应，将其显示在窗口上

#### 代码逻辑

⑴ 首先我们从 `flask` 包导入 `Flask` 类

```python
from flask import Flask  # ⑴
```

⑵ 通过实例化这个类，创建一个程序对象 `app`：

```python
app = Flask(__name__)  # ⑵
```

⑶ 使用 `app.route()` 装饰器将函数绑定对应的 URL，当用户在浏览器访问这个 URL 的时候，就会触发这个函数，获取返回值，并把返回值显示到浏览器窗口。

⑷ 装饰器注册的处理函数，这个函数是处理某个请求的处理函数，Flask 官方把它叫做视图函数（view funciton）！你可以理解为 **请求处理函数**。

⑸ 返回响应内容

```python
# 填入 app.route() 装饰器的第一个参数是 URL 规则字符串，这里的 / 指的是根地址。
@app.route('/')  # ⑶
def index():  # ⑷
    return 'Hello flask ！'  # ⑸
```

⑹ Flask应用程序实例的 run 方法启动 WEB 服务器

```python
if __name__ == '__main__':
    app.run()  # ⑹
```



### 更多的启动选项

#### 使服务器外部可见

我们在上面启动的Web服务器默认是对外不可见的，可以在run命令后 添加--host选项将主机地址设为0.0.0.0使其对外可见：

```
$ flask run --host=0.0.0.0
```

这会让服务器监听所有外部请求。个人计算机（主机）一般没有公⽹ IP（公有地址），所以你的程序只能被局域⽹内的其他用户通过你的个人 计算机的内⽹IP（私有地址）访问，比如你的内⽹IP为192.168.191.1。当局域⽹内的其他用户访问http://192.168.191.1:5000 时，也会看到浏览器里 显示一行“Hello，Flask！”。

#### 改变默认端口

Flask提供的Web服务器默认监听5000端口，你可以在启动时传入参数来改变它：

```
$ flask run --port=8000
```

这时服务器会监听来自8000端口的请求，程序的主页地址也相应变成 了http://localhost:8000/ 。

#### 将参数保存到文件 

需要提前安装  `python-dotenv`  

```
pip install python-dotenv
```

执行 flask run 命令时的 host 和 port 选项也可以通过环境变量 FLASK_RUN_HOST 和 FLASK_RUN_PORT 设置。事实上，Flask内置的命令都可以使用这种模式定义默认选项值， 即“`FLASK_<COMMAND>_<OPTION>`”

如果想不需要每次都指定，可以内容保存到当前目录下的 <span style="color:red"> .flaskenv </span> 或者是 <span style="color:red"> .env </span> 文件中（需要安装 <span style="color:red">  python-dotenv</span> ）。

```
FLASK_ENV=development		# 设置当前开发模式
FLASK_RUN_PORT=5050			# 设置运行的端口
FLASK_RUN_HOST=0.0.0.0		# 设置监听的 ip 
FLASK_APP=app.py

production
```

源于配置参数，可以点击此链接查看 https://flask.palletsprojects.com/en/latest/cli, https://dormousehole.readthedocs.io/en/latest/cli.html

也可以使用 flask --help 命令查看所有可用的命令。 

#### 设置运行环境 

开发环境（development enviroment）和生产环境（production enviroment）是我们后面会频繁接触到的概念。开发环境是指我们在本地 编写和测试程序时的计算机环境，而生产环境与开发环境相对，它指的是 ⽹站部署上线供用户访问时的服务器环境

根据运行环境的不同，Flask程序、扩展以及其他程序会改变相应的行 为和设置。为了区分程序运行环境，Flask提供了一个FLASK_ENV环境变 量用来设置环境，默认为 production（生产）。在开发时，我们可以将其设 为development（开发），这会开启所有⽀持开发的特性。为了方便管理， 我们将把环境变量 FLASK_ENV 的值写入 `.flaskenv` 文件中：

```
FLASK_ENV=development
```

现在启动程序，你会看到下面的输出提示： 

```shell
(helloflask) $ flask run
 * Environment: development
 * Debug mode: on
 * Restarting with stat
 * Debugger is active!
 * Debugger PIN: 161-372-375
 * Running on http://127.0.0.1:5000/ (Press CTRL+C to quit)

```

### Python Shell 

本书有许多操作需要在Python Shell（即Python交互式解释器）里执 行。在开发Flask程序时，我们并不会直接使用python命令启动Python Shell，而是使用flask shell命令： 

```python
(helloflask) $ flask shell
Python 3.6.5 |Anaconda, Inc.| (default, Mar 29 2018, 13:32:41) [MSC v.1900 64 bit (AMD64)] on win32
App: app [development]
    
Instance: C:\Users\Administrator\Desktop\helloflask\instance
>>>
```

和其他 flask 命令相同，执行这个命令前我们要确保程序实例可以被正常找到。

在本书中，如果代码⽚段前的提示符为三个大于号，即“>>>”，那么就表示这些代码需要在使用flask shell命令打开的Python Shell中执行。

使用flask shell命令打开的Python Shell自动包含程序上下文，并且已经导入了app实例： 

```python
>>> app
<Flask 'app'>
>>> app.name
'app'
>>>

```

上下文（context）可以理解为环境。为了正常运行程序，一些操作相关的状态和数据需要被临时保存下来，这些状态和数据被统称为上下文。在Flask中，上下文有两种，分别为程序上下文和请求上下文，后面我们会详细了解。

## 路由与蓝图

### URL与端点（路由）

视图函数的返回值可以自由修改，返回值作为响应的主体，默认会被浏览器作为 HTML 格式解析，所以可以直接返回一个 HTML 格式的内容：

```python
@app.route('/')
def index():
    return '<h1>Hello world!</h1><img src="https://www.python.org/static/img/python-logo.png">'
```

保存修改后，只需要在浏览器里刷新页面，你就会看到页面上的内容也会随之变化。

![1560687035414](assets/1560687035414.png)

#### app.route 的参数

可以自由修改传入 `app.route` 装饰器里的 URL 规则字符串，来修改访问的网站地址，但要注意以斜线 `/` 作为开头。比如：

```python
@app.route('/home')
def home():
    return 'Welcome to flask !'
```

#### 绑定多个路由 

一个视图函数也可以绑定多个 URL，这通过附加多个装饰器实现，比如：

```python
@app.route('/index')
@app.route('/user')
def user():
    return 'Welcome to flask !'
```

现在无论是访问 

http://localhost:5000/home

http://localhost:5000/index 都可以看到返回值。

#### 接收传参

在前面，我们之所以把传入 `app.route` 装饰器的参数称为 URL 规则，是因为我们也可以在 URL 里定义变量部分。比如下面这个视图函数会处理所有类似 `/user/<name>` 的请求：

```python
@app.route('/user/<user>')
def user_page(user):
    return 'User page'
```

不论你访问 

http://localhost:5000/user/greyli

http://localhost:5000/user/peter

http://localhost:5000/user/

都会触发这个函数。通过下面的方式，我们也可以在视图函数里获取到这个变量值：

```python
@app.route('/user/<user>')
def user_page(user):
    return 'User: %s' % user

```

如何在一个在一个视图函数中如何访问另外一个视图函数？

1. 求情目标视图的 url

   缺点：一旦 url 变动就会出错

2. 根据函数名去请求 url

   优点： 函数名一般不会修改

> 将来如果修改了 `URL` ，但没有修改该 `URL` 对应的函数名，就不用到处去替换 `URL` 了。	

### URL处理（转化器）

从前面的路由列表中可以看到，除了 /hello ，这个程序还包含许多 URL 规则，比如和 send 端点对应的 /send/<phone_number > 。

现在请尝试访问 http://localhost:5000/send/phone_number ，在URL中加入一个数字用于当做路由转化器。URL 中的变量部分默认类型为字符串，但 Flask 提供了一些转换器可以在 URL 规则里使用，如表2-6所示。

>  Flask内置的URL变量转换器 

| 转换器 | 说 明                                                        |
| ------ | ------------------------------------------------------------ |
| string | 不包含斜线的字符串（默认值）                                 |
| int    | 整型                                                         |
| float  | 浮点数                                                       |
| path   | 包含斜线的字符串。static路由的URL规则中的filename变量就使用了这个转换器 |
| any    | 匹配一系列给定值中的一个元素                                 |
| uuid   | UUID字符串                                                   |

转换器通过特定的规则指定，即“<转换器：变量名>”。<int：phone_number>把 phone_number 的值转换为整数，因此我们可以在视图函数中直接对year变量进行数学计算：

```python
@app.route('/send/<int:phone_number>') 
def go_back(phone_number): 
	return '<p>信息已经发送到 %d !</p>' % phone_number

```

默认的行为不仅仅是转换变量类型，还包括URL匹配。

将上面的例子以整型匹配数据，可以如下使用：

```python
@app.route('/users/<int:user_id>')
def user_info(user_id):
    print(type(user_id))
    return 'hello user {}'.format(user_id)

```

#### 自定义转换器

如果遇到需要匹配提取 `/sms_codes/18512345678` 中的手机号数据，Flask内置的转换器就无法满足需求，此时需要自定义转换器。

**定义方法**

自定义转换器主要做3步

1. 创建转换器类，保存匹配时的正则表达式

   ```python
   from werkzeug.routing import BaseConverter
   
   class MobileConverter(BaseConverter):
       """
       手机号格式
       """
       regex = r'1[3-9]\d{9}'
   
   ```

   - 注意`regex`名字固定

2. 将自定义的转换器告知Flask应用

   ```python
   app = Flask(__name__)
   
   # 将自定义转换器添加到转换器字典中，并指定转换器使用时名字为: mobile
   app.url_map.converters['mobile'] = MobileConverter
   ```
   
3. 在使用转换器的地方定义使用

   ```python
   @app.route('/sms_codes/<mobile:mob_num>')
   def send_sms_code(mob_num):
       return 'send sms code to {}'.format(mob_num)
   ```



### 蓝图

在一个Flask 应用项目中，如果业务视图过多，可否将以某种方式划分出的业务单元单独维护，将每个单元用到的视图、静态文件、模板文件等独立分开？

例如从业务角度上，可将整个应用划分为用户模块单元、商品模块单元、订单模块单元，如何分别开发这些不同单元，并最终整合到一个项目应用中？

在Flask中，使用蓝图Blueprint来分模块组织管理。

蓝图实际可以理解为是一个存储一组视图方法的容器对象，其具有如下特点：

- 一个应用可以具有多个Blueprint
- 可以将一个Blueprint注册到任何一个未使用的URL下比如 “/user”、“/goods”
- Blueprint可以单独具有自己的模板、静态文件或者其它的通用操作方法，它并不是必须要实现应用的视图和函数的
- 在一个应用初始化时，就应该要注册需要使用的Blueprint

但是一个Blueprint并不是一个完整的应用，它不能独立于应用运行，而必须要注册到某一个应用中。

#### 使用方式

使用蓝图可以分为三个步骤

1. 创建一个蓝图对象

   ```python
   auth_bp = Blueprint('auth', __name__)
   ```
   
2. 在这个蓝图对象上进行操作,注册路由,指定静态文件夹,注册模版过滤器

   ```python
   @auth_bp.route('/login')
   def login():
       return 'user_login'
   ```
   
3. 在应用对象上注册这个蓝图对象

   ```python
   app.register_blueprint(auth_bp)
   ```

#### 单文件蓝图

可以将创建蓝图对象与定义视图放到一个文件中 。

**目录（包）蓝图** 

对于一个打算包含多个文件的蓝图，通常将创建蓝图对象放到Python包的`__init__.py`文件中

```shell
--- project # 工程目录
  |------ main.py # 启动文件
  |------ auth  #用户蓝图
  |  |--- __init__.py  # 此处创建蓝图对象
  |  |--- passport.py  
  |  |--- profile.py
  |  |--- ...
  |
  |------ goods # 商品蓝图
  |  |--- __init__.py
  |  |--- ...
  |...

```

#### 扩展用法

##### 1 指定蓝图的url前缀

在应用中注册蓝图时使用`url_prefix`参数指定

```python
admin_bp = Blueprint('admin', __name__)


@admin_bp.route('/user')
def user_profile():
    return '用户后台页面'


# 给路由添加前缀
app.register_blueprint(admin_bp, url_prefix='/admin')

```

##### 2 蓝图内部静态文件

和应用对象不同，蓝图对象创建时不会默认注册静态目录的路由。需要我们在创建时指定 static_folder 参数。

下面的示例将蓝图所在目录下的static_admin目录设置为静态目录

```python
admin_bp = Blueprint("admin", __name__, static_folder='static_admin')
app.register_blueprint(admin_bp, url_prefix='/admin')

```

现在就可以使用`/admin/static_admin/`访问`static_admin`目录下的静态文件了。

也可通过`static_url_path`改变访问路径

```python
admin = Blueprint("admin", __name__, static_folder='static_admin', static_url_path='/lib')
app.register_blueprint(admin,url_prefix='/admin')

```

##### 3 蓝图内部模板目录

蓝图对象默认的模板目录为系统的模版目录，可以在创建蓝图对象时使用 template_folder 关键字参数设置模板目录

```python
admin_bp = Blueprint('admin', __name__, template_folder='my_templates')
```

URL是指向⽹络上资源的地址。在Flask中，我们需要让请求的URL匹配对应的视图函数，视图函数返回值就是URL对应的资源。 

##### 路由匹配

为了便于将请求分发到对应的视图函数，程序实例中存储了一个路由表（app.url_map），其中定义了URL规则和视图函数的映射关系。当请求发来后，Flask会根据请求报文中的URL（path部分）来尝试与这个表中的 所有URL规则进行匹配，调用匹配成功的视图函数。如果没有找到匹配的 URL规则，Flask会自动返回 404错误响应（Not Found，表示资源未找到）。 



使用flask routes命令可以查看程序中定义的所有路由，这 个列表由app.url_map解析得到：

```
(helloflask)  C:\Users\Administrator\Desktop\helloflask>flask routes
Endpoint  Methods  Rule
--------  -------  -----------------------
index     GET      /
static    GET      /static/<path:filename>

```

在输出的文本中，我们可以看到每个路由对应的端点（Endpoint）、 HTTP方法（Methods）和URL规则（Rule），其中static端点是Flask添加的 特殊路由，用来访问静态文件。

### 静态文件配置

一个完整的⽹站当然不能只返回用户一句“Hello，World！”，我们需要模板（template）和静态文件（static file）来生成更加丰富的⽹页。

**模板** 即包含程序页面的HTML文件，**静态文件** 则是需要在HTML文件中加载的 CSS 和 JavaScript 文件，以及图⽚、字体文件等资源文件。

默认情况下，模板文件存放在项目根目录中的 templates 文件夹中，静态文件存放在 static 文 件夹下，这两个文件夹需要和包含程序实例的模块处于同一个目录下，对应的项目结构示例如下所示：

```
helloflask/
	- templates/ 
	- static/ 
	- app.py
```

#### 初始化参数

Flask 程序实例在创建的时候，需要默认传入当前 Flask 程序所指定的包(模块)，接下来就来详细查看一下 Flask 应用程序在创建的时候一些需要我们关注的参数：

- import_name
  - Flask程序所在的包(模块)，传 `__name__` 就可以
  - 其可以决定 Flask 在访问静态文件时查找的路径
- static_folder
  - 静态文件存储的文件夹，可以不传，默认为 `static` 
- template_folder
  - 模板文件存储的文件夹，可以不传，默认为 `templates` 

```python
# 初始化 Flask 应用程序，并指定当前程序所处于的包名
from flask import current_app, Flask, render_template

app = Flask(__name__,
            static_folder='static',  # 静态文件所在的文件夹名，默认为 static
            template_folder='templates',  # 模板文件所在的文件夹名，默认为 templates
		)

```

#### 程序配置加载

在 Flask 程序运行的时候，可以给 Flask 设置相关配置，比如：配置数据库连接地址等等，设置 Flask 配置有以下四种方式：

2. 从配置对象中加载(常用)

   app.config.form_object()

3. 从配置文件中加载

   app.config.form_pyfile()

4. 从环境变量中加载(了解)

   app.config.from_envvar()

下面演示如何从对象中加载配置文件

```
class TestConfig:
    SECRET_KEY = "测试秘钥"
    

# app.secret_key = '使用app对象进行配置秘钥'
# app.config['SECRET_KEY'] = '使用配置文件进行配置秘钥'
# app.config.from_object(TestConfig)
app.config.from_pyfile('config.py')
```

### @Flask与MVC架构 

MVC架构最初是用来设计桌面程序的，后来也被用于Web程序，应用 了这种架构的 Web 框架有 Django、Ruby on Rails等。

在 MVC 架构中，程序被分为三个组件：数据处理（Model）、用户界面（View）、交互逻辑 （Controller）。 严格来说，Flask并不是MVC架构的框架，因为它没有内置数据模型⽀持。为了方便表述，在本教程中，使用了 app.route（）装饰器的函数仍被称为视图函数，同时会使用“<函数名>视图”（比如index视图）的形式来代指某个视图函数。 

如果想要使用 Flask 来编写一个MVC架构的程序，那么视图函数可以作为控制器（Controller），视图（View）则是将要学习的使用 Jinja2 渲染的 HTML 模板，而模型（Model）可以使用其他库来实现，用 SQLAlchemy 来创建数据库模型。

flask 是 MVT 结构

### @自定义Flask命令

除了 Flask 内置的 flask run 等命令，我们也可以自定义命令。在虚拟环境安装Flask后，包含许多内置命令的flask脚本就可以使用了。在前面我们 已经接触了很多flask命令，比如运行服务器的 flask run，启动 shell 的 flask shell。

通过创建任意一个函数，并为其添加 app.cli.command() 装饰器，我 们就可以注册一个 flask 命令。代码清单1-4创建了一个自定义的 hello() 命 令函数，在函数中我们仍然只是打印一行问候。 

创建自定义命令

```python
import click


@app.cli.command() 
def hello(): 
	click.echo('Hello, flask!')

```

函数的名称即为命令名称，这里注册的命令即hello，你可以使用flask hello命令来触发函数。作为替代，你也可以在 `app.cli.command()` 装饰器 中传入参数来设置命令名称，比如 `app.cli.command('say-hello')` 会把命令 名称设置为say-hello，完整的命令即 flask say-hello 。 

借助 click 模块的 echo() 函数，我们可以在命令行界面输出字符。命令函数的文档字符串则会作为帮助信息显示（flask hello--help）。在命令 行下执行flask hello命令就会触发这个hello（）函数： 

```
$ flask hello 
Hello, flask!
```

在命令下执行flask--help可以查看Flask提供的命令帮助文档，我们自定 义的hello命令也会出现在输出的命令列表中，如下所示： 

```
$ flask
Usage: flask [OPTIONS] COMMAND [ARGS]...

  A general utility script for Flask applications.

  Provides commands from Flask, extensions, and the application. Loads the
  application defined in the FLASK_APP environment variable, or from a
  wsgi.py file. Setting the FLASK_ENV environment variable to 'development'
  will enable debug mode.

    > set FLASK_APP=hello.py
    > set FLASK_ENV=development
    > flask run

Options:
  --version  Show the flask version
  --help     Show this message and exit.

Commands:
  hello   自己定义的指令
  routes  Show the routes for the app.
  run     Runs a development server.
  shell   Runs a shell in the app context.


```

关于自定义命令更多的设置和功能请参考Click的官方文档 ：<https://click.palletsprojects.com/en/6.x/>

我们已经了解了Flask的基本知识，如果想要进一步开发更复杂的 Flask 应用，我们就得了解 Flask 与HTTP 协议的交互方式。 HTTP（Hypertext Transfer Protocol，超文本传输协议）定义了服务器和客户端之间信息交流的格式和传递方式，它是万维⽹（World Wide Web）中数据交换的基础。

了解 Flask 处理请求和响应的各种方式，并对 HTTP  协议以及其他非常规 HTTP 请求。

## 请求与响应

在视图编写中需要读取客户端请求携带的数据时，如何才能正确的取出数据呢？

请求携带的数据可能出现在HTTP报文中的不同位置，需要使用不同的方法来获取参数。

<span style="font-weight: bold;font-size: 20px"> 请求响应循环</span> 

当我们在浏览器中的地址栏中输入个URL，然后按下Enter时，稍等⽚刻，浏览器会显示一个问候页面。这背后到底发生了什么？

事实上，每一个Web应用都包含这种处理模式，即“请求-响应循环（Request- Response Cycle）”：客户端发出请求，服务器端处理请求并返回响应，如图所示。



![图2-1 请求响应循环示意图](assets/1561990644996.png)

客户端（Client Side）是指用来提供给用户的与服务器通信的各种软件。客户端通常指Web浏览器，比如Chrome、Firefox、IE等；服务器端（Server Side）则指为用户提供服务的服务器，也是我们的程序运行的地方。

Flask 程序工作的实际流程如下图所示，HTTP 在整个流程中起到了至关重要的作用，它是客户端和服务器端之间沟通的桥梁。

![图2-2 Flask Web程序工作流程](assets/1561990678422.png)

当用户访问一个URL的整个流程

1. 浏览器便生成对应的 HTTP 请求，经由互联⽹发送到对应的Web服务器。
2. Web 服务器接收请求，通过 WSGI 将 HTTP 格式的请求数据转换成我们的 Flask 程序能够使用的 Python 数据。在程序中，Flask 根据请求的 URL 执行对应的视图函数，获取返回值生成响应。
3. 响应依次经 过 WSGI 转换生成 HTTP 响应，再经由 Web 服务器传递，最终被发出请求的客户端接收。
4. 浏览器渲染响应中包含的 HTML 和 CSS 代码，并执行 JavaScript 代码，最终把解析后的页面呈现在用户浏览器的窗口中。

### 处理HTTP请求

URL 是一个请求的起源。当我们输入指向服务器所在地址的URL，都会向服 务器发送一个HTTP请求。一个标准的URL由很多部分组成，以下面这个 URL 为例：

```html
https://maoyan.com/query?w=蜘蛛侠
```

这个URL的各个组成部分如表2-1所示。 

| 信 息            | 说 明                                           |
| ---------------- | ----------------------------------------------- |
| https://         | 协议字符串，指定要使用的协议                    |
| maoyan.com       | 服务器的地址（域名）                            |
| /query?kw=蜘蛛侠 | 要获取的资源路径（path）,类似UNIX的文件目录结构 |

这个URL后面的 ?kw=蜘蛛侠部分是查询字符串（query string）。 URL 中的查询字符串用来向指定的资源传递参数。查询字符串从问号 ? 开始，以键值对的形式写出，多个键值对之间使用&分隔。 

#### 请求报文

当我们在浏览器中访问这个URL时，随之产生的是一个发向 <https://maoyan.com/> 所在服务器的请求。请求的实质是发送到服务器的一些数据，这种浏览器与服务器之间交互的数据被称为报文 （message），请求时浏览器发送的数据被称为请求报文（request message），而服务器返回的数据被称为响应报文（response message）。 

请求报文由请求的方法、URL、协议版本、首部字段（header）以及内容实体组成。

> 请求报文示意表 

| 组成说明                            | 请求报文内容                                                 |
| ----------------------------------- | ------------------------------------------------------------ |
| 报文首部：请求行（方法、URL、协议） | GET /hello HTTP/1.1                                          |
| 报文首部：各种首部字段              | Host: 127.0.0.1:5000<br>Connection: keep-alive<br>Cache-Control: max-age=0<br>User-Agent: Mozilla/5.0 (Windows NT 6.1; Win64; x64)AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.104 Safari/537.36<br>... |
| 空行                                |                                                              |
| 报文主体                            | name='zhengsan'                                              |

> 下图是使用Chrome访问本地示例程序的示例。

![图2-3 在Chrome浏览器中查看请求和响应报文 ](assets/1562143001044.png)



HTTP通过方法来区分不同的请求类型。比如，当你直接访问一个页面 时，请求的方法是GET；当你在某个页面填写了表单并提交时，请求方法则通常为POST。下表是常见的几种HTTP方法类型

> 常见的HTTP方法 

| 方 法   | 说 明          |
| ------- | -------------- |
| GET     | 获取资源       |
| POST    | 传输数据       |
| PUT     | 传输文件       |
| DELETE  | 删除资源       |
| HEAD    | 获得报文首部   |
| OPTIONS | 询问支持的方法 |

报文首部包含了请求的各种信息和设置，比如客户端的类型、是否设置缓存、语言偏好等。 

如果运行了示例程序，那么当你在浏览器中访问 http://127.0.0.1:5000 时，开发服务器会在命令行中输出一条记录⽇志，其中包含请求的主要信息： 

```
127.0.0.1 - - [03/Jul/2019 16:33:30] "GET / HTTP/1.1" 200 -
```

#### Request对象 

请求解析和响应封装实际上大部分是由 Werkzeug 完成的，Flask⼦类化 Werkzeug 的请求（Request）和响应（Response）对象并添加了和程序相关的特定功能。

假设请求的URL 是 `http://127.0.0.1/hello?kw=蜘蛛侠` ，当 Flask 接收到请求后，请求对象 会提供多个属性来获取 URL 的各个部分，常用的属性如表2-4所示。 

> 表2-4 使用request的属性获取请求URL

| 属性     | 值                                      |
| -------- | --------------------------------------- |
| path     | u'hello'                                |
| fullpath | u'hello?kw=蜘蛛侠'                      |
| host     | u'127.0.0.1'                            |
| host_url | u'http://127.0.0.1.com/'                |
| baseurl  | u'http://127.0.0.1.com/hello'           |
| url      | u'http://127.0.0.1.com/hello?kw=蜘蛛侠' |
| urlroot  | u'http://127.0.0.1.com/'                |

除了URL，请求报文中的其他信息都可以通过request对象提供的属性和方法获取，其中常用的部分如表2-5 所示。 

| 属性    | 说明                           | 类型           |
| :------ | :----------------------------- | :------------- |
| data    | 记录请求的数据，并转换为字符串 | *              |
| form    | 记录请求中的表单数据           | MultiDict      |
| args    | 记录请求中的查询参数           | MultiDict      |
| cookies | 记录请求中的cookie信息         | Dict           |
| headers | 记录请求中的报文头             | EnvironHeaders |
| method  | 记录请求使用的HTTP方法         | GET/POST       |
| url     | 记录请求的URL地址              | string         |
| files   | 记录请求上传的文件             | *              |

> 获取请求URL中的查询字符串 

```python
from flask import Flask, request
app = Flask(__name__)


@app.route('/')
def index():
    # 答应请求头
    print(request.headers)
    # 查看请求拥有的方法
    print(dir(request))
    # 打印请求方法
    print(request.method)
    # 获取请求参数
    print(request.args.get('name'))
    return 'hello flask !'


```

#### HTTP方法

前面通过 flask routes 命令打印出的路由列表可以看到，每一个路由除了包含URL规则外，还设置了监听的HTTP方法。GET是最常用的 HTTP方法，所以视图函数默认监听的方法类型就是 GET，HEAD、 OPTIONS 方法的请求由 Flask 处理，而像 DELETE、PUT 等方法一般不会在 程序中实现，在后面我们构建 Web API 时才会用到这些方法。 

我们可以在 app.route() 装饰器中使用 methods 参数传入一个包含监听 的 HTTP 方法的可迭代对象。比如，下面的视图函数同时监听 GET 请求和 POST 请求： 

```python
@app.route('/hello', methods=['GET', 'POST'])
def hello(): 
	return '<h1>Hello, Flask!</h1>'

```

当某个请求的方法不符合要求时，请求将无法被正常处理。比如在提交表单时通常使用 POST 方法，而如果提交

的目标 URL 对应的视图函数只允许 GET 方法，这时 Flask 会自动返回一个405错误响应（Method Not Allowed，表示请求方法不允许），如图2-6所示。

![1562151707837](assets/1562151707837.png)

通过定义方法列表，我们可以为同一个 URL 规则定义多个视图函数， 分别处理不同 HTTP 方法的请求。

### 处理HTTP响应

#### 响应报文

响应报文主要由协议版本、状态码（status code）、原因短语（reason phrase）、响应首部和响应主体组成。

| 组成说明                                   | 响应报文内容                                                 |
| ------------------------------------------ | ------------------------------------------------------------ |
| 报文首部：状态行（协议、状态码、原因短语） | HTTP/1.0 200 OK                                              |
| 报文首部：各种首部字段                     | Content-Type: text/html; charset=utf-8<br/>Content-Length: 31<br/>Server: Werkzeug/0.15.4 Python/3.6.5<br/>Date: Wed, 03 Jul 2019 14:06:49 GMT |
| 空行                                       |                                                              |
| 报文主体                                   | <hl>Hello, flask!</h1>                                       |

响应报文的首部包含一些关于响应和服务器的信息，这些内容由Flask 生成，而我们在视图函数中返回的内容即为响应报文中的主体内容。浏览 器接收到响应后，会把返回的响应主体解析并显示在浏览器窗口上。 

HTTP状态码用来表示请求处理的结果

> 常见的HTTP状态码和相应的原因短语

| 类 型        | 状态码 | 原因短语（用于解释状态码） | 说 明                                                        |
| ------------ | ------ | -------------------------- | ------------------------------------------------------------ |
| 成功         | 200    | OK                         | 请求被正常处理                                               |
|              | 201    | Created                    | 请求被处理，并创建了一个新资源                               |
|              | 204    | No Content                 | 请求处理成功，但无内容返回                                   |
| 重定向       | 301    | Moved Permanently          | 永久重定向                                                   |
|              | 302    | Found                      | 临时性重定向                                                 |
|              | 304    | Not Modified               | 请求的资源未被修改，重定向到缓存的资源                       |
| 客户端错误   | 400    | Bad Request                | 表示请求无效，即请求报文中存在错误                           |
|              | 401    | Unauthorized               | 类似403,表示请求的资源需要获取授权信息， 在浏览器中会弹出认证弹窗 |
|              | 403    | Forbidden                  | 表示请求的资源被服务器拒绝访问                               |
|              | 404    | Not Found                  | 表示服务器上无法找到请求的资源或URL无效                      |
| 服务器端错误 | 500    | Internal Server Error      | 服务器内部发生错误                                           |

##### 在Flask中生成响应 

响应在 Flask 中使用 Response 对象表示，响应报文中的大部分内容由服务器处理，大多数情况下，我们只负责返回主体内容。 

视图函数可以返回最多由三个元素组成的元组：响应主体、状态码、首部字段。其中首部字段可以为字典，或是两元素元组组成的列表。Flask 会调用 make_response() 方法将视图函数返回值转换为响应对象。

比如，普通的响应可以只包含主体内容： 

```python
@app.route('/')
def hello(): 
    return '<h1>Hello, Flask!</h1>'

```

默认的状态码为200，下面指定了不同的状态码

##### 元组方式

可以返回一个元组，这样的元组必须是 **(response, status, headers)** 的形式，且至少包含一个元素。 status 值会覆盖状态代码， headers 可以是一个列表或字典，作为额外的消息标头值。

```python
@app.route('/') 
def hello(): 
	... 
	return '<h1>Hello, Flask!</h1>', 201

```

有时你会想附加或修改某个首部字段。比如，要生成状态码为 3XX 的 

##### make_response方式

```python
from flask import make_response

@app.route('/')
def hello():
    resp = make_response('make response测试')
    resp.headers["code"] = "Python"
    resp.status = "404 not found"
    return resp

```

##### 错误响应 

大多数情况下，Flask会自动处理常见的错误响应。如果你想手动返回错误响应，更方便的方法是使用Flask提供的 abort() 函数。 

在 abort() 函数中传入状态码即可返回对应的错误响应

```python
from flask import Flask, abort


@app.route('/not_found')
def not_found():
    abort(404)

```

 abort() 函数前不需要使用 return 语句，但一旦 abort() 函数被调用，  abort() 函数之后的代码将不会被执行。 

#### 响应格式 

常用的数据格式有纯文本、HTML、XML和JSON，下面我们分别对这 几种数据进行简单的介绍和分析。为了对不同的数据类型进行对比，我们 将会用不同的数据类型来表示一个便签的内容：张三 写给 李四 的一封信。

##### JSON 

JSON 指 JavaScript Object Notation（JavaScript对象 表示法），是一种流行的、轻量的数据交换格式。它的出现⼜弥补了 XML 的诸多不足：XML 有较高的重用性，但 XML 相对于其他文档格式来说体积稍大，处理和解析的速度较慢。JSON轻量，简洁，容易阅读和解析，而且能和 Web 默认的客户端语言 JavaScript 更好地兼容。正是因为这种通用的数据结构，使得 JSON 在同样基于这些结构的编程语言之间交换成为可能。 

Flask 通过引入 Python 标准库中的 json 模块为程序提供了 JSON ⽀持。你可以直接从Flask中导入 json 对象，然后调用 dumps() 方法将字典、列表或元组序列化（serialize）为 JSON 字符串，再使用前面介绍的方法修改 MIME 类型，即可返回  JSON 响应，如下所示： 

```python
from flask import Flask, make_response, json 

... 

@app.route('/foo') 
def foo(): 
	data = { '姓名':'张三', '性别':'男' }
	response = make_response(json.dumps(data)) 
	response.mimetype = 'application/json' 
	return response

```

不过我们一般并不直接使用 json 模块的 dumps() 、load() 等方法， 因为Flask通过包装这些方法提供了更方便的jsonify() 函数。借助 jsonify() 函数，我们仅需要传入数据或参数，它会对我们传入的参数进行序列化，转换成JSON字符串作为响应的主体，然后生成一个响应对象， 并且设置正确的 MIME 类型。

jsonify() 函数接收多种形式的参数。你既可以传入普通参数，也可以传入关键字参数。如果你想要更直观一点，也可以像使用 dumps() 方 法一样传入字典、列表或元组，比如： 

```python
from flask import jsonify 
@app.route('/foo')
def foo(): 
	return jsonify({name: 'zhangsan', gender: 'male'})

```

会生成下面的JSON字符串： 

```python
'{"gender": "male", "name": "zhangsan"}'
```

##### HTML 

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>给李四的信</title>
</head>
<body>
<h1>给李四的信</h1>
<p>亲爱的李四: </p>
<p>你好</p>
<p><strong>生活就像是强奸，如果不能反抗，那就好好享受！</strong></p>
<p>祝：工作顺利</p>
<p>x年x月x日</p>
<p>你的朋友：张三</p>
</body>
</html>

```

HTML（https://www.w3.org/html/ ）指Hypertext Markup Language（超文本标记语言），是最常用的数据格式，也是Flask返回响应的默认数据类 型。从我们在本书一开始的最⼩程序中的视图函数返回的字符串，到我们 后面会学习的HTML模板，都是HTML。当数据类型为HTML时，浏览器会 自动根据HTML标签以及样式类定义渲染对应的样式。 这也是默认的数据类型。 



#### 网页重定向

视图函数的名字是自由定义的，和 URL 规则无关。和定义其他函数或变量一样，只需要让它表达出所要处理页面的含义即可。使用Flask提供的 url_for() 函数获取 URL，当路由中定义的 URL 规则被修改时，这个函数总会返回正确的 URL 。

除此之外，它还有一个重要的作用：作为代表某个路由的端点（endpoint），同时用来生成 URL。对于程序内的 URL，为了避免手写，Flask 提供了一个 `url_for` 函数来生成 URL，它接受的第一个参数就是端点值，默认为视图函数的名称。

```python
from flask import url_for

@app.route('/test_url_for')
def test_url_for():
    return url_for('user', user='test_url_for')

```

- 路由的端点即视图函数的名称 test_url_for，调用 url_for('test_url_for') 即可 获取对应的 URL，即 `/test_url_for`。 
- 在 app.route() 装饰器中使用 endpoint 参数可以自定义端点值，不过我们通常不需要这样做。 
- 如果URL含有动态部分，那么我们需要在 url_for() 函数里传入相应的参数 



在 Web 程序中，我们经常需要进行重定向。比如，当某个用户在没有经过认证的情况下访问需要登录后才能访问的资源，程序通常会重定向到登录页面。 

对于重定向这一类特殊响应，Flask 提供了一些辅助函数。除了像前面 那样手动生成302响应，我们可以使用 Flask提供的 redirect() 函数来生成 重定向响应，重定向的目标 URL 作为第一个参数。前面的例⼦可以简化 为：

```python
from flask import Flask, redirect 


@app.route('/baidu')
def bai_du():
    return redirect('http://www.baidu.com')

```

> 重定向流程示意图 

![1562164056648](assets/1562164056648.png)

### Cookie 

HTTP 是无状态（stateless）协议。也就是说，在一次请求响应结束后，服务器不会留下任何关于对方状态的信息。但是对于某些Web程序来 说，客户端的某些信息⼜必须被记住，比如用户的登录状态，这样才可以根据用户的状态来返回不同的响应。为了解决这类问题，就有了Cookie技 术。Cookie技术通过在请求和响应报文中添加Cookie数据来保存客户端的状态信息。

**无状态**：指一次用户请求时，浏览器、服务器无法知道之前这个用户做过什么，每次请求都是一次新的请求。

**无状态原因**：浏览器与服务器是使用 socket 套接字进行通信的，服务器将请求结果返回给浏览器之后，会关闭当前的 socket 连接，而且服务器也会在处理页面完毕之后销毁页面对象。

有时需要保持下来用户浏览的状态，比如用户是否登录过，浏览过哪些商品等

实现状态保持主要有两种方式：

- 在客户端存储信息使用 `Cookie` 
- 在服务器端存储信息使用 `Session` 

Cookie：指某些网站为了辨别用户身份、进行会话跟踪而储存在用户本地的数据（通常经过加密）。

- 复数形式Cookies。
- Cookie是由服务器端生成，发送给客户端浏览器，浏览器会将 Cookie 的 key/value 保存，下次请求同一网站时就发送该 Cookie 给服务器（前提是浏览器设置为启用 cookie ）。
- Cookie 的 key/value 可以由服务器端自己定义。

应用：

- 最典型的应用是判定注册用户是否已经登录网站，用户可能会得到提示，是否在下一次进入此网站时保留用户信息以便简化登录手续，这些都是 Cookie 的功用。
- 网站的广告推送，经常遇到访问某个网站时，会弹出小窗口，展示我们曾经在购物网站上看过的商品信息。
- 购物车，用户可能会在一段时间内在同一家网站的不同页面中选择不同的商品，这些信息都会写入Cookie，以便在最后付款时提取信息。

提示：

- Cookie 是存储在浏览器中的一段纯文本信息，建议不要存储敏感信息如密码，因为电脑上的浏览器可能被其它人使用
- Cookie 基于域名安全，不同域名的 Cookie 是不能互相访问的
  - 如访问 python.org 时向浏览器中写了 Cookie 信息，使用同一浏览器访问 baidu.com 时，无法访问到 python.org 写的 Cookie 信息
  - 浏览器的同源策略
- 当浏览器请求某网站时，会将本网站下所有 Cookie 信息提交给服务器，所以在 request 中可以读取 Cookie 信息

#### 设置 cookie

通过操作 response 对象的 set_cookie 方法我们可以设置自定义cookie:

```python
from flask import Flask, abort, request, make_response

app = Flask(__name__)


@app.route('/set_cookie')
def set_cookie():
    response = make_response('设置 cookie')
    response.set_cookie('username', 'tom')
    return response

```

> set_cookie的参数

| **属 性** | **说 明**                                                    |
| --------- | ------------------------------------------------------------ |
| key       | cookie的键（名称）                                           |
| value     | cookie的值                                                   |
| max_age   | cookie被保存的时间数，单位为秒；默认在用户会话结束（即关闭浏览器）时过期 |
| expires   | 具体的过期时间，一个datetime对象或UNIX时间戳                 |
| path      | 限制cookie只在给定的路径可用，默认为整个域名                 |
| domain    | 设置cookie可用的域名                                         |
| secure    | 如果设为True,只有通过HTTPS才可以使用                         |
| httponly  | 如果设为True,禁止客户端JavaScript获取cookie                  |

设置过期时间

```python
@app.route('/set_cookie')
def set_cookie():
    response = make_response('设置 cookie')
    response.set_cookie('username', 'tom', max_age=3600)
    return response

```

#### 获取cookie

可以使用 request 对象 cookies 字段的 get 方法来获取我们所需要的 cookie 

```python
@app.route('/get_cookie')
def get_cookie():
    username = request.cookies.get('username')
    return "cookie 中的名字为：" + username

```

#### 删除cookie

共有三种方法可以删除一个 cookie : 
(1) 可以通过在浏览器中设置来清除 cookie. 

(2) 使用 response 的 set_cookie 进行清除

(3)使用Response的 delete_cookie方法.

```python
@app.route('/del_cookie')
def del_cookie():
    response = make_response('删除cookie')
    # response.set_cookie('username', '', expires=0)
    response.delete_cookie('username')
    return response

```

### session：安全的Cookie 

session 是基于 cookie 实现， 保存在服务端的键值对, 同时在浏览器中的 cookie 中也对应一相同的随机字符串，用来再次请求的时候验证；

- 对于敏感、重要的信息，建议存储在服务器端，不能存储在浏览器中，如用户名、余额、等级、验证码等信息
- 在服务器端进行状态保持的方案就是 `Session` 
- **Session依赖于Cookie**  

#### session设置与删除

session:请求上下文对象，用于处理http请求中的一些数据内容

在 flask 中使用 session 也很简单，只要使用 `from flask import session` 导入这个变量，在代码中就能直接通过读写它和 session 交互。

> 因为flask的session是通过加密之后放到了cookie中。所以有加密就有密钥用于解密，所以，只要用到了flask的session模块就一定要配置“SECRET_KEY”这个全局宏。一般设置为24位的字符。

```python
# -*- coding: utf-8 -*-

from flask import Flask, session

app = Flask(__name__)
# 设置加密字符串
app.secret_key = 'secret'


@app.route('/set_session')
def index1():
    session['username'] = 'tony'
    return session['username']


@app.route('/get_session')
def get_session():
    # session_name = session['username']
    session_name = session.get('username')
    return session_name


@app.route('/del_session/')
def delete():
    session.pop('username', None)
    session['username'] = False
    print(session.get('username'))
    return "删除会话"


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5050, debug=True)


```

#### session过期时间

如果没有指定 session 的过期时间，那么默认是浏览器关闭后就自动结束。session.permanent = True 在 flask下则可以将有效期延长至一个月。下面有方法可以配置具体多少天的有效期。

- 如果没有指定 session 的过期时间，那么默认是浏览器关闭后就自动结束
- 如果设置了 session 的 permanent 属性为 True，那么过期时间是31天。
- 可以通过给 `app.config` 设置 `PERMANENT_SESSION_LIFETIME` 来更改过期时间，这个值的数据类型是`datetime.timedelay`类型。

一种更先进的配置有效期的方法：（比如配置7天有效）

- 1.引入包：`from datetime import timedelta` 
- 2.配置有效期限：`app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(days=7) # 配置7天有效` 
- 3.设置：`session.permanent = True` 

```python
from flask import Flask,session
from datetime import timedelta
import os 
app = Flask(__name__)
app.config['SECRET_KEY'] = os.urandom(24)
app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(days=7) # 配置7天有效 

```

### 请求钩子

在客户端和服务器交互的过程中，有些准备工作或扫尾工作需要处理，比如：

- 在请求开始时，建立数据库连接；
- 在请求开始时，根据需求进行权限校验；
- 在请求结束时，指定数据的交互格式；

为了让每个视图函数避免编写重复功能的代码，Flask提供了通用设施的功能，即请求钩子。

请求钩子是通过装饰器的形式实现，Flask支持如下四种请求钩子：

> 表2-7 请求钩⼦ 

| 钩 子                | 说 明                                            |
| -------------------- | ------------------------------------------------ |
| before_first_request | 在处理第一个请求前执行                           |
| before_request       | 在每次请求前执行                                 |
| after_request        | 如果没有未处理的异常抛出，会在每个请求结束后运行 |
| teardown_request     | 在每次请求后执行，如果有相关错误抛出             |

这些钩⼦使用起来和 app.route() 装饰器基本相同，每个钩⼦可以注册任意多个处理函数，函数名并不是必须和钩⼦名称相同，下面是一个基本示例： 

```python
from flask import Flask
from flask import abort

app = Flask(__name__)


# 在第一次请求之前调用，可以在此方法内部做一些初始化操作
@app.before_first_request
def before_first_request():
    print("before_first_request")


# 在每一次请求之前调用，这时候已经有请求了，可能在这个方法里面做请求的校验
# 如果请求的校验不成功，可以直接在此方法中进行响应，直接return之后那么就不会执行视图函数
@app.before_request
def before_request():
    print("before_request")
    # if 请求不符合条件:
    #     return "laowang"


# 在执行完视图函数之后会调用，并且会把视图函数所生成的响应传入,可以在此方法中对响应做最后一步统一的处理
@app.after_request
def after_request(response):
    print("after_request")
    response.headers["Content-Type"] = "application/json"
    return response


# 请每一次请求之后都会调用，会接受一个参数，参数是服务器出现的错误信息
@app.teardown_request
def teardown_request(e):
    print("teardown_request")


@app.route('/')
def index():
    return 'index'


```

假如我们创建了三个视图函数 A、B、C，其中视图 C 使用了 after_this_request钩⼦，那么当请求 A 进入后，整个请求处理周期的请求处 理函数调用流程如图2-7所示。 

下面是请求钩⼦的一些常见应用场景： 

+ before_first_request

  在玩具程序中，运行程序前我们需要进行一些程序的初始化操作，比如创建数据库表，添加管理员用户。这些工作可以放 到使用before_first_request装饰器注册的函数中。 

+ before_request

  比如⽹站上要记录用户最后在线的时间，可以通过用户最后发送的请求时间来实现。为了避免在每个视图函数都添加更新在线 时间的代码，我们可以仅在使用before_request钩⼦注册的函数中调用这段代码。

+ after_request

  我们经常在视图函数中进行数据库操作，比如更新、 插入等，之后需要将更改提交到数据库中。提交更改的代码就可以放到 after_request 钩⼦注册的函数中。

> 图2-7 请求处理函数调用示意图 

![1562141891761](assets/1562141891761.png)

在Flask程序中，客户端发出的请求触发相应的视图函数，获取返回值会作为响应的主体，最后生成完整的响应，即响应报文。

### 异常处理

#### HTTP 异常主动抛出

- abort 方法
  - 抛出一个给定状态代码的 HTTPException 或者 指定响应，例如想要用一个页面未找到异常来终止请求，你可以调用 abort(404)。
- 参数：
  - code – HTTP的错误状态码

```python
# abort(404)
abort(500)

```

> 抛出状态码的话，只能抛出 HTTP 协议的错误状态码

#### 捕获错误

- errorhandler 装饰器
  - 注册一个错误处理程序，当程序抛出指定错误状态码的时候，就会调用该装饰器所装饰的方法
- 参数：
  - code_or_exception – HTTP的错误状态码或指定异常
- 例如统一处理状态码为500的错误给用户友好的提示：

```python
# -*- coding: utf-8 -*-
from flask import Flask

app = Flask(__name__)


@app.route('/')
def index():
    return 'index'


@app.errorhandler(500)
def internal_server_error(e):
    return '服务器搬家了'


@app.errorhandler(404)
def internal_server_error(e):
    return '404 错误'


```

- 捕获指定异常

```python
@app.errorhandler(ZeroDivisionError)
def zero_division_error(e):
    return '除数不能为0'

```

### flask 上下文

上下文：即语境，语意，在程序中可以理解为在代码执行到某一时刻时，根据之前代码所做的操作以及下文即将要执行的逻辑，可以决定在当前时刻下可以使用到的变量，或者可以完成的事情。

Flask中有两种上下文，请求上下文和应用上下文

Flask中上下文对象：相当于一个容器，保存了 Flask 程序运行过程中的一些信息。

在很多情况下，要执行某一操作，需要做很多的准备工作！而这一操作前必须满足的状态，就是当前操作的上文。由此及彼，当前操作之后要达到的状态就是当前操作的下文！其实就是中文里所谓的语境，就是语言环境。

| **变量名**  | 上下文类别 | 说 明                                                        |
| ----------- | ---------- | ------------------------------------------------------------ |
| current_app | 程序上下文 | 指向处理请求的当前程序实例                                   |
| g           | 程序上下文 | 替代Python的全局变量用法，确保仅在当前请求中可用。用于存储全局数据，每次请求都会重设 |
| request     | 请求上下文 | 封装客户端发出的请求报文数据                                 |
| session     | 请求上下文 | 用于记住请求之间的数据，通过签名的Cookie实现                 |

#### 请求上下文(request context)

思考：在视图函数中，如何取到当前请求的相关数据？比如：请求地址，请求方式，cookie等等

在 flask 中，可以直接在视图函数中使用 **request** 这个对象进行获取相关数据，而 **request** 就是请求上下文的对象，保存了当前本次请求的相关数据，请求上下文对象有：request、session

- request
  - 封装了HTTP请求的内容，针对的是 http 请求。举例：user = request.args.get('user')，获取的是get请求的参数。
- session
  - 用来记录请求会话中的信息，针对的是用户信息。举例：session['name'] = user.id，可以记录用户信息。还可以通过 session.get('name') 获取用户信息。

#### 应用上下文(application context)

它的字面意思是 应用上下文，但它不是一直存在的，它只是 request context 中的一个对 app 的代理(人)，所谓local proxy。它的作用主要是帮助 request 获取当前的应用，它是伴 request 而生，随 request 而灭的。

应用上下文对象有：current_app，g

##### current_app

应用程序上下文,用于存储应用程序中的变量，可以通过 current_app.name 打印当前app的名称，也可以在current_app中存储一些变量，例如：

- 应用的启动脚本是哪个文件，启动时指定了哪些参数
- 加载了哪些配置文件，导入了哪些配置
- 连了哪个数据库
- 有哪些 public 的工具类、常量
- 应用跑再哪个机器上，IP多少，内存多大

**示例**

```python
# -*- coding: utf-8 -*-
from flask import Flask, current_app

app1 = Flask(__name__)
app2 = Flask(__name__)

# 以 secret_key 对象为例
# 为了方便在各个视图中使用，将创建的 secret_key 变量保存到flask app中，
# 后续可以在视图中使用 current_app.secret_key 获取
app1.secret_key = 'app1 秘钥'
app2.secret_key = 'app2 秘钥'


@app1.route('/')
def route11():
    # current_app 是当前请求的对象，是app对象的一个代理对象，只能读取数据不能修改
    return current_app.secret_key


@app2.route('/')
def route12():
    return current_app.secret_key


```

运行

```shell
export FLASK_APP=FLASK_APP=08context.py:app1
flask run

```

- 访问`/` 显示`app1 秘钥`

```shell
export FLASK_APP=current_app_demo:app2
flask run

```

- 访问`/` 显示`app2 秘钥`

**作用**

`current_app` 就是当前运行的flask app，在代码不方便直接操作flask的app对象时，可以操作`current_app`就等价于操作flask app对象



##### 变量 g

g 作为 flask 程序全局的一个临时变量，充当中间媒介的作用，我们可以通过它在一次请求调用的多个函数间传递一些数据。每次请求都会重设这个变量。

大的区别是，session 对象是可以跨 request 的，只要 session 还未失效，不同的 request 的请求会获取到同一个session，但是 g 对象不是，g 对象不需要管过期时间，请求一次就 g 对象就改变了一次，或者重新赋值了一次。那么 g 对象该如何使用呢？

```python
from flask import Flask, g

app = Flask(__name__)

def db_query():
    user_id = g.user_id
    user_name = g.user_name
    print('user_id={} user_name={}'.format(user_id, user_name))

@app.route('/')
def get_user_profile():
    g.user_id = 123
    g.user_name = 'info'
    db_query()
    return 'hello world'

```

> 注意：不同的请求，会有不同的全局变量

两者区别：

- 请求上下文：保存了客户端和服务器交互的数据
- 应用上下文：flask 应用程序运行过程中，保存的一些配置信息，比如程序名、数据库连接、应用信息等

### 请求钩子综合案例

#### 需求

（无前端页面）

- 构建认证机制
- 对于特定视图可以提供强制要求用户登录的限制
- 对于所有视图，无论是否强制要求用户登录，都可以在视图中尝试获取用户认证后的身份信息

```python
from flask import Flask, abort, g

app = Flask(__name__)

@app.before_request
def authentication():
    """
    利用before_request请求钩子，在进入所有视图前先尝试判断用户身份
    :return:
    """
    # TODO 此处利用鉴权机制（如cookie、session、jwt等）鉴别用户身份信息
    # if 已登录用户，用户有身份信息
    g.user_id = 123
    # else 未登录用户，用户无身份信息
    # g.user_id = None

def login_required(func):
    def wrapper(*args, **kwargs):
        if g.user_id is not None:
            return func(*args, **kwargs)
        else:
            abort(401)

    return wrapper

@app.route('/')
def index():
    return 'home page user_id={}'.format(g.user_id)

@app.route('/profile')
@login_required
def get_user_profile():
    return 'user profile page user_id={}'.format(g.user_id)

```



## 模板

### 什么是模板

网站的主页会有一个欢迎用户的标题。虽然目前的应用程序还没有实现用户概念，但这不妨碍我使用一个Python字典来*模拟*一个用户，如下所示：

```
user = {'username': '青灯教育'}
```

创建模拟对象是一项实用的技术，它可以让你专注于应用程序的一部分，而无需为系统中尚不存在的其他部分分心。 在设计应用程序主页的时候，我可不希望因为没有一个用户系统来分散我的注意力，因此我使用了模拟用户对象，来继续接下来的工作。

####  模板基本用法

原先的视图函数返回简单的字符串，我现在要将其扩展为包含完整HTML页面元素的字符串，如下所示：

```python
from flask import Flask

app = Flask(__name__, template_folder='templates')


@app.route('/')
@app.route('/index')
def index():
    user = {'username': '青灯教育'}
    return f'''
    <html>
        <head>
            <title>个人主页-{user['username']}</title>
        </head>
        <body>
            <h1>Hello, {user['username']}!</h1>
        </body>
    </html>'''


```

利用上述的代码更新这个视图函数，然后再次在浏览器打开它的URL看看结果。

![1560947013106](assets/1560947013106.png)

但是上面的案例有一个很大的缺陷——返回HTML的方式并不友好。如果视图变得非常多，就更加麻烦。

####  创建模板 

如果我说这个函数返回HTML的方式并不友好的话，你可能会觉得诧异。设想一下，当这个视图函数中的用户和博客不断变化时，里面的代码将会变得多么的复杂。应用的视图函数及其关联的URL也会持续增长。如果哪天我决定更改这个应用的布局，那就不得不更新每个视图函数的HTML字符串。显然，随着应用的扩张，这种方式完全不可行。

将应用程序的后台逻辑和网页布局划分开来，你不觉得更容易组织管理吗？甚至你可以聘请一位Web设计师来设计一个杀手级的网站前端，而你只需要用Python编写后台应用逻辑。

模板有助于实现页面展现和业务逻辑之间的分离。 在Flask中，模板被编写为单独的文件，存储在应用程序包内的*templates*文件夹中。 在确定你在 *microblog* 目录后，创建一个存储模板的目录：

```
(venv) $ mkdir templates

```

在下面可以看到你的第一个模板，它的功能与上面的`index()`视图函数返回的HTML页面相似。 把这个文件写在*app/templates/index.html* 中：

```
<!DOCTYPE html>
<html lang="en">
<head>
    <title>个人主页 - {{ username }}</title>
</head>

<body>
<h1>Hello, {{ username }}!</h1>
</body>
</html>

```

这个HTML页面看起来非常简单，唯一值得关注的地方是 `{{ ... }}`。`{{ ... }}` 包含的内容是动态的，只有在运行时才知道具体表示成什么样子。

网页渲染转移到HTML模板之后，视图函数就能被简化：

```
@app.route('/view')
def view():
    username = request.args.get('username')
    if not username:
        username = '正心'
    return render_template('0101temp.html', username=username)

```

看起来好多了吧？ 赶紧试试这个新版本的应用程序，看看模板是如何工作的。 在浏览器中加载页面后，你需要从浏览器查看 HTML 源代码并将其与原始模板进行比较。

将模板转换为完整的 HTML 页面的操作称为*渲染*。 为了渲染模板，需要从Flask框架中导入一个名为`render_template()` 的函数。 该函数需要传入模板文件名和模板参数的变量列表，并返回模板中所有占位符都用实际变量值替换后的字符串结果。

`render_template()` 函数调用Flask框架原生依赖的 [Jinja2](http://jinja.pocoo.org/) 模板引擎。 Jinja2 用 `render_template()` 函数传入的参数中的相应值替换 `{{...}}` 块。

####  模板的使用

设置 templates 文件夹属性以便能够在代码中有智能提示

![1560948907724](assets/1560948907724.png)

设置 html 中的模板语言，以便在 html 有智能提示

![1560948923337](assets/1560948923337.png)



###  模板语法

利用 Jinja2 这样的模板引擎，我们可以将一部分的程序逻辑放到模板中去。简单地说，我们可以在模板中使用Python语句和表达式来操作数据的输出。但需要注意的是，Jinja2并不⽀持所有Python语法。而且出于效率和
代码组织等方面的考虑，我们应该适度使用模板，仅把和输出控制有关的逻辑操作放到模板中。

Jinja2允许你在模板中使用大部分Python对象，比如字符串、列表、字典、元组、整型、浮点型、布尔值。它⽀持基本的运算符号（+、-、*、/等）、比较符号（比如==、！=等）、逻辑符号（and、or、not和括号）以及in、is、None和布尔值（True、False）。

Jinja2 的语法和 Python 大致相同，你在后面会陆续接触到一些常见的用法。在模板里，你需要添加特定的定界符将 Jinja2 语句和变量标记出来，下面是三种常用的定界符：

- `{{ ... }}` 用来标记变量。
- `{% ... %}` 用来标记语句，比如 if 语句，for 语句等。
- `{# ... #}` 用来写注释。

模板中使用的变量需要在渲染的时候传递进去

#### 使用变量

代码中传入字符串，列表，字典到模板中

```python
@app.route('/args')
def args():
    my_str = 'hello'
    my_int = 10
    my_arr = [1, 2, 3, 4, 5]
    my_dict = {
        "name": "正心",
        'age': 18
    }
    return render_template(
        '0103args.html',
        my_str=my_str,
        my_int=my_int,
        my_arr=my_arr,
        my_dict=my_dict,
    )


```

**模板中代码** 

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>模板变量</title>
</head>
<body>
<h1>我的模板变量</h1>
<div>str：{{ my_str }}</div>
<div>int：{{ my_int }}</div>
<div>arr：{{ my_arr }}</div>
<div>dict：{{ my_dict }}</div>
</body>
</html>

```

**运行效果** 

![1560949211303](assets/1560949211303.png)

**相关运算，取值** 

```html
<h1>相关运算</h1>
<div>str + str：{{ my_str + ' world !' }}</div>
<div>int + int：{{ my_int + 100}}</div>
<div>arr[1]：{{ my_arr[1] }}</div>
<div>arr[1:]：{{ my_arr[1:] }}</div>
<div>dict['name']：{{ my_dict['name'] }}</div>
<div>my_dict.items()：{{ my_dict.items() }}</div>

```



####  条件语句

在渲染过程中使用实际值替换占位符，只是Jinja2在模板文件中支持的诸多强大操作之一。 模板也支持在`{%...％}`块内使用控制语句。 *temp_demo3.html*模板的下一个版本添加了一个条件语句：

```jinja2
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    {% if username %}
        <title>个人主页 - {{ username }}</title>
    {% else %}
        <title>欢迎来到个人主页!</title>
    {% endif %}
</head>
<body>
<h1>Hello, {{ username }}!</h1>
</body>
</html>

```

现在，模板变得聪明点儿了，如果视图函数忘记给渲染函数传入一个名为 `title` 的关键字参数，那么模板将显示一个默认的标题，而不是显示一个空的标题。 你可以通过在视图函数的 `render_template()` 调用中去除`title`参数来试试这个条件语句是如何生效的。

```python
@app.route('/if')
def demo_if():
    # username = request.args.get('username')
    # if not username:
    #     username = '正心'
    return render_template(
        '0202if.html',
        # username=username,
    )

```

####  循环

登录后的用户可能想要在主页上查看其他用户的最新动态，针对这个需求，我现在要做的是丰富这个应用来满足它。

我将会故技重施，使用模拟对象的把戏来创建一些模拟用户和动态：

```
@app.route('/loop')
def demo_loop():
    my_array = ['苹果', '橘子', '西瓜']
    return render_template('0203loop.html',
                           arr=my_array)


```

我使用了一个列表来表示用户。然后将列表的发送给模板进行渲染

在模板方面，我必须解决一个新问题。 用户动态列表拥有的元素数量由视图函数决定。 那么模板不能对有多少个用户动态进行任何假设，因此需要准备好以通用方式渲染任意数量的用户动态。

Jinja2提供了 `for` 控制结构来应对这类问题：

```
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>循环</title>
</head>
<body>
<h3>列表取值</h3>
<div>我爱吃 {{ arr[0] }}!</div>
<div>我爱吃 {{ arr[1] }}!</div>
<div>我爱吃 {{ arr[2] }}!</div>
<h3>循环遍历</h3>
{% for i in arr %}
    <div>我爱吃 {{ i }}!</div>
{% endfor %}
<h3>循环特殊变量</h3>
{% for post in arr %}
    <div>{{ loop.index }}, {{ post }}</div>
{% endfor %}
</body>
</html>

```

大道至简，对吧？ 玩玩这个新版本的应用程序，一定要逐步添加更多的内容到用户列表，看看模板如何调度以展现视图函数传入的所有用户动态。

![image-20201114150959469](assets/image-20201114150959469.png)

在一个 for 循环块中你可以访问这些特殊的变量:

| 变量           | 描述                                  |
| -------------- | ------------------------------------- |
| loop.index     | 当前循环迭代的次数（从 1 开始）       |
| loop.index0    | 当前循环迭代的次数（从 0 开始）       |
| loop.revindex  | 到循环结束需要迭代的次数（从 1 开始） |
| loop.revindex0 | 到循环结束需要迭代的次数（从 0 开始） |
| loop.first     | 如果是第一次迭代，为 True 。          |
| loop.last      | 如果是最后一次迭代，为 True 。        |
| loop.length    | 序列中的项目数。                      |
| loop.cycle     | 在一串序列间期取值的辅助函数。        |

在循环内部,你可以使用一个叫做 loop 的特殊变量来获得关于 for 循环的一些信息

比如：要是我们想知道当前被迭代的元素序号，并模拟 Python 中的 enumerate 函数做的事情，则可以使用loop 变量的 index 属性,例如:

```
<h3>循环特殊变量</h3>
{% for post in arr %}
    <h1>{{ loop.index }}, {{ post }}</h1>
{% endfor %}

```

### 过滤器

在 Jinja2 中，过滤器（filter）是一些可以用来修改和过滤变量值的特殊函数，过滤器和变量用一个竖线（管道符号）隔开，需要参数的过滤器可以像函数一样使用括号传递。

有时候我们不仅仅只是需要输出变量的值，我们还需要修改变量的显示，甚至格式化、运算等等，而在模板中是不能直接调用 Python 中的某些方法，那么这就用到了过滤器。

下面是一个对 name 变量使用 title 过滤器的例⼦：

```
{{ name|title }}

```

这会将 name 变量的值标题化，相当于在 Python 里调用 name.title（）。

**使用方式：** 

过滤器的使用方式为：变量名 | 过滤器。

```python
{{variable | filter_name(*args)}}

```

如果没有任何参数传给过滤器,则可以把括号省略掉

```python
{{variable | filter_name}}

```

- 如：`variable`，这个过滤器的作用：把变量 variable 的值的首字母转换为大写，其他字母转换为小写

#### 链式调用

在 jinja2 中，过滤器是可以支持链式调用的，示例如下：

```python
{{ "hello world" | reverse | upper }}

```

####  字符串操作

safe：禁用转义

```python
<p>{{ '<b>hello</b>' | safe }}</p>

```

truncate: 字符串截断

```python
<p>{{ 'hello every one' | truncate(9)}}</p>

```

striptags：渲染之前把值中所有的HTML标签都删掉

```python
<p>{{ '<em>hello</em>' | striptags }}</p>

```



capitalize：把变量值的首字母转成大写，其余字母转小写

```python
<p>{{ 'hello' | capitalize }}</p>

```

lower：把值转成小写

```python
<p>{{ 'HELLO' | lower }}</p>

```

upper：把值转成大写

```python
<p>{{ 'hello' | upper }}</p>

```

title：把值中的每个单词的首字母都转成大写

```python
<p>{{ 'hello' | title }}</p>

```

reverse：字符串反转

```python
<p>{{ 'olleh' | reverse }}</p>

```

format：格式化输出

```python
<p>{{ '%s is %d' | format('name',17) }}</p>

```



####  列表操作

first：取第一个元素

```python
<p>{{ [1,2,3,4,5,6] | first }}</p>

```

last：取最后一个元素

```python
<p>{{ [1,2,3,4,5,6] | last }}</p>

```

length：获取列表长度

```python
<p>{{ [1,2,3,4,5,6] | length }}</p>

```

sum：列表求和

```python
<p>{{ [1,2,3,4,5,6] | sum }}</p>

```

sort：列表排序

```
<p>{{ [6,2,3,1,5,4] | sort }}</p>

```

###  宏

使用宏之前代码

```html
<form>
    <label>用户名：</label><input type="text" name="username"><br/>
    <label>身份证号：</label><input type="text" name="idcard"><br/>
    <label>密码：</label><input type="password" name="password"><br/>
    <label>确认密码：</label><input type="password" name="password2"><br/>
    <input type="submit" value="注册">
</form>

```

定义宏

```html
{#定义宏，相当于定义一个函数，在使用的时候直接调用该宏，传入不同的参数就可以了#}
{% macro input(label="", type="text", name="", value="") %}
<label>{{ label }}</label><input type="{{ type }}" name="{{ name }}" value="{{ value }}">
{% endmacro %}

```

使用宏

```html
<form>
    {{ input("用户名：", name="username") }}<br/>
    {{ input("身份证号：", name="idcard") }}<br/>
    {{ input("密码：", type="password", name="password") }}<br/>
    {{ input("确认密码：", type="password", name="password2") }}<br/>
    {{ input(type="submit", value="注册") }}
</form>

```

对宏(macro)的理解：

1. 把它看作 Jinja2 中的一个函数，它会返回一个模板或者 HTML 字符串
2. 为了避免反复地编写同样的模板代码，出现代码冗余，可以把他们写成函数以进行重用
3. 需要在多处重复使用的模板代码片段可以写入单独的文件，再包含在所有模板中，以避免重复

定义宏

```python
{% macro input(name,value='',type='text') %}
    <input type="{{type}}" name="{{name}}"
        value="{{value}}" class="form-control">
{% endmacro %}

```

调用宏

```python
{{ input('name'， value='zs')}}

```

这会输出

```python
<input type="text" name="name" value="zs" class="form-control">

```

把宏单独抽取出来，封装成html文件，其它模板中导入使用，文件名可以自定义macro.html

```python
{% macro function(type='text', name='name', value='张三') %}
<input type="{{type}}" name="{{name}}" value="{{value}}" class="form-control">
{% endmacro %}

```

在其它模板文件中先导入，再调用

```python
{% import 'macro.html' as func %}
{{ func.function() }}

```

###  模板的继承

绝大多数Web应用程序在页面的顶部都有一个导航栏，其中带有一些常用的链接，例如编辑配置文件，登录，注销等。我可以轻松地用HTML标记语言将导航栏添加到 `index.html` 模板上，但随着应用程序的增长，我将需要在其他页面重复同样的工作。尽量不要编写重复的代码，这是一个良好的编程习惯，毕竟我真的不想在诸多HTML模板上保留同样的代码。

Jinja2 有一个模板继承特性，专门解决这个问题。从本质上来讲，就是将所有模板中相同的部分转移到一个基础模板中，然后再从它继承过来。

![1561105840934](assets/1561105840934.png)

所以我现在要做的是定义一个名为 `base.html` 的基本模板，其中包含一个简单的导航栏，以及我之前实现的标题逻辑。 您需要在模板文件 *templates/base.html* 中编写代码如下：

```python
<!DOCTYPE html>
<html lang="en">
<head>
    {% if username %}
        <title>个人主页 - {{ username }}</title>
    {% else %}
        <title>欢迎来到个人主页</title>
    {% endif %}
</head>
<body>

{% block content %}{% endblock %}

</body>
</html>

```

在这个模板中，我使用 `block` 控制语句来定义派生模板可以插入代码的位置。 *block* 被赋予一个唯一的名称，派生的模板可以在提供其内容时进行引用。

通过从基础模板 *base.html* 继承 HTML 元素，我现在可以简化模板 *index.html* 了：

```python
{% extends "base.html" %}

{% block content %}
    {% for i in username %}
            <h1>Hello, {{ i }}!</h1>
    {% endfor %}
{% endblock %}

```

自从基础模板 *base.html* 接手页面的布局之后，我就可以从 *index.html* 中删除所有这方面的元素，只留下内容部

分。 `extends` 语句用来建立了两个模板之间的继承关系，这样 Jinja2 才知道当要求呈现 `index.html` 时，需要将其嵌入到 `base.html` 中。 而两个模板中匹配的`block`语句和其名称 `content` ，让Jinja2知道如何将这两个模板合并成在一起。 现在，扩展应用程序的页面就变得极其方便了，我可以创建从同一个基础模板*base.html*继承的派生模板，这就是我让应用程序的所有页面拥有统一外观布局而不用重复编写代码的秘诀。

![1560957406862](assets/1560957406862.png)



模板继承是为了重用模板中的公共内容。一般Web开发中，继承主要使用在网站的顶部菜单、底部。这些内容可以定义在父模板中，子模板直接继承，而不需要重复书写。

- 标签定义的内容

```python
{% block top %} {% endblock %}

```

- 相当于在父模板中挖个坑，当子模板继承父模板时，可以进行填充。
- 子模板使用 extends 指令声明这个模板继承自哪个模板
- 父模板中定义的块在子模板中被重新定义，在子模板中调用父模板的内容可以使用 super()

####  父模板

- base.html

```python
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    {% if title %}
        <title>个人主页 - {{ username }}</title>
    {% else %}
        <title>欢迎来到个人主页</title>
    {% endif %}
    <style>
        div {
            border: 2px solid;
            height: 100px;

        }

        .nav {
            height: 40px;
        }

        .top {
            background-color: pink;
        }

        .content {
            background-color: pink;
        }

        .bottom {
            background-color: pink;
        }
    </style>
</head>
<body>
{% block top %}
    <div class="top">base 顶部菜单</div>
{% endblock top %}
<br>
{% block content %}
    <dic class="content">base 内容部分</dic>
{% endblock content %}
<br>
{% block bottom %}
    <div class="bottom">base 底部</div>
{% endblock bottom %}
</body>
</html>

```

####  子模板

- extends指令声明这个模板继承自哪

```python
{% extends 'base.html' %}
{% block content %}
 需要填充的内容
{% endblock content %}

```

- 模板继承使用时注意点：
  - 不支持多继承
  - 为了便于阅读，在子模板中使用 extends 时，尽量写在模板的第一行。
  - 不能在一个模板文件中定义多个相同名字的 block 标签。
  - 当在页面中使用多个 block 标签时，建议给结束标签起个名字，当多个 block 嵌套时，阅读性更好。

####  包含

Jinja2 模板中，除了宏和继承，还支持一种代码重用的功能，叫包含(Include)。它的功能是将另一个模板整个加载到当前模板中，并直接渲染。

- templates/header.html 的使用

```python
{% include 'header.html' %}

```

文件：header.html

```
<div class="nav">
    头部部分
</div>

```

包含在使用时，如果包含的模板文件不存在时，程序会抛出 **TemplateNotFound** 异常，可以加上 `ignore missing` 关键字。如果包含的模板文件不存在，会忽略这条include语句。

- include 的使用加上关键字ignore missing

```python
{% include 'header.html' ignore missing %}

```

**小结** 

- 宏(Macro)、继承(Block)、包含(include)均能实现代码的复用。
- 继承(Block)的本质是代码替换，一般用来实现多个页面中重复不变的区域。
- 宏(Macro)的功能类似函数，可以传入参数，需要定义、调用。
- 包含(include)是直接将目标模板文件整个渲染出来。

在模板中，可能会遇到以下情况：

- 多个模板具有完全相同的顶部和底部内容
- 多个模板中具有相同的模板代码内容，但是内容中部分值不一样
- 多个模板中具有完全相同的 html 代码块内容

像遇到这种情况，可以使用 JinJa2 模板中的 宏、继承、包含来进行实现

###  静态文件

静态文件（static files）和我们的模板概念相反，指的是内容不需要动态生成的文件。比如图片、CSS 文件和 JavaScript 脚本等。

python代码

```
@app.route('/ex_static')
def ex_static():
    name = '正心'
    messages = [
        {'title': '有位非常漂亮的女同事，有天起晚了没有时间化妆便急忙冲到公司。结果那天她被记旷工了……'},
        {'title': '失恋算个啥？轻轻的，你走吧，千万别后悔，因为只要你一挥手，就会发现，已经有那等不及的意中人，正偷偷摸摸拉你的手！'},
        {'title': '世界上最有钱的人是奥特曼，因为所有取款机上都印着他名字的缩写“ATM” 。'},
        {'title': '所谓爱情也不过是：看上了，追求了，好上了，开心了；不久后，腻了，吵了，淡了，散了。'},
        {'title': '据说失眠的同学盯着看十分钟就能睡着了。'},
        {'title': '才知道，朋友就像人民币，有真、也有假，可惜我不是验钞机。'},
        {'title': '回想这几年，尝尽辛酸艰难。从一开始什么都没有到30万，从30万到200万，从200万、300万到现在的1300万！不是炫耀，我只是想通过我自己的经历告诉我的朋友们——手机像素越高，拍的照片越清晰！'},
    ]
    return render_template('static.html', name=name, messages=messages)

```

html代码

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    {#   生成静态文件 URL #}
    <link rel="stylesheet" href="/static/style.css">
</head>
<body>
<h2>
    {#    添加图片#}
    <img class="user_ico" src="/static/a.jpg">
    正心-语录
</h2>
<p>{{ messages|length }}条留言</p>
<ul class="message-list">
    {% for msg in messages %}
        <li>{{ msg['title'] }}</li>
    {% endfor %}
</ul>
</body>
</html>

```

static/style.css：定义页面样式

```css
body {
    margin: auto;
    max-width: 580px;
    font-size: 14px;
    font-family: Helvetica, Arial, sans-serif;
}

.user_ico {
    width: 40px;
}

.message-list {
    list-style-type: none;
    padding: 0;
    margin-bottom: 10px;
    box-shadow: 0 2px 5px 0 rgba(0, 0, 0, 0.16), 0 2px 10px 0 rgba(0, 0, 0, 0.12);
}

.message-list li {
    padding: 12px 24px;
    border-bottom: 1px solid #ddd;
}

```



####  生成静态文件 URL

在 HTML 文件里，引入这些静态文件需要给出资源所在的 URL。为了更加灵活，这些文件的 URL 可以通过 Flask 提供的 `url_for()` 函数来生成。

我们学习过 `url_for()` 函数的用法，传入端点值（视图函数的名称）和参数，它会返回对应的 URL。对于静态文件，需要传入的端点值是 `static`，同时使用`filename` 参数来传入相对于 static 文件夹的文件路径。



**提示** 在 Python 脚本里，`url_for()` 函数需要从 `flask` 包中导入，而在模板中则可以直接使用，因为 Flask 把一些常用的函数和对象添加到了模板上下文（环境）里。



**由 url_for 生成静态url**

templates/static.html：引入 CSS 文件

```html
<link rel="stylesheet" href="{{ url_for('static', filename='style.css') }}" type="text/css">

```

最后要为对应的元素设置 `class` 属性值，以便和对应的 CSS 定义关联起来：

*templates/static.html：添加 class 属性*

```html
<img alt="user_ico" class="user_ico" src="{{ url_for('static', filename='a.jpg') }}">

```

花括号部分的调用会返回 `/static/a.jpg`。



最终的页面如下图所示：

![1561126508185](assets/1561126508185.png)

####  自定义错误页面

当程序返回错误响应时，会渲染一个默认的错误页面。默认的错误页面太简单了，而且和其他页面的风格不符， 导致用户看到这样的页面时往往会不知所措。我们可以自定义错误页面。

错误处理函数和视图函数很相似，返回值将会作为响应的主体。并在其中为最常见的404和500错误创建了模板文件，表示404 页面的 404.html 模板内容。

> 404页面模板 

```
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
        <title>网页没有被找到</title>
</head>
<body>
<h1>页面不见了</h1>
<p>你已经迷失了回家的方向....</p>
</body>
</html>

```

错误处理函数需要附加app.errorhandler()装饰器，并传入错误状态 码作为参数。当发生错误时，对应的错误处理函数会被调用，它的返回值会作为错误响应的主体。代码清单3-13是用来捕捉404错误的错误处理器。 

> 404错误处理器 

```
from flask import Flask, render_template, flash

app = Flask(__name__)
app.secret_key = '123456'


@app.errorhandler(404)
def error404(e):
    flash('请重新刷新页面试试')
    flash('刷新也没用？检查一下代码哪里错了')
    flash('代码没错？重启pycharm试试')
    flash('重启pycharm没有？重启电脑试试')
    flash('重启电脑没用？重装系统试试')
    return render_template('404.html'), 404


```

错误处理函数接收异常对象作为参数，内置的异常对象提供了下列常用属性，如表3-7所示

> Werkzeug 内置的 HTTP 异常类的常用属性

| 属 性           | 说 明                                                        |
| --------------- | ------------------------------------------------------------ |
| **code**        | 状态码                                                       |
| **name**        | 原因短语                                                     |
| **description** | 错误描述，另外使用 get_description() 方法还可以获取 HTML 格式的错误 描述代码 |



###  @自定义过滤器

如果内置的过滤器不能满足你的需要，还可以添加自定义过滤器。使用 app.template_filter（）装饰器可以注册自定义过滤器

- 通过Flask应用对象的 **add_template_filter** 方法
- 通过装饰器来实现自定义过滤器

**重要：自定义的过滤器名称如果和内置的过滤器重名，会覆盖内置的过滤器。**

####  需求：添加列表反转的过滤器

#####  方式一

通过调用应用程序实例的 add_template_filter 方法实现自定义过滤器。该方法第一个参数是函数名，第二个参数是自定义的过滤器名称：

```python
@app.template_filter('sort_reverse')
def sort_reverse(li):
    # 通过原列表创建一个新列表
    temp_li = list(li)
    # 将新列表进行返转
    temp_li.reverse()
    return temp_li

```

#####  方式二

用装饰器来实现自定义过滤器。装饰器传入的参数是自定义的过滤器名称。

```python
def sort_reverse(li):
    # 通过原列表创建一个新列表
    temp_li = list(li)
    # 将新列表进行返转
    temp_li.reverse()
    return temp_li

app.add_template_filter(do_listreverse, 'lireverse')

```

在 html 中使用该自定义过滤器

```html
<br/> my_array 原内容：{{ [3, 4, 2, 1, 7, 9]  }}
<br/> my_array 反转：{{ [3, 4, 2, 1, 7, 9]  | sort_reverse }}

```

运行结果

```
my_array 原内容：[3, 4, 2, 1, 7, 9] 
my_array 反转：[9, 7, 1, 2, 4, 3]

```

附录：

Jinja2常用内置过滤器

| 过滤器                                                       | 说 明                                                        |
| ------------------------------------------------------------ | ------------------------------------------------------------ |
| default (value, default_value=u", boolean=False)             | 设置默认值，默认值作为参数传入，别名为d                      |
| escape(s)                                                    | 转义HTML文本，别名为e                                        |
| first (seq)                                                  | 返回序列的第一个元素                                         |
| last(seq)                                                    | 返回序列的最后一个元素                                       |
| length(object)                                               | 返回变量的长度                                               |
| random(seq)                                                  | 返回序列中的随机元素                                         |
| safe( value)                                                 | 将变量值标记为安全，避免转义                                 |
| trim(value)                                                  | 清除变量值前后的空格                                         |
| max(value, case_sensitive=False, attribute=None)             | 返回序列中的最大值                                           |
| min(value, case_sensitive=False, attribute=None)             | 返回序列中的最小值                                           |
| unique(value, case_sensitive=F alse, attribute=None)         | 返回序列中的不重复的值                                       |
| striptags(value)                                             | 清除变量值内的HTML标签                                       |
| urlize (value, trim_url_limit=None, nofbllow=False, target=None, rel=None) | 将URL文本转换为可单击的HTML链接                              |
| wordcount (s)                                                | 计算单词数量                                                 |
| tojson(value, indent=None)                                   | 将变量值转换为JSON格式                                       |
| truncate(s, length=255, killwords=False,end-...', leeway=None) | 截断字符串，常用于显示文章摘要，length参数设置截断的长度, killwords参数设置是否截断单词，end参数设置结尾的符号 |

这里只列出了一部分常用的过滤器，完整的列表请 [访问]( http://jinja.pocoo.org/docs/2.10/templates/#builtin-filters) 查看。
