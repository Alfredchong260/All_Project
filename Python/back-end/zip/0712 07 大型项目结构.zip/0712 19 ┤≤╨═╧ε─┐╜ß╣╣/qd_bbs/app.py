from flask import Flask, render_template, send_file, request

app = Flask(__name__)


@app.route('/')
def index():
    return render_template('bbs/index.html')


@app.route('/article')
def article():
    return render_template('bbs/article.html')


@app.route('/profile')
def profile():
    return render_template('bbs/profile.html')


@app.errorhandler(404)
def not_fund(e):
    return render_template('bbs/404.html')


@app.route('/user')
def user_view():
    return render_template('user/user.html')


@app.route('/user/base_info')
def user_base_info():
    return render_template('user/base_info.html')


@app.route('/user/followed')
def followed():
    return render_template('user/followed.html')


@app.route('/user/collection')
def collection():
    return render_template('user/collection.html')


@app.route('/user/articles')
def articles_view():
    return render_template('user/articles.html')


@app.route('/user/article_release')
def article_release_view():
    return render_template('user/article_release.html')


@app.route('/admin/login')
def admin_login_view():
    return render_template('admin/login.html')


@app.route('/admin')
@app.route('/admin/index')
def admin_index_view():
    return render_template('admin/main.html')


@app.route('/admin/users')
def admin_users_view():
    return render_template('admin/users.html')


@app.route('/admin/articles')
def admin_articles_view():
    return render_template('admin/articles.html')


@app.route('/admin/types')
def admin_article_types_view():
    return render_template('admin/article_types.html')


@app.route('/admin/article_review')
def admin_article_review_view():
    article_id = request.args.get('article_id')
    return render_template('admin/article_review.html')


@app.route('/admin/article_edit')
def admin_article_edit_view():
    article_id = request.args.get('article_id')
    return render_template('admin/article_edit.html')


@app.route('/passport/getCaptcha')
def get_captcha_view():
    return send_file('static/images/admin/getCaptcha.png')


@app.route('/demo/table/user/')
def table_data():
    return {
        "code": 0,
        "msg": "",
        "count": 1000,
        "data": [
            {"id": 10000, "username": "user-0", "sex": "女", "city": "城市-0", "sign": "签名-0", "experience": 255,
             "logins": 24, "phone": 82830700, "classify": "作家", "score": 57},
            {"id": 10001, "username": "user-1", "sex": "男", "city": "城市-1", "sign": "签名-1", "experience": 884,
             "logins": 58, "phone": 64928690, "classify": "词人", "score": 27},
            {"id": 10002, "username": "user-2", "sex": "女", "city": "城市-2", "sign": "签名-2", "experience": 650,
             "logins": 77, "phone": 6298078, "classify": "酱油", "score": 31},
            {"id": 10003, "username": "user-3", "sex": "女", "city": "城市-3", "sign": "签名-3", "experience": 362,
             "logins": 157, "phone": 37117017, "classify": "诗人", "score": 68},
            {"id": 10004, "username": "user-4", "sex": "男", "city": "城市-4", "sign": "签名-4", "experience": 807,
             "logins": 51, "phone": 76263262, "classify": "作家", "score": 6},
            {"id": 10005, "username": "user-5", "sex": "女", "city": "城市-5", "sign": "签名-5", "experience": 173,
             "logins": 68, "phone": 60344147, "classify": "作家", "score": 87},
            {"id": 10006, "username": "user-6", "sex": "女", "city": "城市-6", "sign": "签名-6", "experience": 982,
             "logins": 37, "phone": 57768166, "classify": "作家", "score": 34},
            {"id": 10007, "username": "user-7", "sex": "男", "city": "城市-7", "sign": "签名-7", "experience": 727,
             "logins": 150, "phone": 82030578, "classify": "作家", "score": 28},
            {"id": 10008, "username": "user-8", "sex": "男", "city": "城市-8", "sign": "签名-8", "experience": 951,
             "logins": 133, "phone": 16503371, "classify": "词人", "score": 14},
            {"id": 10009, "username": "user-9", "sex": "女", "city": "城市-9", "sign": "签名-9", "experience": 484,
             "logins": 25, "phone": 86801934, "classify": "词人", "score": 75}
        ]}


@app.route('/demo/table/news/')
def table_data_news():
    return {
        "code": 0,
        "msg": "",
        "count": 1000,
        "data": [
            {"id": 10001, "title": "日本史上最大IPO之一要来了：软银计划将手机业务分拆上市", "release_time": "2018-3-5 21:39:05", "status": "已通过",
             "option": "签名-0"},
            {"id": 10002, "title": "日本史上最大IPO之一要来了：软银计划将手机业务分拆上市", "release_time": "2018-3-5 21:39:05", "status": "已通过",
             "option": "签名-0"},
            {"id": 10003, "title": "日本史上最大IPO之一要来了：软银计划将手机业务分拆上市", "release_time": "2018-3-5 21:39:05", "status": "已通过",
             "option": "签名-0"},
            {"id": 10004, "title": "日本史上最大IPO之一要来了：软银计划将手机业务分拆上市", "release_time": "2018-3-5 21:39:05", "status": "已通过",
             "option": "签名-0"},
            {"id": 10005, "title": "日本史上最大IPO之一要来了：软银计划将手机业务分拆上市", "release_time": "2018-3-5 21:39:05", "status": "已通过",
             "option": "签名-0"},
            {"id": 10006, "title": "日本史上最大IPO之一要来了：软银计划将手机业务分拆上市", "release_time": "2018-3-5 21:39:05", "status": "已通过",
             "option": "签名-0"},
            {"id": 10007, "title": "日本史上最大IPO之一要来了：软银计划将手机业务分拆上市", "release_time": "2018-3-5 21:39:05", "status": "已通过",
             "option": "签名-0"},
            {"id": 10008, "title": "日本史上最大IPO之一要来了：软银计划将手机业务分拆上市", "release_time": "2018-3-5 21:39:05", "status": "已通过",
             "option": "签名-0"},
            {"id": 10009, "title": "日本史上最大IPO之一要来了：软银计划将手机业务分拆上市", "release_time": "2018-3-5 21:39:05", "status": "已通过",
             "option": "签名-0"},
            {"id": 10010, "title": "日本史上最大IPO之一要来了：软银计划将手机业务分拆上市", "release_time": "2018-3-5 21:39:05", "status": "已通过",
             "option": "签名-0"},
        ]}


@app.route('/demo/table/type/')
def table_data_type():
    return {
        "code": 0,
        "msg": "",
        "count": 1000,
        "data": [
            {"id": 10001, "title": "基础"},
            {"id": 10002, "title": "进阶"},
            {"id": 10003, "title": "爬虫"},
            {"id": 10004, "title": "数据分析"},
            {"id": 10005, "title": "全栈开发"},
        ]
    }
