## 数据库

入数据库是大多数动态Web程序的基础设施，只要你想把数据存储下来，就离不开数据库。我们这里提及的数据库（Database）指的是由存储 数据的单个或多个文件组成的集合，它是一种容器，可以类比为文件柜。 而人们通常使用数据库来表示操作数据库的软件，这类管理数据库的软件被称为数据库管理系统（DBMS，Database Management System），常见的 DBMS 有MySQL、PostgreSQL、SQLite、MongoDB等。

### SQLAlchemy(ORM魔法 )

在 Web 应用里使用原生 SQL 语句操作数据库主要存在下面两类问题： 

- 手动编写 SQL 语句比较乏味，而且视图函数中加入太多 SQL 语句会降低代码的易读性。另外还会容易出现安全问题，比如 SQL 注入。 
- 常见的开发模式是在开发时使用简单的 SQLite，而在部署时切换到 MySQL 等更健壮的 DBMS。但是对于不同的 DBMS，我们需要使用不同的 Python 接口库，这让 DBMS 的切换变得不太容易。 
- 使用ORM可以避免SQL注入问题，但你仍然需要对传入的查询参数进行验证。在执行原生SQL语句时也要注意避免使用字符串拼接 或字符串格式化的方式传入参数。 

使用ORM可以很大程度上解决这些问题。它会自动帮你处理查询参数的转义，尽可能地避免SQL注入的发生。另外，它为不同的DBMS提供统 一的接口，让切换工作变得非常简单。ORM扮演翻译的角色，能够将我们 的Python语言转换为DBMS能够读懂的SQL指令，让我们能够使用Python来操控数据库。 

尽管ORM非常方便，但是自己编写SQL代码可以获得更大的灵活性和性能优势。就像是使用IDE一样，ORM对初学者来说非常方便，但进阶以后你也许会想要自己掌控一切。

ORM把底层的SQL数据实体转化成高层的Python对象，这样一来，你甚至不需要了解SQL，只需要通过Python代码即可完成数据库操作，ORM 主要实现了三层映射关系： 

- 表 --> Python类。
- 字段（列） --> 类属性。
- 记录（行） --> 类实例。 

![img](assets/timg.jpg)

比如，我们要创建一个 contacts 表来存储留言，其中包含用户名称和电话号码两个字段。在SQL中，下面的代码用来创建这个表： 

```sql
CREATE TABLE contacts( name varchar(100) NOT NULL, phone_number varchar(32));
```

如果使用ORM，我们可以使用类似下面的Python类来定义这个表： 

```python
import sqlalchemy as sqa
from sqlalchemy.ext.declarative import declarative_base

# 创建对象的基类:
Base = declarative_base()


class Contact(Base):
    __tablename__ = 'contacts'
    name = sqa.Column(sqa.String(100), nullable=False)
    phone_number = sqa.Column(sqa.String(32))

```

要向表中插入一条记录，需要使用下面的SQL语句： 

```sql
INSERT INTO contacts(name, phone_number) VALUES('zhengxin', '123456');
```

使用 ORM 则只需要创建一个 Contact 类的实例，传入对应的参数表示各个列的数据即可。下面的代码和使用上面的SQL语句效果相同： 

```python
contact = Contact(name='zhengxin', phone_number='123456')
```

除了便于使用，ORM还有下面这些优点： 

- 灵活性好。你既能使用高层对象来操作数据库，⼜⽀持执行原生SQL 语句。
- 提升效率。从高层对象转换成原生SQL会牺牲一些性能，但这微不足道的性能牺牲换取的是巨大的效率提升。 
- 可移植性好。ORM通常⽀持多种DBMS，包括MySQL、 PostgreSQL、Oracle、SQLite等。你可以随意更换DBMS，只需要稍微改动少量配置。 

使用 Python 实现的 ORM 有 SQLAlchemy、PonyORM等。其中 SQLAlchemy是Python社区使用最⼴泛的ORM之一

### Flask-SQLAlchemy

扩展 Flask-SQLAlchemy 集成了SQLAlchemy，它简化了连接数据库服务器、管理数据库操作会话等各类工作，让Flask中的数据处理体验变得更加轻松。

```
$ pip install flask-sqlalchemy
```

下面在示例程序中实例化Flask-SQLAlchemy提供的SQLAlchemy类， 传入程序实例app，以完成扩展的初始化： 

```python
from flask import Flask 
from flask_sqlalchemy import SQLAlchemy 
app = Flask(__name__) 
db = SQLAlchemy(app)
```

为了便于使用，我们把实例化扩展类的对象命名为db。这个db对象代 表我们的数据库，它可以使用Flask-SQLAlchemy提供的所有功能。 

虽然我们要使用的大部分类和函数都由SQLAlchemy提供，但在Flask- SQLAlchemy中，大多数情况下，我们不需要手动从SQLAlchemy导入类或函数。在sqlalchemy和sqlalchemy.orm模块中实现的类和函数，以及其他几 个常用的模块和对象都可以作为db对象的属性调用。当我们创建这样的调用时，Flask-SQLAlchemy会自动把这些调用转发到对应的类、函数或模 块。

#### 连接数据库服务器 

DBMS通常会提供数据库服务器运行在操作系统中。要连接数据库服 务器，首先要为我们的程序指定数据库URI（Uniform Resource Identifier，统一资源标识符）。数据库URI是一串包含各种属性的字符串，其中包含 了各种用于连接数据库的信息。 

URI代表统一资源标识符，是用来标示资源的一组字符串。URL是它 的⼦集。在大多数情况下，这两者可以交替使用。 表2是一些常用的DBMS及其数据库URI格式示例。 

| DBMS             | URI                                                          |
| ---------------- | ------------------------------------------------------------ |
| PostgreSQL       | postgresql://username:password@host/databasename             |
| MySQL            | mysql://username:password@host/databasename                  |
| Oracle           | oracle ://username:password@host:port/sidname                |
| SQLite (UNIX)    | sqlite:////absolute/path/to/foo.db                           |
| SQLite (Windows) | sqlite:///absolute\\path\\to\\foo.db 或 r'sqlite:///absolute\path\to\foo.db', |
| SQlite (内存型)  | sqlite:///或 sqlite:///:memory:                              |

数据库的URI通过配置变量 SQLALCHEMY_DATABASE_URI 设置，默认为SQLite内存型数据库 （sqlite：///：memory：）。SQLite是基于文件的DBMS，所以只需要指定数据库文件的绝对路径。

```python
import click
from flask import Flask
# 1. 导入 flask-sql alchemy 中的 SQLAlchemy 对象
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)


class Config:
    # 数据库链接配置参数
    SQLALCHEMY_DATABASE_URI = 'sqlite:///data.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False


# 2. 提前加载数据库配置
app.config.from_object(Config)

# 3. 创建数据库链接对象
db = SQLAlchemy()

# 4. 将数据库操作对象与 flask app 进行绑定
db.init_app(app)

```



> SQLite的数据库URI在Linux或macOS系统下的斜线数量是4个；在 Windows系统下的URI中的斜线数量为3个。内存型数据库的斜线固定为3 个。 
>
> SQLite数据库文件名不限定后缀，常用的命名方式有foo.sqlite， foo.db，或是注明SQLite版本的foo.sqlite3。 

设置好数据库URI后，在Python Shell中导入并查看db对象会获得下面 的输出： 

```python
>>> from app import db 
>>> db 
<SQLAlchemy engine=sqlite:///Path/to/your/data.db>
```

安装并初始化 Flask-SQLAlchemy 后，启动程序时会看到命令行下有一行警告信息。这是因为Flask-SQLAlchemy建议你设置 SQLALCHEMY_TRACK_MODIFICATIONS 配置变量，这个配置变量决定是否追踪对象的修改，这用于Flask-SQLAlchemy 的事件通知系统。这个配置键的默认值为None，如果没有特殊需要，我们可以把它设为False来关闭警告信息： 

```python
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
```

#### 定义数据库模型 

用来映射到数据库表的 Python 类通常被称为数据库模型（model），一 个数据库模型类对应数据库中的一个表。定义模型即使用Python类定义表模式，并声明映射关系。所有的模型类都需要继承 Flask-SQLAlchemy 提供 的 db.Model 基类。

本章的示例程序是一个笔记程序，笔记保存到数据库中，你可以通过程序查询、添加、更新和删除笔记。我们定义一个 Students 模型类，用来存储笔记。 

```python
# 5. 创建数据库模型
class Students(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(length=20))
    math = db.Column(db.Integer)
    chinese = db.Column(db.Integer)
    english = db.Column(db.Integer)

```

在上面的模型类中，表的字段（列）由db.Column类的实例表示，字段 的类型通过Column类构造方法的第一个参数传入。在这个模型中，我们创 建了一个类型为db.Integer的id字段和类型为db.Text的body列，分别存储整 型和文本。常用的SQLAlchemy字段类型如下表所示。 

> SQLAlchemy常用的字段类型 

| **字**	**段** | **说**	**明**                             |
| ---------------- | -------------------------------------------- |
| Integer          | 整数                                         |
| String           | 字符串，可选参数length可以用来设置最大长度   |
| Text             | 较长的Unicode文本                            |
| Date             | 日期，存储Python的datetime.date对象          |
| Time             | 时间，存储Python的datetime.time对象          |
| DateTime         | 时间和日期，存储Python的datetime对象         |
| Interval         | 时间间隔，存储Python的datetime.timedelta对象 |
| Float            | 浮点数                                       |
| Boolean          | 布尔值                                       |
| PickleType       | 存储Pickle列化的Python对象                   |
| LargeBinary      | 存储任意二进制数据                           |

字段类型一般直接声明即可，如果需要传入参数，可以添加括号。对于类似String的字符串列，有些数据库会要求限定长度，因此最好为其指定长度。虽然使用Text类型可以存储相对灵活的变长文本，但从性能上考虑，我们仅在必须的情况下使用Text类型，比如用户发表的文章和评论等不限长度的内容。 

注意当你在数据库模型类中限制了字段的长度后，在接收对应数据的表单类字段里，也需要使用Length验证器来验证用户的输入数据。 默认情况下，Flask-SQLAlchemy会根据模型类的名称生成一个表名称，生成规则如下： 

```
Message --> message # 单个单词转换为⼩写 
FooBar --> foo_bar # 多个单词转换为⼩写并使用下划线分隔

```

Note类对应的表名称即note。如果你想自己指定表名称，可以通过定 义 `__tablename__` 属性来实现。字段名默认为类属性名，你也可以通过字段 类构造方法的第一个参数指定，或使用关键字name。根据我们定义的Note 模型类，最终将生成一个note表，表中包含id和body字段。 

除了name参数，实例化字段类时常用的字段参数如表5-4所示。 

> 常用的SQLAlchemy字段参数 

| 参数名      | 说	明                                          |
| ----------- | ------------------------------------------------- |
| primary key | 如果设为True,该字段为主键                         |
| unique      | 如果设为True,该字段不允许出现重复值               |
| index       | 如果设为True，为该字段创建索引，以提高査询效率    |
| nullable    | 确定字段值可否为空，值为True或False，默认值为True |
| default     | 为字段设置默认值                                  |

在实例化字段类时，通过把参数primary_key设为True可以将其定义为主键。在我们定义的Note类中，id字段即表的主键（primary key）。主键是每一条记录（行）独一无二的标识，也是模型类中必须定义的字段，一 般命名为id或pk。 

#### 创建数据库和表 

如果把数据库（文件）看作一个仓库，为了方便取用，我们需要把货物按照类型分别放置在不同货架上，这些货架就是数据库中的表。创建模型类后，我们需要手动创建数据库和对应的表，也就是我们常说的建库和建表。这通过对我们的 db 对象调用 create_all() 方法实现： 

```
$ flask shell 
>>> from app import db 
>>> db.create_all() 
```

如果模型类定义在单独的模块中，那么必须在调用 db.create_all()方法前导入相应模块，以便让SQLAlchemy获取模型类被创建时生成的表信息，进而正确生成数据表。

数据库和表一旦创建后，之后对模型的改动不会自动作用到实际的表中。比如，在模型类中添加或删除字段，修改字段的名称和类型，这时再次调用 create_all() 也不会更新表结构。如果要使改动生效，最简单的方式是调用 db.drop_all() 方法删除数据库和表，然后再调用 db.create_all() 方法创建，后面会具体介绍。 



**自定义用于创建数据库和表的flask命令 ** 

我们也可以自己实现一个自定义flask命令完成这个工作 

```python
import click 


@app.cli.command()
def init_db():
    """创建数据库"""
    db.create_all()
    click.echo('初始化数据库。')
```

在命令行下输入flask inintdb即可创建数据库和表： 

```shell
$ flask initdb
```

对于示例程序来说，这会在database目录下创建一个data.db文件。 



### 数据库操作 

数据库操作主要是 CRUD，即Create（创建）、Read（读取/ 查询）、Update（更新）和Delete（删除）。 

Flask-SQLAlchemy 自动帮我们创建会话，可以通过 db.session 属性获取

#### CRUD 

这一节我们会演示 CRUD 操作。

默认情况下，Flask- SQLAlchemy 会自动为模型类生成一个 `__repr__()` 方法。 当在 Python Shell 中调用模型的对象时，`__repr__()` 方法会返回一条类 似“<模型类名主键值>”的字符串，比如 <Note 2>。为了便于实际操作测 试，示例程序中，所有的模型类都重新定义了 `__repr__()`方法，返回一些更有用的信息

```python
class Students(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(length=20))
    math = db.Column(db.Integer, default=0)
    chinese = db.Column(db.Integer)
    english = db.Column(db.Integer)

```

##### insert

添加一条新记录到数据库主要分为三步：

1）创建Python对象（实例化模型类）作为一条记录。 

2）添加新创建的记录到数据库会话。 

3）提交数据库会话。 

下面的示例向数据库中添加了一条数据： 

```python
@app.cli.command()
def create():
    """新增数据"""
    # 使用类对象创建一个实例对象（一条数据）
    stu1 = Students(name='张三', math=60, chinese=60, english=60)
    # 添加一条数据
    db.session.add(stu1)
    # 提交数据
    db.session.commit()
    print(stu1.id)

```

在这个示例中，我们首先从app模块导入db对象和Note类，然后分别创 建三个Note实例表示三条记录，使用关键字参数传入字段数据。

我们的 Students 类继承自db.Model基类，db.Model基类会为Note类提供一个构造函数，接收匹配类属性名称的参数值，并赋值给对应的类属性，所以我们不需要自己在 Students 类中定义构造方法。接着我们调用add()方法把这三个 Students 对象添加到会话对象db.session中，最后调用commit()方法提交会 话。 

除了依次调用add()方法添加多个记录，也可以使用add_all()一次添加包含所有记录对象的列表。 

你可能注意到了，我们在创建模型类实例的时候并没有定义id字段的 数据，这是因为主键由SQLAlchemy管理。模型类对象创建后作为临时对 象（transient），当你提交数据库会话后，模型类对象才会转换为数据库记录写入数据库中，这时模型类对象会自动获得id值： 

```python
>>> stu1.id 
1 


```



最后添加多条数据给后面使用

```
stu2 = Students(name='李四', math=65, chinese=65, english=65)
stu3 = Students(name='王五', math=70, chinese=70, english=70)
stu4 = Students(name='正心', math=100, chinese=100, english=100)
db.session.add(stu2)
db.session.add(stu3)
db.session.add(stu4)
db.session.commit()

```



##### Read 

我们已经知道了如何向数据库里添加记录，那么如何从数据库里取回 数据呢？使用模型类提供的query属性附加调用各种过滤方法及查询方法可 以完成这个任务。 

一般来说，一个完整的查询遵循下面的模式： 

```
<模型类>.query.<过滤方法>.<查询方法>

```

![image-20211023163512195](assets/image-20211023163512195.png)

从某个模型类出发，通过在query属性对应的Query对象上附加的过滤 方法和查询函数对模型类对应的表中的记录进行各种筛选和调整，最终返 回包含对应数据库记录数据的模型类实例，对返回的实例调用属性即可获 取对应的字段数据。 

如果你执行了上面⼩节里的操作，我们的数据库现在一共会有三条记录

| id   | name | math | chinese | english |
| ---- | ---- | ---- | ------- | ------- |
| 1    | 张三 | 60   | 60      | 60      |
| 2    | 李四 | 65   | 65      | 65      |
| 3    | 王五 | 70   | 70      | 70      |
| 4    | 正心 | 100  | 100     | 100     |

SQLAlchemy提供了许多查询方法用来获取记录

> 常用的SQLAlchemy查询方法 

| 查询方法（触发器）     | 说	明                                                     |
| ---------------------- | ------------------------------------------------------------ |
| all()                  | 返回包含所有查询记录的列表                                   |
| first()                | 返回查询的第一条记录，如果未找到，则返回None                 |
| one()                  | 返回第一条记录，旦仅允许有一条记录。如果记录数量大于1或小于1，则拋出错误 |
| get(ident)             | 传入主键值作为参数，返回指定主键值的记录，如果未找到，则返回None |
| count()                | 返回查询结果的数量                                           |
| one_or_none()          | 类似one()，如果结果数量不为1，返回None                       |
| first_or_404()         | 返回查询的第一条记录，如果未找到，则返回404错误响应          |
| get_or_404(ident)      | 传人主键值作为参数，返回指定主键值的记录，如果未找到，则返回404错误响应 |
| paginate()             | 返回一个Pagination对象，可以对记录进行分页处理               |
| with_parent( instance) | 传人模型类实例作为参数，返回和这个实例相关联的对象，后面会详细介绍 |

first_or_404()、get_or_404() 以及 paginate() 方法是 Flask-SQLAlchemy 附加的查询方法。 

下面是对 Note 类进行查询的几个示例。all() 返回所有记录： 

```
>>> Students.query.all()
[<Students 张三>, <Students 李四>, <Students 王五>, <Students 正心>]

```

first() 返回第一条记录： 

```
>>> Students.query.first()
>>> <Students 张三>

```

get() 返回指定主键值（id字段）的记录： 

```
>>> stu2 = Students.query.get(2)
>>> stu2 
<Students 李四>

```

count()返回记录的数量： 

```
>>> Students.query.count() 
4
```

SQLAlchemy还提供了许多过滤方法，使用这些过滤方法可以获取更 精确的查询，比如获取指定字段值的记录。对模型类的query属性存储的 Query对象调用过滤方法将返回一个更精确的Query对象（后面我们简称为 查询对象）。因为每个过滤方法都会返回新的查询对象，所以过滤器可以 叠加使用。在查询对象上调用前面介绍的查询方法，即可获得一个包含过 滤后的记录的列表。常用的查询过滤方法如表5-7所示。 

完整的查询方法和过滤方法列表 在http://docs.sqlalchemy.org/en/latest/orm/query.html 可以看到

| 查询过滤器     | 说	明                                                     |
| -------------- | ------------------------------------------------------------ |
| filter_by()    | 使用指定规则过滤记录（以关键字表达式的形式），返回新产生的查洵对象 |
| filter()       | 使用指定的规则过滤记录，返回新产生的查询对象                 |
| order_by()     | 根据指定条件对记录进行排序，返回新产生的查询对象             |
| limit(limit)   | 使用指定的值限制原查询返回的记录数量，返回新产生的查询对象   |
| group_by()     | 根据指定条件对记录进行分组，返回新产生的查询对象             |
| offset(offset) | 使用指定的值偏移原查询的结果，返回新产生的查询对象           |

 filter()方法是最基础的查询方法。它使用指定的规则来过滤记录， 下面的示例在数据库里找出了body字段值为“SHAVE”的记录： 

```
>>> Students.query.filter(Students.name == '正心').first()
<Students 正心>

```

直接打印查询对象或将其转换为字符串可以查看对应的SQL语句： 

```
>>> Students.query.filter(Students.name == '正心').first()

SELECT students.id AS students_id, students.name AS students_name, students.math AS students_math, students.chinese AS students_chinese, students.english AS students_english 
FROM students 
WHERE students.name = ?
 LIMIT ? OFFSET ?

```

在filter()方法中传入表达式时，除了“==”以及表示不等于的“!=”， 其他常用的查询操作符以及使用示例如下所示： 

LIKE： 

```
filter(Students.name.like('%正%'))

```

IN： 

```
filter(Students.name.in_(['张三', '李四'])

```

NOT IN： 

```
.filter(~Students.name.in_(['张三', '李四'])

```

AND： 

```
from sqlalchemy import and_

filter(and_(Students.name == '正心', Students.chinese == 100))

# 或在filter()中加入多个表达式，使用逗号分隔
filter(Students.name == '正心', Students.chinese == 100)

# 或叠加调用多个 filte()/ filte_by() 方法 
filter(Students.name == '正心').filter(Students.chinese == 100)

```

OR： 

```
from sqlalchemy import or_

print(Students.query.filter(or_(Students.name == '正心', Students.chinese == 60)).all())


```

完整的可用操作符列表可以访问 http://docs.sqlalchemy.org/en/latest/core/sqlelement.html#sqlalchemy.sql.operator 查看。

和filter()方法相比，filter_by()方法更易于使用。在filter_by() 方法中，你可以使用关键字表达式来指定过滤规则。更方便的是，你可以 在这个过滤器中直接使用字段名称。下面的示例使用filter_by()过滤器完 成了同样的任务： 

```
>>> print(Students.query.filter_by(name='正心').all())
[<Students 正心>]


```

**查询指定字典**

```
# 查询指定字段
print(Students.query.with_entities(Students.name, Students.math).filter_by(name='正心').all())

```



##### Update 

更新一条记录非常简单，直接赋值给模型类的字段属性就可以改变字 段值，然后调用commit()方法提交会话即可。下面的示例改变了一条记 录的body字段的值： 

```
"""更新数据"""
stu4 = Students.query.get(4)
stu4.chinese = 99
db.session.commit()

```

插入新的记录或要将现有的记录添加到会话中时才需要使用 add() 方法，单纯要更新现有的记录时只需要直接为属性赋新值，然后提交会话。

##### Delete 

删除记录和添加记录很相似，不过要把add()方法换成delete()方法，最后都需要调用commit()方法提交修改。下面的示例删除了id（主 键）为2的记录： 

```
"""删除数据"""
stu4 = Students.query.get(4)
db.session.delete(stu4)
db.session.commit()

```

### 在视图函数里操作数据库

在视图函数里操作数据库的方式和我们在 Python Shell 中的练习大致相 同，只不过需要一些额外的工作。

比如把查询结果作为参数传入模板渲染出来，或是获取表单的字段值作为提交到数据库的数据。在这一节，我们 将把上一节学习的所有数据库操作知识运用到一个简单的程序中。这个程序可以让你创建、编辑和删除信息，并在主页列出所有保存后的笔记。

##### Read 

当进入学生信息管理系统时，应该将所有的信息全部展示出来

> 在视图函数中查询数据库记录 并传入模板 

```python
@app.route('/')
def index():
    students = Students.query.all()
    return render_template('index.html', stus=students)

```

在模板中，我们迭代这个 stus 列表，调用 stus对象的body属性（note.body）获取body字段的值。通过length过滤器获取笔记的数量。

```
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>学生信息管理系统</title>
    <style>
        * {margin: 0;padding: 0;}
        table {margin: 100px auto;}
        .footer {width: 500px;margin: 0 auto;}
        .footer a {display: inline-block;width: 20%;text-decoration: none;color: #cccccc;}
        .footer a:hover {color: orange;}
    </style>
</head>
<body>
<div class="table">
    <table border="1" align="center" width="500" cellpadding="2" cellspacing="0">
        <tr>
            <td>姓名</td>
            <td>数学</td>
            <td>语文</td>
            <td>英语</td>
            <td>总分</td>
        </tr>
        {% for stu in stus %}
            <tr>
                <td>{{ stu.name }}</td>
                <td>{{ stu.math }}</td>
                <td>{{ stu.chinese }}</td>
                <td>{{ stu.english }}</td>
                <td>{{ stu.total }}</td>
            </tr>
        {% endfor %}
    </table>
    <div class="footer">
        <span><a href="{{ url_for('insert') }}">新增</a></span>
        <span><a href="{{ url_for('delete') }}">删除</a></span>
        <span><a href="#">修改</a></span> <span>
        <a href="{{ url_for('index') }}">查询</a></span>
    </div>
</div>
</body>
</html>

```



**分页查询** 

参数定义：

- `page` 查询的页数
- `per_page` 每页的条数
- `max_per_page` 每页最大条数，有值时，`per_page` 受它影响
- `error_out` 当值为 True 时，下列情况会报错
  - 当 page 为 1 时，找不到任何数据
  - page 小于 1，或者 per_page 为负数
  - page 或 per_page 不是整数

该方法返回一个分页对象 `Pagination` 

### 字段

- `has_next` 如果下一页存在，返回 True
- `has_prev` 如果上一页存在，返回 True
- `items` 当前页的数据列表
- `next_num` 下一页的页码
- `page` 当前页码
- `pages` 总页数
- `per_page` 每页的条数
- `prev_num` 上一页的页码
- `query` 用于创建此分页对象的无限查询对象。
- `total` 总条数
- `iter_pages(left_edge=2, left_current=2, right_current=5, right_edge=2)`
  迭代分页中的页码，四个参数，分别控制了省略号左右两侧各显示多少页码，在模板中可以这样渲染



```python
# 分页查询
paginate_obj = User.query.paginate(page=1, per_page=20, error_out=False)  # 第一页，每页20条数据。 默认第一页。
# 参数：error_out 设为True表示页数不是int或超过总页数时,会报错,并返回404状态码。 默认True


# 获取总页数
total_page = paginate_obj.pages
```



##### Create 

为了⽀持输入笔记内容，我们先创建一个用于记录信息的表单，如下所示：

```python
from flask_wtf import FlaskForm
from wtforms import StringField,  SubmitField, IntegerField
from wtforms.validators import DataRequired

class Students(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(length=20))
    math = db.Column(db.Integer, default=0)
    chinese = db.Column(db.Integer)
    english = db.Column(db.Integer)

    @property
    def total(self):
        return self.math + self.chinese + self.english

    def __repr__(self):
        return '<Students %s>' % self.name


```

我们创建一个 insert 视图，这个视图负责渲染创建笔记的模板，并处理表单的提交

> 创建新笔记 

```python
@app.route('/insert', methods=['GET', 'POST'])
def insert():
    form = InsertFrom(request.form)
    if form.validate_on_submit():
        stu = Students(
            name=request.form.get('name'),
            math=request.form.get('math'),
            chinese=request.form.get('chinese'),
            english=request.form.get('english'),
        )
        db.session.add(stu)
        db.session.commit()
        return redirect(url_for('index'))
    return render_template('insert.html', form=form)


```

我们先来看看form.validate_on_submit() 返回True时的处理代码。当 表单被提交且通过验证时，我们获取表单字段的数据，然后创建新的实例对象，将表单中的字段的值传入到关系模型对象，最后添加到数据库会话中并提交会话。

这个过程接收用户通过表单提交的数据并保存到数据库中，最后我们使用flash()函数发送提示消息并重定向到index视图。 

> insert.html

```jinja2
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>新增数据</title>
    <style>
        .form {
            width: 500px;
            margin: 100px auto;
        }
    </style>
</head>
<body>
<div class="form">
    <form method="POST" action="{{ url_for('insert') }}">
        {{ form.csrf_token() }}
        <table>
            <tr>
                <td>{{ form.name.label }}</td>
                <td>{{ form.name }}</td>
            </tr>
            <tr>
                <td>{{ form.math.label }}</td>
                <td>{{ form.math }}</td>
            </tr>
            <tr>
                <td>{{ form.chinese.label }}</td>
                <td>{{ form.chinese }}</td>
            </tr>
            <tr>
                <td>{{ form.english.label }}</td>
                <td>{{ form.english }}</td>
            </tr>
        </table>
        {{ form.submit }}
    </form>
</div>
</body>
</html>


```

##### Delete 

在程序中，删除的实现也非常简单，不过这里经常会有一个误区。大 多数人通常会考虑在笔记内容下添加一个删除链接： 

```
<a href="{{ url_for('delete', id=stu.id) }}">删除</a>

```

这个链接指向用来删除笔记的delete_note视图： 

```python
@app.route('/delete')
def delete():
    id_ = request.args.get('id')
    if id_:
        stu = Students.query.get(id_)
        db.session.delete(stu)
        db.session.commit()
        return redirect(url_for('delete'))

    students = Students.query.all()
    return render_template('delete.html', stus=students)

```

> delete.html

```
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>学生信息管理系统</title>
    <style>
        * {margin: 0;padding: 0;}
        table {margin: 100px auto;}
        .footer {width: 500px;margin: 0 auto;}
        .footer a {display: inline-block;width: 20%;text-decoration: none;color: #cccccc;}
        .footer a:hover {color: orange;}
    </style>
</head>
<body>

<div class="table">
    <table border="1" align="center" width="500" height="200" cellpadding="2" cellspacing="0">
        <tr>
            <td>姓名</td>
            <td>数学</td>
            <td>语文</td>
            <td>英语</td>
            <td></td>
        </tr>
        {% for stu in stus %}
            <tr>
                <td>{{ stu.name }}</td>
                <td>{{ stu.math }}</td>
                <td>{{ stu.chinese }}</td>
                <td>{{ stu.english }}</td>
                <td><a href="{{ url_for('delete', id=stu.id) }}">删除</a></td>
            </tr>
        {% endfor %}
    </table>
    <div class="footer">
        <span><a href="{{ url_for('insert') }}">新增</a></span>
        <span><a href="">删除</a></span>
        <span><a href="">修改</a></span>
        <span><a href="">查询</a></span>
    </div>
</div>
</body>
</html>


```



##### Update 

略



### 更新数据库表

模型类（表）不是一成不变的，当你添加了新的模型类，或是在模型 类中添加了新的字段，甚至是修改了字段的名称或类型，都需要更新表。 在前面我们把数据库表类比成盛放货物的货架，这些货架是固定生成的。 当我们在操控程序（DBMS/ORM）上变更了货架的结构时，仓库的货架也 要根据变化相应进行调整。而且，当货架的结构产生变动时，我们还需要 考虑如何处理货架上的货物（数据）。 

当你在数据库的模型中添加了一个新的字段后，比如在Note模型里添 加了一个存储笔记创建时间的timestamp字段。这时你可能想要立刻启动程 序看看效果，遗憾的是，你看到了下面的报错信息： 

```
OperationalError: (sqlite3.OperationalError) no such column: note.timestamp [...]
```

这段错误消息指出note表中没有timestamp列，并在中括号里给出了查 询所对应的SQL原语。之所以会出现这个错误，是因为数据库表并不会随 着模型的修改而自动更新。想想我们之前关于仓库的比喻，仓库里来了一 批新类型的货物，可我们还没为它们安排相应的货架，这当然要出错了。 下面我们会学习如何更新数据库。 

#### 重新生成表 

重新调用create_all（）方法并不会起到更新表或重新创建表的作用。 如果你并不在意表中的数据，最简单的方法是使用drop_all（）方法删除表 以及其中的数据，然后再使用create_all（）方法重新创建： 

```
>>> db.drop_all()
>>> db.create_all()
```

这会清除数据库里的原有数据，请勿在生产环境下使用。

为了方便开发，我们修改initdb命令函数的内容，为其增加一个--drop 选项来⽀持删除表和数据库后进行重建

> ⽀持删除表后重建 

```python
@app.cli.command() 
@click.option('--drop', is_flag=True, help='Create after drop.') 
def initdb(drop): 
    """Initialize the database.""" 
    if drop: 
        click.confirm('This operation will delete the database, do you want to continue?', abort=True) 
        db.drop_all() 
        click.echo('Drop tables.')
    db.create_all()
    click.echo('Initialized database.')

```

在这个命令函数前，我们使用click提供的option装饰器为命令添加了一 个--drop选项，将is_flag参数设为True可以将这个选项声明为布尔值标志 （boolean flag）。--drop选项的值作为drop参数传入命令函数，如果提供了 这个选项，那么drop的值将是True，否则为False。因为添加--drop选项会直 接清空数据库内容，如果需要，也可以通过click.confirm（）函数添加一个 确认提示，这样只有输入y或yes才会继续执行操作。 

现在，执行下面的命令会重建数据库和表： 

```
$ flask initdb --drop
```

当使用SQLite时，直接删除data.db文件和调用 drop_all() 方法效果相同，而且更直接，不容易出错。 





## 数据迁移

### Alembic

https://zhuanlan.zhihu.com/p/90106173



### Flask-Migrate

在开发过程中，需要修改数据库模型，而且还要在修改之后更新数据库。最直接的方式就是删除旧表，但这样会丢失数据。

更好的解决办法是使用数据库迁移框架，它可以追踪数据库模式的变化，然后把变动应用到数据库中。

在Flask中可以使用Flask-Migrate扩展，来实现数据迁移。并且集成到Flask-Script中，所有操作通过命令就能完成。

为了导出数据库迁移命令，Flask-Migrate提供了一个MigrateCommand类，可以附加到flask-script的manager对象上。



首先要在虚拟环境中安装Flask-Migrate。

扩展Flask-Migrate集成了Alembic，提供了一些flask命令来简化迁移工 作，我们将使用它来迁移数据库。Flask-Migrate及其依赖（主要是 Alembic）可以使用pip安装： 

```
$ pip install flask-migrate

```

在程序中，我们实例化Flask-Migrate提供的Migrate类，进行初始化操 作：

```python
from flask import Flask, render_template, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate

app = Flask(__name__)


class Config:
    # 数据库链接配置参数
    SQLALCHEMY_DATABASE_URI = 'sqlite:///data_04.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    # SQLALCHEMY_ECHO = True
    SECRET_KEY = 'secret key'


app.config.from_object(Config)

# 创建数据库链接对象
db = SQLAlchemy()
migrate = Migrate()
db.init_app(app)
migrate.init_app(app, db)


class Students(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(length=20))
    gender = db.Column(db.String(length=20))
    birth = db.Column(db.String(length=20))
    phone = db.Column(db.String(length=20))

    def __repr__(self):
        return '<Students %s>' % self.username


@app.cli.command()
def create():
    """新增数据"""
    from data import students
    for student in students:
        stu = Students()
        for key, value in student.items():
            setattr(stu, key, value)
        db.session.add(stu)
    # 提交数据
    db.session.commit()


```

实例化Migrate类时，除了传入程序实例app，还需要传入实例化Flask- SQLAlchemy提供的SQLAlchemy类创建的db对象作为第二个参数。 

#### 创建迁移环境 

在开始迁移数据之前，需要先使用下面的命令创建一个迁移环境： 

```
# 这个命令会创建migrations文件夹，所有迁移文件都放在里面。
$ flask db init

```

附注 

Flask-Migrate提供了一个命令集，使用db作为命名集名称，它提供的 命令都以flask db开头。你可以在命令行中输入flask--help查看所有可用的 命令和说明。 

迁移环境只需要创建一次。这会在你的项目根目录下创建一个 migrations文件夹，其中包含了自动生成的配置文件和迁移版本文件夹。

#### 生成迁移脚本 

使用migrate⼦命令可以自动生成迁移脚本： 

```
$ flask db migrate -m "init db"
INFO  [alembic.runtime.migration] Context impl SQLiteImpl.
INFO  [alembic.runtime.migration] Will assume non-transactional DDL.
INFO  [alembic.autogenerate.compare] Detected added table 'students'
Generating D:\课程-07-后端课程\02 flask框架\flaskextentions\flask-sqlalchemy\migrations\versions\0ec61111eb0d_init_db.py ...  done

```

这条命令可以简单理解为在flask里对数据库（db）进行迁移 （migrate）。-m选项用来添加迁移备注信息。从上面的输出信息我们可以 看到，Alembic检测出了模型的变化：表note新添加了一个timestamp列，并 且相应生成了一个迁移脚本c52a02014635_add_note_timestamp.py

> 迁移脚本代码 

```shell
"""init db

Revision ID: 0ec61111eb0d
Revises: 
Create Date: 2021-10-28 13:37:05.183723

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '0ec61111eb0d'
down_revision = None
branch_labels = None
depends_on = None


def upgrade():
    # ### commands auto generated by Alembic - please adjust! ###
    op.create_table('students',
    sa.Column('id', sa.Integer(), nullable=False),
    sa.Column('username', sa.String(length=20), nullable=True),
    sa.Column('gender', sa.String(length=20), nullable=True),
    sa.Column('birth', sa.String(length=20), nullable=True),
    sa.Column('phone', sa.String(length=20), nullable=True),
    sa.PrimaryKeyConstraint('id')
    )
    # ### end Alembic commands ###


def downgrade():
    # ### commands auto generated by Alembic - please adjust! ###
    op.drop_table('students')
    # ### end Alembic commands ###


```

从上面的代码可以看出，迁移脚本主要包含了两个函数：

+ upgrade()：函数把迁移中的改动应用到数据库中。
+ downgrade()：函数则将改动删除。

自动创建的迁移脚本会根据模型定义和数据库当前状态的差异，生成upgrade()和downgrade()函数的内容。

对比不一定完全正确，有可能会遗漏一些细节，需要进行检查

**注意** 

就像这两个函数中的注释所说的，迁移命令是由Alembic自动生成的，其中可能包含错误，所以有必要在生成后检查一下。 

因为每一次迁移都会生成新的迁移脚本，而且Alembic为每一次迁移都 生成了修订版本（revision）ID，所以数据库可以恢复到修改历史中的任一 点。正因为如此，迁移环境中的文件也要纳入版本控制。 

有些复杂的操作无法实现自动迁移，这时可以使用revision命令手动创 建迁移脚本。这同样会生成一个迁移脚本，不过脚本中的upgrade（）和 downgrade（）函数都是空的。你需要使用Alembic提供的Operations对象指 令在这两个函数中实现具体操作，具体可以访问Alembic官方文档查看。 

#### 更新数据库 

生成了迁移脚本后，使用upgrade⼦命令即可更新数据库： 

```shell
$ flask db upgrade
INFO  [alembic.runtime.migration] Context impl SQLiteImpl.
INFO  [alembic.runtime.migration] Will assume non-transactional DDL.
INFO  [alembic.runtime.migration] Running upgrade  -> 0ec61111eb0d, init db

```

如果还没有创建数据库和表，这个命令会自动创建；如果已经创建， 则会在不损坏数据的前提下执行更新。 

提示 

如果你想回滚迁移，那么可以使用downgrade命令（降级），它会撤销 最后一次迁移在数据库中的改动，这在开发时非常有用。比如，当你执行 upgrade命令后发现某些地方出错了，这时就可以执行flask db downgrade命 令进行回滚，删除对应的迁移脚本，重新生成迁移脚本后再进行更新 （upgrade）。 

**返回以前的版本** 

可以根据history命令找到版本号,然后传给downgrade命令:

```
$ flask db history
<base> -> 0ec61111eb0d (head), init db

输出格式：<base> ->  版本号 (head), initial migration

```

- 回滚到指定版本

```
flask db downgrade 版本号

```

#### 操作顺序

1.flask db init

2.flask  db migrate -m "版本名(注释)"

3.flask  db upgrade 然后观察表结构

4.根据需求修改模型

5.flask  db migrate -m "新版本名(注释)"

6.flask  db upgrade 然后观察表结构

7.若返回版本,则利用 flask  db history查看版本号

8.flask  db downgrade(upgrade) 版本号

#### 开发时是否需要迁移？ 

在生产环境下，当对数据库结构进行修改后，进行数据库迁移是必要 的。因为你不想损坏任何数据，毕竟数据是无价的。在生成自动迁移脚本 后，执行更新之前，对迁移脚本进行检查，甚至是使用备份的数据库进行 迁移测试，都是有必要的。

而在开发环境中，你可以按需要选择是否进行数据迁移。对于大多数 程序来说，我们可以在开发时使用虚拟数据生成工具来生成虚拟数据，从 而避免手动创建记录进行测试。这样每次更改表结构时，可以直接清除后 重新生成，然后生成测试数据，这要比执行一次迁移简单很多（在后面我 们甚至会学习通过一条命令完成所有工作），除非生成虚拟数据耗费的时 间过长。

另外，在本地开发时通常使用SQLite作为数据库引擎。SQLite不⽀持 ALTER语句，而这正是迁移工具依赖的工作机制。也就是说，当SQLite数 据库表的字段删除或修改后，我们没法直接使用迁移工具进行更新，你需 要手动添加迁移代码来进行迁移。在开发中，修改和删除列是很常见的行为，手动操作迁移会花费太多的时间。 

## 定义关系

在关系型数据库中，我们可以通过关系让不同表之间的字段建立联系。一般来说，定义关系需要两步，分别是创建外键和定义关系属性。在 更复杂的多对多关系中，我们还需要定义关联表来管理关系。这一节我们 会学习如何使用SQLAlchemy在模型之间建立几种基础的关系模式。

### 一对多 

我们将以作者和文章来演示一对多关系：一个作者可以写作多本小说。

![image-20211028134843206](assets/image-20211028134843206.png)



在示例程序中，Author类用来表示作者，Article类用来表示文章

> 一对多关系示例 

```python
# ... 
class Author(db.Model): 
    id = db.Column(db.Integer, primary_key=True) 
    name = db.Column(db.String(70), unique=True) 
    phone = db.Column(db.String(20)) 
    
class Article(db.Model): 
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(50), index=True)
    body = db.Column(db.Text)


```

我们将在这两个模型之间建立一个简单的一对多关系，建立这个一对 多关系的目的是在表示作者的Author类中添加一个关系属性articles，作为 集合（collection）属性，当我们对特定的Author对象调用articles属性会返 回所有相关的Article对象。我们会在下面介绍如何一步步定义这个一对多关系。

添加数据

```python
db.drop_all()
db.create_all()

author1 = Author(name='烽火戏诸侯', phone='110110')
author2 = Author(name='我吃西红柿', phone='110111')
author3 = Author(name='辰东', phone='110112')

db.session.add(author1)
db.session.add(author2)
db.session.add(author3)
db.session.commit()

article1 = Article(title='剑来',
                   body='大千世界，无奇不有。天道崩塌，我陈平安，唯有一剑，可搬山，断江，倒海，降妖，镇魔，敕神，摘星，摧城，开天！')
article2 = Article(title='雪中悍刀行',
                   body="该小说讲述一个关于庙堂权争与刀剑交错的时代，一个暗潮涌动粉墨登场的江湖。荣获首届网络文学双年奖之银奖作品。")

db.session.add(article1)
db.session.add(article2)

article3 = Article(title='星辰变',
                   body="当鱼跃龙门化身为龙的时候，他便不是鱼，而是龙！他是龙，龙则是不会呆在鱼群中，他需要的而是无限的天空，上穷碧落下黄泉，翱翔九天。")
article4 = Article(title='沧元图',
                   body="我叫孟川，今年十五岁，是东宁府“镜湖道院”的当代大师兄。")
article5 = Article(title='飞剑问道',
                   body="在这个世界，有狐仙、河神、水怪、大妖，也有求长生的修行者。")

db.session.add(article3)
db.session.add(article4)
db.session.add(article5)

article6 = Article(title='圣墟',
                   body="在破败中崛起，在寂灭中复苏。沧海成尘，雷电枯竭，那一缕幽雾又一次临近大地，世间的枷锁被打开了，一个全新的世界就此揭开神秘的一角……")

article7 = Article(title='遮天',
                   body="冰冷与黑暗并存的宇宙深处，九具庞大的龙尸拉着一口青铜古棺，亘古长存。")
article8 = Article(title='完美世界',
                   body="一粒尘可填海，一根草斩尽日月星辰，弹指间天翻地覆。群雄并起，万族林立，诸圣争霸，乱天动地。问苍茫大地，谁主沉浮？")

db.session.add(article6)
db.session.add(article7)
db.session.add(article8)

db.session.commit()

```

#### 定义外键 

定义关系的第一步是创建外键。外键是（foreign key）用来在A表存储 B表的主键值以便和B表建立联系的关系字段。因为外键只能存储单一数据 （标量），所以外键总是在“多”这一侧定义，多篇文章属于同一个作者， 所以我们需要为每篇文章添加外键存储作者的主键值以指向对应的作者。 在Article模型中，我们定义一个author_id字段作为外键： 

```python
class Article(db.Model): 
    ... 
    author_id = db.Column(db.Integer, db.ForeignKey('author.id'))


```

这个字段使用db.ForeignKey类定义为外键，传入关系另一侧的表名和 主键字段名，即author.id。实际的效果是将article表的author_id的值限制为 author表的id列的值。它将用来存储author表中记录的主键值，如图5-4所示。 

![image-20200802025356555](assets/image-20200802025356555.png)

提示 

外键字段的命名没有限制，因为要连接的目标字段是author表的id列，所以为了便于区分而将这个外键字段的名称命名为author_id。 

注意 

传入ForeignKey类的参数author.id，其中author指的是Author模型对应的表名称，而id指的是字段名，即“表名.字段名”。模型类对应的表名由Flask-SQLlchemy生成，默认为类名称的⼩写形式，多个单词通过下划线分隔，你也可以显式地通过`__tablename__` 属性自己指定，后面不再提示。 

#### 定义关系属性 

定义关系的第二步是使用关系函数定义关系属性。关系属性在关系的 出发侧定义，即一对多关系的“一”这一侧。一个作者拥有多篇文章，在 Author模型中，我们定义了一个articles属性来表示对应的多篇文章： 

```python
class Author(db.Model): 
	... 
	articles = db.relationship('Article')


```

关系属性的名称没有限制，你可以自由修改。它相当于一个快捷查询，不会作为字段写入数据库中。 这个属性并没有使用Column类声明为列，而是使用了 db.relationship()关系函数定义为关系属性，因为这个关系属性返回多个 记录，我们称之为集合关系属性。relationship()函数的第一个参数为关 系另一侧的模型名称，它会告诉SQLAlchemy将Author类与Article类建立关系。当这个关系属性被调用时，SQLAlchemy会找到关系另一侧（即article 表）的外键字段（即author_id），然后反向查询article表中所有author_id值 为当前表主键值（即author.id）的记录，返回包含这些记录的列表，也就 是返回某个作者对应的多篇文章记录。 

下面我们会在Python Shell中演示如何对实际的对象建立关系。我们先 创建一个作者记录和两个文章记录，并添加到数据库会话中： 

```python
>>> author1 = Author(name='烽火戏诸侯', phone='110110')
>>> author2 = Author(name='我吃西红柿', phone='110111')
>>> author3 = Author(name='辰东', phone='110112')
>>> db.session.add(author1) 
>>> db.session.add(author2) 
>>> db.session.add(author3)

```

#### 建立关系

建立关系有两种方式，第一种方式是为外键字段赋值，比如： 

```
>>> article1.author_id = 1 
>>> db.session.commit()

```

我们将spam对象的author_id字段的值设为1，这会和id值为1的Author 对象建立关系。提交数据库改动后，如果我们对id为1的foo对象调用articles 关系属性，会看到spam对象包括在返回的Article对象列表中： 

```
>>> author1.articles 
[<Article 1>, <Article 2>]

```

另一种方式是通过操作关系属性，将关系属性赋给实际的对象即可建 立关系。集合关系属性可以像列表一样操作，调用append()方法来与一 个Article对象建立关系： 

```
>>> author1.articles.append(article1) 
>>> author1.articles.append(article2)
>>> db.session.commit()

```

可以直接将关系属性赋值给一个包含Article对象的列表。 

和前面的第一种方式类似，为了让改动生效，我们需要调用 db.session.commit()方法提交数据库会话。建立关系后，存储外键的 author_id字段会自动获得正确的值，而调用Author实例的关系属性articles 时，会获得所有建立关系的Article对象： 

```
>>> article1.author_id 
1
>>> author1.articles 
[<Article 1>, <Article 2>]


```

和主键类似，外键字段由SQLAlchemy管理，我们不需要手动设置。当通过关系属性建立关系后，外键字段会自动获得正确的值。 

在后面的示例程序中，我们会统一使用第二种方式，即通过关系属性 来建立关系。 

和append()相对，对关系属性调用remove()方法可以与对应的 Aritcle对象解除关系： 

```
>>> foo.articles.remove(spam) 
>>> db.session.commit() 
>>> author1.articles 
[<Article 1>]


```

你也可以使用pop()方法操作关系属性，它会与关系属性对应的列表 的最后一个Aritcle对象解除关系并返回该对象。 

不要忘记在操作结束后需要调用commit()方法提交数据库会话，这 样才可以把改动写入数据库。 

在上面我们提到过，使用关系函数定义的属性不是数据库字段，而是 类似于特定的查询函数。当某个Aritcle对象被删除时，在对应Author对象 的aritcles属性调用时返回的列表也不会包含该对象。 

在关系函数中，有很多参数可以用来设置调用关系属性进行查询时的 具体行为。

> 常用的SQLAlchemy关系函数参数

| 参数名         | 说	明                                                     |
| -------------- | ------------------------------------------------------------ |
| back_populates | 定义反向引用，用于建立双向关系，在关系的另一侧也必须显式定义关系属性 |
| backref        | 添加反向引用，A动在另一侧建立关系属性，是back_populates的简化版 |
| lazy           | 指定如何加载相关记录，具体选项见下表                         |
| uselist        | 指定是否使用列表的形式加载记录，设为False则使用标量(scalar)  |
| cascade        | 设置级联操作，后面会具体介绍                                 |
| order_by       | 指定加载相关记录时的排序方式                                 |
| secondary      | 在多对多关系中指定关联表                                     |
| primaryjoin    | 指定多对多关系中的一级联结条件                               |
| secondaryjoin  | 指定多对多关系中的二级联结条件                               |

```
当关系属性被调用时，关系函数会加载相应的记录，表5-9列出了控制 关系记录加载方式的lazy参数的常用选项。 
```

> 常用的SQLAlchemy关系记录加载方式（lazy参数可选值） 

| 关系加载方式 | 说	明                                                     |
| ------------ | ------------------------------------------------------------ |
| select       | 在必要时一次性加载记录，返回包含记录的列表（默认值），等同于lazy=Tme |
| joined       | 和父査询一样加载记录，但使用联结，等同于lazy=False           |
| immediate    | 一旦父查询加载就加载                                         |
| subquery     | 类似于joined,不过将使用子查询                                |
| dynamic      | 不直接加载记录，而是返回一个包含相关记录的qiiery对象，以便再继续附加查询函 数对结果进行过滤 |

dynamic选项仅用于集合关系属性，不可用于多对一、一对一或是在关 系函数中将uselist参数设为False的情况。 

许多教程和示例使用dynamic来动态加载所有集合关系属性对应的记 录，这是应该避免的行为。使用dynamic加载方式意味着每次操作关系都会 执行一次SQL查询，这会造成潜在的性能问题。大多数情况下我们只需要 使用默认值（select），只有在调用关系属性会返回大量记录，并且总是需要对关系属性返回的结果附加额外的查询时才需要使用动态加载 （lazy='dynamic'）。 

#### 建立双向关系 

我们在Author类中定义了集合关系属性articles，用来获取某个作者拥有的多篇文章记录。在某些情况下，你也许希望能在Article类中定义一个 类似的author关系属性，当被调用时返回对应的作者记录，这类返回单个 值的关系属性被称为标量关系属性。而这种两侧都添加关系属性获取对方 记录的关系我们称之为双向关系（bidirectional relationship）。 

双向关系并不是必须的，但在某些情况下会非常方便。双向关系的建立很简单，通过在关系的另一侧也创建一个relationship()函数，我们就 可以在两个表之间建立双向关系。我们使用作家（Author）和书（Article） 的一对多关系来进行演示，建立双向关系后的Author和Article类

> 基于一对多关系的双向关

```python
class Author(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(70), unique=True)
    phone = db.Column(db.String(20))

    # # 2. 定义关系
    # articles = db.relationship('Article')

    # 4. 可以直接添加反向引用
    articles = db.relationship('Article', backref='author')


class Article(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(50), index=True)
    body = db.Column(db.Text)

    # 1. 定义外键
    author_id = db.Column(db.Integer, db.ForeignKey('author.id'))

    # # 3. back_populates='articles' 添加反向关系
    # # 可以通过 Article.author 方式反向取到 Author 对象
    # author = db.relationship('Author', back_populates='articles')


```

在“多”这一侧的Article（书）类中，我们新创建了一个writer关系属性， 这是一个标量关系属性，调用它会获取对应的Writer（作者）记录；而在 Writer（作者）类中的books属性则用来获取对应的多个Book（书）记录。 在关系函数中，我们使用back_populates参数来连接对方，back_populates参 数的值需要设为关系另一侧的关系属性名。 

因为之前已经有数据了，而新增的反向关系没有新建字段，所以直接可以使用。

设置双向关系后，除了通过集合属性 articles 来操作关系，我们也可以使 用标量属性 author来进行关系操作。比如，将一个Author对象赋值给某个 Article 对象的author属性，就会和这个Article对象建立关系： 

```
article1 = Article.query.get(1)
print(article1.author)
author1 = Author.query.get(3)
print(author1.articles)

article1.author = author1
print(article1.author)


```

相对的，将某个Article的author属性设为None，就会解除与对应Author对象的关系： 

```
article1.author = None
print(article1.author)


```

需要注意的是，我们只需要在关系的一侧操作关系。当为Book对象的 writer属性赋值后，对应Writer对象的books属性的返回值也会自动包含这个 Book对象。反之，当某个Writer对象被删除时，对应的Book对象的writer属 性被调用时的返回值也会被置为空（即NULL，会返回None）。 

其他关系模式建立双向关系的方式完全相同，在下面介绍不同的关系模式时我们会简单说明。 

#### 使用backref简化关系定义 

在介绍关系函数的参数时，我们曾提到过，使用关系函数中的backref 参数可以简化双向关系的定义。以一对多关系为例，backref参数用来自动为关系另一侧添加关系属性，作为反向引用（back reference），赋予的值会作为关系另一侧的关系属性名称。比如，我们在Author一侧的关系函数中将backref参数设为author，SQLAlchemy会自动为Article类添加一个author 属性。



在定义集合属性 articles 的关系函数中，我们将 backref 参数设为 author， 这会同时在 Article 类中添加了一个author 标量属性。这时我们仅需要定义一个 关系函数，虽然 author 是一个“看不见的关系属性”，但在使用上和定义两个关系函数并使用 back_populates 参数的效果完全相同。 

尽管使用backref非常方便，但通常来说“显式好过隐式”，所以我们应该尽量使用 back_populates 定义双向关系。

### 多对多 

我们将使用学生和老师来演示多对多关系：每个学生有多个老师，而 每个老师有多个学生。

![image-20211028144621933](assets/image-20211028144621933.png)

在示例程序中，Student类表示学生，Teacher类表示老师。在这两个模 型之间建立多对多关系后，我们需要在Student类中添加一个集合关系属性 teachers，调用它可以获取某个学生的多个老师，而不同的学生可以和同一 个老师建立关系。 

在一对多关系中，我们可以在“多”这一侧添加外键指向“一”这一侧， 外键只能存储一个记录，但是在多对多关系中，每一个记录都可以与关系 另一侧的多个记录建立关系，关系两侧的模型都需要存储一组外键。在 SQLAlchemy中，要想表示多对多关系，除了关系两侧的模型外，我们还 需要创建一个关联表（association table）。关联表不存储数据，只用来存 储关系两侧模型的外键对应关系，如代码所示。 

> 建立多对多关系 

```python
association_table = db.Table(
    'association',
    db.Column('student_id', db.Integer, db.ForeignKey('student.id')),
    db.Column('teacher_id', db.Integer, db.ForeignKey('teacher.id'))
)


class Student(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(70), unique=True)
    subject = db.Column(db.String(20))
    teachers = db.relationship('Teacher',
                               secondary=association_table,
                               back_populates='students')


class Teacher(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(70), unique=True)
    office = db.Column(db.String(20))
    students = db.relationship('Student',
                               secondary=association_table,
                               back_populates='teachers')



```

关联表使用db.Table类定义，传入的第一个参数是关联表的名称。我们 在关联表中定义了两个外键字段：teacher_id字段存储Teacher类的主键， student_id存储Student类的主键。借助关联表这个中间人存储的外键对，我 们可以把多对多关系分化成两个一对多关系





当我们需要查询某个学生记录的多个老师时，我们先通过学生和关联 表的一对多关系查找所有包含该学生的关联表记录，然后就可以从这些记 录中再进一步获取每个关联表记录包含的老师记录。以图5-8中的随机数据 为例，假设学生记录的id为1，那么通过查找关联表中student_id字段为1的 记录，就可以获取到对应的teacher_id值（分别为3和4），通过外键值就可以在teacher表里获取id为3和4的记录，最终，我们就获取到id为1的学生记 录相关联的所有老师记录。 

我们在Student类中定义一个teachers关系属性用来获取老师集合。在多 对多关系中定义关系函数，除了第一个参数是关系另一侧的模型名称外， 我们还需要添加一个secondary参数，把这个值设为关联表的名称。 

为了便于实现真正的多对多关系，我们需要建立双向关系。建立双向 关系后，多对多关系会变得更加直观。在Student类上的teachers集合属性会 返回所有关联的老师记录，而在Teacher类上的students集合属性会返回所有 相关的学生记录： 

```python
class Student(db.Model): 
    ... 
    teachers = db.relationship('Teacher',
                               secondary=association_table,
                               back_populates='students')
    
class Teacher(db.Model): 
    ... 
    students = db.relationship('Student',
                               secondary=association_table,
                               back_populates='teachers')



```

除了在声明关系时有所不同，多对多关系模式在操作关系时和其他关 系模式基本相同。调用关系属性student.teachers时，SQLAlchemy会直接返 回关系另一侧的Teacher对象，而不是关联表记录，反之亦同。和其他关系 模式中的集合关系属性一样，我们可以将关系属性teachers和students像列 表一样操作。比如，当你需要为某一个学生添加老师时，对关系属性使用 append()方法即可。如果你想要解除关系，那么可以使用remove()方 法。 

关联表由SQLAlchemy接管，它会帮我们管理这个表：我们只需要像 往常一样通过操作关系属性来建立或解除关系，SQLAlchemy会自动在关 联表中创建或删除对应的关联表记录，而不用手动操作关联表。

同样的，在多对多关系中我们也只需要在关系的一侧操作关系。当为 学生A的teachers添加了老师B后，调用老师B的students属性时返回的学生 记录也会包含学生A，反之亦同。

```python
@app.cli.command()
def create():
    """新增数据"""
    db.drop_all()
    db.create_all()

    stu1 = Student(name='小红', subject='文科')
    stu2 = Student(name='小绿', subject='文科')
    stu3 = Student(name='小灰', subject='理科')
    stu4 = Student(name='小黑', subject='理科')

    db.session.add(stu1)
    db.session.add(stu2)
    db.session.add(stu3)
    db.session.add(stu4)
    db.session.commit()

    tea1 = Teacher(name='张三', office='语文老师')
    tea2 = Teacher(name='李四', office='历史老师')
    tea3 = Teacher(name='王五', office='物理老师')

    db.session.add(tea1)
    db.session.add(tea2)
    db.session.flush()

    tea1.students.append(stu1)
    tea1.students.append(stu2)
    tea1.students.append(stu3)
    tea1.students.append(stu4)

    tea2.students.append(stu1)
    tea2.students.append(stu2)

    tea3.students.append(stu3)
    tea3.students.append(stu4)

    db.session.commit()

@app.cli.command()
def rel():
    tea = Teacher.query.get(2)
    print(tea.students)
    # 删除对应关系
    stu = Student.query.get(1)
    # stu = tea.students[0]
    tea.students.remove(stu)
    print(tea.students)
    db.session.commit()


```

### 多对多演练

在项目开发过程中，会遇到很多数据之间多对多关系的情况，比如：

- 学生网上选课(学生和课程)
- 老师与其授课的班级(老师和班级)
- 用户与其收藏的新闻(用户和新闻)
- 等等...

所以在开发过程中需要使用 ORM 模型将表与表的多对多关联关系使用代码描述出来。多对多关系描述有一个唯一的点就是：**需要添加一张单独的表去记录两张表之间的对应关系**

#### 需求分析

- 学生可以网上选课，学生有多个，课程也有多个
- 学生有：张三、李四、王五
- 课程有：物理、化学、生物
- 选修关系有：
  - 张三选修了化学和生物
  - 李四选修了化学
  - 王五选修了物理、化学和生物
- 需求：
  1. 查询某个学生选修了哪些课程
  2. 查询某个课程都有哪些学生选择

#### 思路分析

- 可以通过分析得出
  - 用一张表来保存所有的学生数据
  - 用一张表来保存所有的课程数据
- 具体表及测试数据可以如下：

##### 学生表(Student)

| 主键(id) | 学生名(name) |
| :------- | :----------- |
| 1        | 张三         |
| 2        | 李四         |
| 3        | 王五         |

##### 选修课表(Course)

| 主键(id) | 课程名(name) |
| :------- | :----------- |
| 1        | 物理         |
| 2        | 化学         |
| 3        | 生物         |

##### 数据关联关系表(Student_Course)

| 主键(student.id) | 主键(course.id) |
| :--------------- | :-------------- |
| 1                | 2               |
| 1                | 3               |
| 2                | 2               |
| 3                | 1               |
| 3                | 2               |
| 3                | 3               |

#### 结果

- 查询某个学生选修了哪些课程，例如：查询王五选修了哪些课程
  - 取出王五的 id 去 Student_Course 表中查询 student.id 值为 3 的所有数据
  - 查询出来有3条数据，然后将这3条数据里面的 course.id 取值并查询 Course 表即可获得结果
- 查询某个课程都有哪些学生选择，例如：查询生物课程都有哪些学生选修
  - 取出生物课程的 id 去 Student_Course 表中查询 course.id 值为 3 的所有数据
  - 查询出来有2条数据，然后将这2条数据里面的 student.id 取值并查询 Student 表即可获得结果

#### 代码演练

- 定义模型及表

```python
tb_student_course = db.Table('tb_student_course',
                             db.Column('student_id', db.Integer, db.ForeignKey('students.id')),
                             db.Column('course_id', db.Integer, db.ForeignKey('courses.id'))
                             )


class Student(db.Model):
    __tablename__ = "students"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(64), unique=True)

    courses = db.relationship('Course', secondary=tb_student_course,
                              backref='student',
                              lazy='dynamic')


class Course(db.Model):
    __tablename__ = "courses"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(64), unique=True)
```

- 添加测试数据

```python
if __name__ == '__main__':
    db.drop_all()
    db.create_all()

    # 添加测试数据

    stu1 = Student(name='张三')
    stu2 = Student(name='李四')
    stu3 = Student(name='王五')

    cou1 = Course(name='物理')
    cou2 = Course(name='化学')
    cou3 = Course(name='生物')

    stu1.courses = [cou2, cou3]
    stu2.courses = [cou2]
    stu3.courses = [cou1, cou2, cou3]

    db.session.add_all([stu1, stu2, stu2])
    db.session.add_all([cou1, cou2, cou3])

    db.session.commit()

    app.run(debug=True)
```