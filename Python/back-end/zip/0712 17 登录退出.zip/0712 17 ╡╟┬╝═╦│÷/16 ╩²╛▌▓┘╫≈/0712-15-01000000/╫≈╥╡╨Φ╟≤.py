""""""
"""
使用 jinja2 的继承与include,
将 blog 案例下的 html 中 header、footer、script、侧边栏 都抽取成 jinja2 继承(extend)与包含（include）
 + 需要有一个基类模板
 + 可以自由组合没有标准答案
"""