from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from utils import AnonymousUser
from flask_migrate import Migrate


db: SQLAlchemy = SQLAlchemy()
login_manager = LoginManager()
migrate = Migrate()


# 用于获取用户对象
@login_manager.user_loader
def load_user(user_id):
    from models import User
    return User.query.get(user_id)


# 设置用户登录视图函数 endpoint
login_manager.login_view = 'blog.login'
login_manager.login_message = '请先登录之后再进行操作'
login_manager.anonymous_user = AnonymousUser
