from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import current_user, login_required, logout_user, login_user

from extention import db
from models import User, Role

blog_bp = Blueprint('blog', __name__)


@blog_bp.route('/')
def index():
    return render_template('index.html')


@blog_bp.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        print(current_user)
        username = request.form.get('username')
        pwd = request.form.get('password')
        email = request.form.get('email')
        user = User()
        user.username = username
        user.pwd = pwd
        user.email = email
        db.session.add(user)
        db.session.commit()
        flash('注册成功，可以进行登录了')
        return redirect(url_for('blog.login'))
    return render_template('register.html')


@blog_bp.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == "POST":
        form = request.form
        username = form.get('username')
        user = User.query.filter(User.username == username).first()
        print(user)
        login_user(user)
        flash('登录成功.')
        return redirect(url_for('blog.index'))
    return render_template('login.html')


@blog_bp.route("/admin")
@login_required
def admin():
    print(current_user)
    return render_template('admin.html')


@blog_bp.route("/logout")
@login_required
def logout():
    print(current_user)
    logout_user()
    return redirect(url_for('blog.index'))
