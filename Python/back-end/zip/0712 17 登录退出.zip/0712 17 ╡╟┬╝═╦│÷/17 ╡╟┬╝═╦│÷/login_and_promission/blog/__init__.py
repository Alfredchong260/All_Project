from flask import Flask

from extention import login_manager, migrate
import models

class Config:
    # 数据库链接配置参数
    SQLALCHEMY_DATABASE_URI = 'sqlite:///data.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False


app = Flask('login_and_promission')
app.secret_key = '123456'
app.config.from_object(Config)

from extention import db

db.init_app(app)
# 挂在登录与退出管理
login_manager.init_app(app)
migrate.init_app(app, db)

from .auth import auth_bp
from .blog import blog_bp

app.register_blueprint(auth_bp)
app.register_blueprint(blog_bp)
