class Permission:
    """二进制的运算"""
    READ = 0b00000001  # 0x01
    FOLLOW = 0b00000010  # 0x02
    COMMENT = 0b00000100  # 0x04
    WRITE_ARTICLES = 0b00001000  # 0x08

    MODERATE_COMMENTS = 0b00010000  # 0x10
    ADMINISTER = 0b1000000  # 0x80
    # '0b1111'

# 二进制的运算
class AnonymousUser(object):
    @property
    def is_authenticated(self):
        return False

    @property
    def is_active(self):
        return False

    @property
    def is_anonymous(self):
        return True

    def get_id(self):
        return

    @property
    def permissions(self):
        return 0x01

    # 权限验证
    def can_permissions(self, permissions):
        return (self.permissions & permissions) == permissions

    @property
    def role(self):
        return None

    # 角色验证
    def can_role(self, permissions):
        return self.role is not None and (self.role.permissions & permissions) == permissions
