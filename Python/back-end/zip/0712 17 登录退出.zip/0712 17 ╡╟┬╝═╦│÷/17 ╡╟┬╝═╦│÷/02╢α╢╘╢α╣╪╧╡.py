""""""

from flask import Flask, render_template, request, redirect

from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate

app = Flask(__name__)


class Config:
    SQLALCHEMY_DATABASE_URI = r'sqlite:///data_01.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    # SQLALCHEMY_ECHO = True


app.config.from_object(Config)

db = SQLAlchemy()
migrate = Migrate()

db.init_app(app)
migrate.init_app(app, db)

association_table = db.Table(
    'association',
    db.Column('teacher_id', db.Integer, db.ForeignKey('teacher.id')),
    db.Column('student_id', db.Integer, db.ForeignKey('student.id'))
)


# 多对多关系的中间表


class Teachers(db.Model):
    __tablename__ = 'teacher'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(length=20))
    office = db.Column(db.String(length=20))

    students = db.relationship('Student',
                               secondary=association_table,
                               back_populates='teachers')

    def __repr__(self):
        return '<Teachers {}>'.format(self.name)


class Student(db.Model):
    __tablename__ = 'student'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(length=20))
    subject = db.Column(db.String(length=20))

    teachers = db.relationship('Teachers',
                               secondary=association_table,
                               back_populates='students')

    def __repr__(self):
        return '<Students {}>'.format(self.name)


@app.cli.command()
def search():
    db.drop_all()
    db.create_all()

    stu1 = Student(name='小红', subject='文科')
    stu2 = Student(name='小绿', subject='文科')
    stu3 = Student(name='小灰', subject='理科')
    stu4 = Student(name='小黑', subject='理科')

    db.session.add(stu1)
    db.session.add(stu2)
    db.session.add(stu3)
    db.session.add(stu4)
    db.session.commit()

    tea1 = Teachers(name='张三', office='语文老师')
    tea2 = Teachers(name='李四', office='历史老师')
    tea3 = Teachers(name='王五', office='物理老师')

    db.session.add(tea1)
    db.session.add(tea2)
    db.session.add(tea3)
    db.session.flush()  # 提交数据之前,刷新一下服务器的数据,生成id

    tea1.students.append(stu1)
    tea1.students.append(stu2)
    tea1.students.append(stu3)
    tea1.students.append(stu4)

    tea2.students.append(stu1)
    tea2.students.append(stu2)

    tea3.students.append(stu3)
    tea3.students.append(stu4)

    db.session.commit()


@app.cli.command()
def rel():
    stu = Student.query.get(1)
    print(stu)
    print(stu.teachers)
    print(stu.teachers[0].students)
    print(stu.teachers[1].students)