### Flask Todo List

使用 Flask 框架与 html/css/javascript 实现 ToDo List 案例

使用的技术
+ flask 框架
+ bootstrap5
+ Web Api
