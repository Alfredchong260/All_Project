
headers = {
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9
Accept-Encoding: gzip, deflate, br
Accept-Language: zh-CN,zh;q=0.9
Cache-Control: no-cache
Connection: keep-alive
Cookie: __mta=244152890.1603971211691.1618042413519.1618044198851.63; __mta=244152890.1603971211691.1618044198851.1634557772212.64; _lxsdk_cuid=1757422618bc8-00cec1fb04d25d-303464-1fa400-1757422618bc8; __mta=244152890.1603971211691.1632809679672.1632897727972.102; uuid_n_v=v1; uuid=3C2172202DB811EC8BAB0F3D6466135E2D04577D7E3E440993213828E3D7F8DB; _lx_utm=utm_source%3DBaidu%26utm_medium%3Dorganic; _lxsdk=3C2172202DB811EC8BAB0F3D6466135E2D04577D7E3E440993213828E3D7F8DB; _csrf=b4fd5c105a55e10f7c106c4df06b659df542bc4cd7b4fd7a010994c86b40807d; Hm_lvt_703e94591e87be68cc8da0da7cbd0be2=1632897725,1634124634,1634302984,1634556705; Hm_lpvt_703e94591e87be68cc8da0da7cbd0be2=1634557772; _lxsdk_s=17c939ad100-d13-546-62f%7C%7C1
Host: maoyan.com
Pragma: no-cache
Referer: https://maoyan.com/board/4?offset=20
sec-ch-ua: "Chromium";v="94", "Google Chrome";v="94", ";Not A Brand";v="99"
sec-ch-ua-mobile: ?0
sec-ch-ua-platform: "Windows"
Sec-Fetch-Dest: document
Sec-Fetch-Mode: navigate
Sec-Fetch-Site: same-origin
Sec-Fetch-User: ?1
Upgrade-Insecure-Requests: 1
User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.81 Safari/537.36
}

