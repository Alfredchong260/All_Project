"""
	目标网址: https://cs.lianjia.com/ershoufang/
	
    要求:
		100页数据, 请用多进程方式实现, 需要以下数据:
			room_title = 二手房标题
			room_address = 二手房地址
			room_introduce = 二手房型简介
			room_follow = 关注人数及发布时间
			room_totalPrice = 单价
			room_unitPrice = 总价
			
请在下方编写代码
"""