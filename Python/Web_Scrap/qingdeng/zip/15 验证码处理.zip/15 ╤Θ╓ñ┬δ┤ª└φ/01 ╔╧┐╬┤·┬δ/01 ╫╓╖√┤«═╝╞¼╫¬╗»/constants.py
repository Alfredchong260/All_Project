"""快识别账号密码"""
KUAI_USERNAME = '请输入你的用户信息'
KUAI_PASSWORD = '请输入你的用户信息'

"""凤凰网账号密码"""
FENG_USERNAME = '请输入你的用户信息'
FENG_PASSWORD = '请输入你的用户信息'

"""哔哩哔哩账号密码"""
BILIBILI_USERNAME = '请输入你的用户信息'
BILIBILI_PASSWORD = '请输入你的用户信息'