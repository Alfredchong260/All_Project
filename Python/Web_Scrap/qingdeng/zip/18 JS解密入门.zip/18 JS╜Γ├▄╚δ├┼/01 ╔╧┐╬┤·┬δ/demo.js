

// 相当于Python 的 print 函数
console.log('hello world !')

// 可能大家某些同学的插件没有自动适配
