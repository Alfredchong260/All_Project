import urllib.request

response = urllib.request.urlopen('https://github.com/')

print(response.read().decode('utf-8'))
