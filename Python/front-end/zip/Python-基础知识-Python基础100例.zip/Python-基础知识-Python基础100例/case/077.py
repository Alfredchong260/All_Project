l=['moyu','niupi','xuecaibichi','shengfaji','42']
for i in range(len(l)):
    print(l[i])
