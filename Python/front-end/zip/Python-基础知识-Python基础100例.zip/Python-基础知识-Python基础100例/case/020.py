high=200.
total=100
for i in range(10):
    high/=2
    total+=high
    print(high/2)
print('总长：',total)
    
