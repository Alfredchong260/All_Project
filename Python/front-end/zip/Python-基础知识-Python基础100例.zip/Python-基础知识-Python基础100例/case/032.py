a = ['one', 'two', 'three']
print(a[::-1])
