import random
print(random.uniform(10,20))
