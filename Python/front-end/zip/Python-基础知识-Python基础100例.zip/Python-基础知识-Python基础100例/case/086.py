a='guangtou'
b='feipang'
print(b+a)
