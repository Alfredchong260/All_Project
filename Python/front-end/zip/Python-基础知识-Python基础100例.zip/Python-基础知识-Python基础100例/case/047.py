def exc(a,b):
    return (b,a)
a=0
b=10
a,b=exc(a,b)
print(a,b)
