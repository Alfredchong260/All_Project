print(~234)
print(~~234)
