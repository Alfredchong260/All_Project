from dateutil import parser
dt = parser.parse("Aug 28 2015 12:00AM")
print (dt)
