l=['baaa','aaab','aaba','aaaa','abaa']
l.sort()
print(l)
