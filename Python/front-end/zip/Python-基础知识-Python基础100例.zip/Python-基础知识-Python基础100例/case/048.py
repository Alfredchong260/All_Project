a=int(input('a='))
b=int(input('b='))
if a<b:
    print('a<b')
elif a>b:
    print('a>b')
else:
    print('a=b')
