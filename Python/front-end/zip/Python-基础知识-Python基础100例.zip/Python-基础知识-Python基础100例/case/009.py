import time
for i in range(4):
    print(str(int(time.time()))[-2:])
    time.sleep(1)
