peach=1
for i in range(9):
    peach=(peach+1)*2
print(peach)
