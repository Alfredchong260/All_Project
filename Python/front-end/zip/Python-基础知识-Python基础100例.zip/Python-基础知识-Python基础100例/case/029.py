n=int(input('输入一个正整数：'))
n=str(n)
print('%d位数'%len(n))
print(n[::-1])
