## JQuery

### 基础概念

#### JavaScript 库

JavaScript库：即 library，是一个封装好的特定的集合（方法和函数）。从封装一大堆函数的角度理解库，就是在这个库中，封装了很多预先定义好的函数在里面，比如动画 animate、hide、show，比如获取元素等。

简单理解： 就是一个JS 文件，里面对我们原生js代码进行了封装，存放到里面。这样我们可以快速高效的使用这些封装好的功能了。

jQuery，就是为了快速方便的操作DOM，里面基本都是函数（方法）。


#### jQuery的概念

jQuery总体概况如下 :

- jQuery 是一个快速、简洁的 JavaScript 库，其设计的宗旨是“write Less，Do More”，即倡导写更少的代码，做更多的事情。

- j 就是 JavaScript； Query 查询； 意思就是查询js，把js中的DOM操作做了封装，我们可以快速的查询使用里面的功能。

- jQuery 封装了 JavaScript 常用的功能代码，优化了 DOM 操作、事件处理、动画设计和 Ajax 交互。

- 学习jQuery本质： 就是学习调用这些函数（方法）。

- jQuery 出现的目的是加快前端人员的开发速度，我们可以非常方便的调用和使用它，从而提高开发效率。

![jQuery概述](../assets/jQuery概述.jpg)

#### jQuery 的优点

1. 轻量级。核心文件才几十kb，不会影响页面加载速度。
2. 跨浏览器兼容，基本兼容了现在主流的浏览器。
3. 链式编程、隐式迭代。
4. 对事件、样式、动画支持，大大简化了DOM操作。
5. 支持插件扩展开发。有着丰富的第三方的插件，例如：树形菜单、日期控件、轮播图等。
6. 免费、开源。


### 基本使用

**下载** 

jQuery的官网地址： https://jquery.com/，官网即可下载最新版本。

>  各个版本的下载：https://www.bootcdn.cn/jquery/

版本介绍：

> 1x ：兼容 IE 678 等低版本浏览器， 官网不再更新
>
> 2x ：不兼容 IE 678 等低版本浏览器， 官网不再更新
>
> 3x ：不兼容 IE 678 等低版本浏览器， 是官方主要更新维护的版本



**使用步骤：** 

1. 引入jQuery文件。
2. 在文档最末尾插入 script 标签，书写体验代码。
3. $('div').hide() 可以隐藏盒子。

> mdn 界面上的事件：https://www.w3.org/TR/DOM-Level-3-Events



**jQuery的入口函数** 

jQuery 中常见的两种入口函数：

```javascript
// 第一种: 简单易用。
$(function () {   
    ...  // 此处是页面 DOM 加载完成的入口
}) ; 

// 第二种: 繁琐，但是也可以实现
$(document).ready(function(){
   ...  //  此处是页面DOM加载完成的入口
});
```

总结：

1. 等着 DOM 结构渲染完毕即可执行内部代码，不必等到所有外部资源加载完成，jQuery 帮我们完成了封装。
2. 相当于原生 js 中的 DOMContentLoaded。
3. 不同于原生 js 中的 load 事件是等页面文档、外部的 js 文件、css 文件、图片加载完毕才执行内部代码。
4. 更推荐使用第一种方式。


**顶级对象$** 

`$` 是 jQuery 的别称，在代码中可以使用 jQuery 代替，但一般为了方便，通常都直接使用 `$`  。

`$` 是 jQuery 的顶级对象，相当于原生 JavaScript 中的 window 。把元素利用$包装成 jQuery 对象，就可以调用jQuery 的方法。



#### jQuery 对象和 DOM 对象

使用 jQuery 方法和原生JS获取的元素是不一样的，总结如下 : 

1. 用原生 JS 获取来的对象就是 DOM 对象
2. jQuery 方法获取的元素就是 jQuery 对象。
3. jQuery 对象本质是： 利用 $ 对 DOM 对象包装后产生的对象（伪数组形式存储）。

注意：

只有 jQuery 对象才能使用 jQuery 方法，DOM 对象则使用原生的 JavaScirpt 方法。

![jQuery对象和DOM对象](../assets/jQuery对象和DOM对象.png)

#### jQuery 对象和 DOM 对象转换

DOM 对象与 jQuery 对象之间是可以相互转换的。因为原生 js 比 jQuery 更大，原生的一些属性和方法 jQuery 没有给我们封装. 要想使用这些属性和方法需要把 jQuery 对象转换为 DOM 对象才能使用。

```javascript
// 1.DOM对象转换成jQuery对象，方法只有一种
var box = document.getElementById('box');  // 获取DOM对象
var jQueryObject = $(box);  // 把DOM对象转换为 jQuery 对象

// 2.jQuery 对象转换为 DOM 对象有两种方法：
//   2.1 jQuery对象[索引值]
var domObject1 = $('div')[0]

//   2.2 jQuery对象.get(索引值)
var domObject2 = $('div').get(0)
```

总结：实际开发比较常用的是把 DOM 对象转换为 jQuery 对象，这样能够调用功能更加强大的 jQuery 中的方法。



## 常用API

### jQuery 选择器

原生 JS 获取元素方式很多，很杂，而且兼容性情况不一致，因此 jQuery 给我们做了封装，使获取元素统一标准。

#### 基础选择器

```js
$("选择器")   //  里面选择器直接写 CSS 选择器即可，但是要加引号
```

| 名称       | 用法            | 描述                     |
| ---------- | --------------- | ------------------------ |
| ID选择器   | $("#id")        | 获取指定ID的元素         |
| 全选选择器 | $("*")          | 匹配所有元素             |
| 类选择器   | $(".class")     | 获取同一类class的元素    |
| 标签选择器 | $("div")        | 获取同一类标签的所有元素 |
| 并集选择器 | $("div,p,i")    | 选取多个元素             |
| 交集选择器 | $("li.current") | 交集元素                 |



#### 层级选择器

层级选择器最常用的两个分别为：后代选择器和子代选择器。

| 名称.       | 用法        | 描述                                                       |
| ----------- | ----------- | ---------------------------------------------------------- |
| 子代选择器. | $("ul>li"); | 使用>号,获取亲儿子层级的元素;注意,并不会获取孙子层级的元素 |
| 后代选择器  | $("ul li"); | 使用空格，代表后代选择器，获取ul下的所有li元素，包括孙子等 |

**基础选择器和层级选择器案例代码**

```html
<body>
    <div>我是div</div>
    <div class="nav">我是nav div</div>
    <p>我是p</p>
    <ul>
        <li>我是ul 的</li>
        <li>我是ul 的</li>        
        <li>我是ul 的</li>
    </ul>
    <script>
        $(function() {
            console.log($(".nav"));
            console.log($("ul li"));
        })
    </script>
</body>
```

#### 伪类选择器

筛选选择器，顾名思义就是在所有的选项中选择满足条件的进行筛选选择。常见如下 :

| 语法       | 用法          | 描述.                                                     |
| ---------- | ------------- | --------------------------------------------------------- |
| :first     | $(li:first')  | 获取第一个i元素                                           |
| :last      | $(li:last')   | 获取最后-一个li元素                                       |
| :eq(index) | $("Ii:eq(2)") | 获取到的i元素中，选择索引号为2的元素,索引号index从0开始。 |
| :odd       | $("li:odd")   | 获取到的1i元素中，选择索引号为奇数的元素                  |
| :even      | $("li:even")  | 获取到的1i元素中，选择索引号为偶数的元素                  |

**案例代码**

```html
<body>
    <ul>
        <li>多个里面筛选几个</li>
        <li>多个里面筛选几个</li>
        <li>多个里面筛选几个</li>
        <li>多个里面筛选几个</li>
        <li>多个里面筛选几个</li>
        <li>多个里面筛选几个</li>
    </ul>
    <ol>
        <li>多个里面筛选几个</li>
        <li>多个里面筛选几个</li>
        <li>多个里面筛选几个</li>
        <li>多个里面筛选几个</li>
        <li>多个里面筛选几个</li>
        <li>多个里面筛选几个</li>
    </ol>
    <script>
        $(function() {
            $("ul li:first").css("color", "red");
            $("ul li:eq(2)").css("color", "blue");
            $("ol li:odd").css("color", "skyblue");
            $("ol li:even").css("color", "pink");
        })
    </script>
</body>
```

另:  jQuery中还有一些筛选方法，类似DOM中的通过一个节点找另外一个节点，父、子、兄以外有所加强。

#### 筛选方法

| 语法                | 用法.                          | 说明                                                   |
| ------------------- | ------------------------------ | ------------------------------------------------------ |
| parent()            | $("1i").parent()               | 查找父级                                               |
| children(selector)  | `$("ul").children("1i")`       | 相当于$("ul>li")，最近--级(亲儿子)                     |
| find(selector)      | `$("u1").find("1i")`           | 相当于$ ("ulli"),后代选择器                            |
| Isiblings(selector) | $(".first").siblings("li")     | 查找兄弟节点，不包括自己本身                           |
| nextAll([expr])     | $(".first").nextAll()          | 查找当前元索之后所有的同辈元素                         |
| prevtAll([expr])    | $(".last").prevAll()           | 查找当前元素之前所有的同辈元素                         |
| hasClass(class)     | $('div').hasClass("protected") | 检查当前的元素是否含有某个特定的类，如果有，则返回true |
| eq(index)           | `$("li").eq(2) `               | 相当于$("li:eq(2)"),index从0开始                       |



#### 常用技巧

##### jQuery 设置样式

```javascript
$('div').css('属性', '值')    
```

##### 隐式迭代

```javascript
// 遍历内部 DOM 元素（伪数组形式存储）的过程就叫做隐式迭代。
// 简单理解：给匹配到的所有元素进行循环遍历，执行相应的方法，而不用我们再进行循环，简化我们的操作，方便我们调用。
$('div').hide();  // 页面中所有的div全部隐藏，不用循环操作
```

```html
<body>
<div>惊喜不，意外不</div>
<div>惊喜不，意外不</div>
<div>惊喜不，意外不</div>
<div>惊喜不，意外不</div>
<ul>
    <li>相同的操作</li>
    <li>相同的操作</li>
    <li>相同的操作</li>
</ul>
<script>
    // 1. 获取四个div元素
    console.log($("div"));
    // 2. 给四个div设置背景颜色为粉色 jquery对象不能使用style
    $("div").css("background", "pink");
    // 3. 隐式迭代就是把匹配的所有元素内部进行遍历循环，给每一个元素添加css这个方法
    $("ul li").css("color", "red");
</script>
</body>
```



**案例：新浪下拉菜单**

```html
<style>
    * {margin: 0;padding: 0;}
    li {list-style-type: none;}
    a {text-decoration: none;font-size: 14px;}
    .nav > li {position: relative;float: left;width: 80px;height: 41px;text-align: center;}
    .nav li a {display: block;width: 100%;height: 100%;line-height: 41px;color: #333;}
    .nav > li > a:hover {background-color: #eee;}
    .nav ul {display: none;position: absolute;top: 41px;left: 0;width: 100%;}
    .nav ul li {border-left: 1px solid #FECC5B;border-right: 1px solid #FECC5B;border-bottom: 1px solid #FECC5B;}
    .nav ul li a:hover {background-color: #FFF5DA;}
</style>


<ul class="nav">
    <li><a href="#">博客</a>
        <ul>
            <li><a href="">私信</a></li>
            <li><a href="">评论</a></li>
            <li><a href="">@我</a></li>
        </ul>
    </li>
    <li><a href="#">博客</a>
        <ul>
            <li><a href="">博客评论</a></li>
            <li><a href="">未读提醒</a></li>
        </ul>
    </li>
    <li><a href="#">邮箱</a>
        <ul>
            <li><a href="">免费邮箱</a></li>
            <li><a href="">VIP邮箱</a></li>
            <li><a href="">企业邮箱</a></li>
        </ul>
    </li>
</ul>


<script>
  $(function () {
    // 鼠标经过
    $('.nav>li').mouseover(function () {
      // $(this) jQuery 当前元素  this不要加引号
      // show() 显示元素  hide() 隐藏元素
      $(this).children('ul').show()
    })

    // 鼠标离开
    $('.nav>li').mouseout(function () {
      $(this).children('ul').hide()
    })
  })
</script>
```





##### 排他思想

```html
<body>
<button>快速</button>
<button>快速</button>
<button>快速</button>
<button>快速</button>
<button>快速</button>
<button>快速</button>
<button>快速</button>
<script>
    $(function () {
        // 1. 隐式迭代 给所有的按钮都绑定了点击事件
        $("button").click(function () {
            // 2. 当前的元素变化背景颜色
            $(this).css("background", "pink");
            // 3. 其余的兄弟去掉背景颜色 隐式迭代
            $(this).siblings("button").css("background", "");
        });
    })
</script>
</body>
```



##### 链式编程

```html
<body>
<button>快速</button>
<button>快速</button>
<button>快速</button>
<button>快速</button>
<button>快速</button>
<button>快速</button>
<button>快速</button>
<script>
    $(function () {
        // 隐式迭代 给所有的按钮都绑定了点击事件
        $("button").click(function () {
            // 链式编程
            $(this).css("color", "red").siblings().css("color", "");
        });
    })
</script>
</body>
```



### jQuery 样式操作

jQuery中常用的样式操作有两种：css() 和 设置类样式方法

#### 方法1: 操作 css 方法

jQuery 可以使用 css 方法来修改简单元素样式； 也可以操作类，修改多个样式。

常用以下三种形式 : 

```javascript
// 1.参数只写属性名，则是返回属性值
var strColor = $(this).css('color');

// 2.  参数是属性名，属性值，逗号分隔，是设置一组样式，属性必须加引号，值如果是数字可以不用跟单位和引号
$(this).css('color, 'red');

// 3.  参数可以是对象形式，方便设置多组样式。属性名和属性值用冒号隔开， 属性可以不用加引号
$(this).css({"color":"white","font-size":"20px"});
```

注意：css() 多用于样式少时操作，多了则不太方便。

#### 方法2: 设置类样式方法

作用等同于以前的 classList，可以操作类样式， 注意操作类里面的参数不要加点。

常用的三种设置类样式方法：

```javascript
// 1.添加类
$("div").addClass("current");

// 2.删除类
$("div").removeClass("current");

// 3.切换类
$("div").toggleClass("current");
```

注意：

1. 设置类样式方法比较适合样式多时操作，可以弥补css()的不足。
2. 原生 JS 中 className 会覆盖元素原先里面的类名，jQuery 里面类操作只是对指定类进行操作，不影响原先的类名。

#### 案例：淘宝服饰精品案例

思路分析: 

1. 核心原理：鼠标经过左侧盒子某个小li，就让内容区盒子相对应图片显示，其余的图片隐藏。
2. 需要得到当前小li 的索引号，就可以显示对应索引号的图片
3. jQuery 得到当前元素索引号 $(this).index()
4. 中间对应的图片，可以通过  eq(index) 方法去选择
5. 显示元素 show()   隐藏元素 hide()

```html
<style>
* {margin: 0;padding: 0;}
li {list-style-type: none;}
.tab {width: 978px;margin: 100px auto;}
.tab_list {height: 39px;border: 1px solid #ccc;background-color: #f1f1f1;}
.tab_list li {float: left;height: 39px;line-height: 39px;padding: 0 20px;text-align: center;cursor: pointer;}
.tab_list .current {background-color: #c81623;color: #fff;}
.item_info {padding: 20px 0 0 20px;}
.item {display: none;}
</style>
```

```html
<div class="tab">
    <div class="tab_list">
        <ul>
            <li class="current">商品介绍</li>
            <li>规格与包装</li>
            <li>售后保障</li>
            <li>商品评价（50000）</li>
            <li>手机社区</li>
        </ul>
    </div>
    <div class="tab_con">
        <div class="item" style="display: block;"> 商品介绍模块内容</div>
        <div class="item"> 规格与包装模块内容</div>
        <div class="item"> 售后保障模块内容</div>
        <div class="item"> 商品评价（50000）模块内容</div>
        <div class="item"> 手机社区模块内容</div>
    </div>
</div>
```

```html
<script>
    $(function() {
        // 1.点击上部的li，当前li 添加current类，其余兄弟移除类
        $(".tab_list li").click(function() {
            // 链式编程操作
            $(this).addClass("current").siblings().removeClass("current");
            // 2.点击的同时，得到当前li 的索引号
            var index = $(this).index();
            console.log(index);
            // 3.让下部里面相应索引号的item显示，其余的item隐藏
            $(".tab_con .item").eq(index).show().siblings().hide();
        });
    })
</script>
```







###  jQuery 效果

jQuery 给我们封装了很多动画效果，最为常见的如下：

- 显示隐藏：show() / hide() / toggle() ;
- 划入画出：slideDown() / slideUp() / slideToggle() ; 
- 淡入淡出：fadeIn() / fadeOut() / fadeToggle() / fadeTo() ; 
- 自定义动画：animate() ;

注意：

> 动画或者效果一旦触发就会执行，如果多次触发，就造成多个动画或者效果排队执行。
>
> jQuery为我们提供另一个方法，可以停止动画排队：stop() ;

#### 显示隐藏

显示隐藏动画，常见有三个方法：show() / hide() / toggle() ;

语法规范如下:

+ 1 显示语法规范

  ```
  show([speed, [easing], [fn]])
  ```

+ 2 显示参数

  ⑴ 参数都可以省略，无动画直接显示。

  ⑵ speed: 三种预定速度之一的字符串（'slow', 'normal', 'fast'） 或表示动画市场的毫秒数值

  ⑶ easing: (Optional) 用来指定切换效果，默认是 'waing', 可选参数 'liner'。

  ⑷ fn: 回调函数，在动画完成时执行的函数，每个元素执行一次。

+ 1 影藏语法规范

  ```
  hide([speed, [easing], [fn]])
  ```

+ 2 影藏参数

  ⑴ 参数都可以省略，无动画直接显示。

  ⑵ speed: 三种预定速度之一的字符串（'slow', 'normal', 'fast'） 或表示动画市场的毫秒数值

  ⑶ easing: (Optional) 用来指定切换效果，默认是 'waing', 可选参数 'liner'。

  ⑷ fn: 回调函数，在动画完成时执行的函数，每个元素执行一次。

+ 1 切换语法规范

  ```
  toggle([speed, [easing], [fn]])
  ```

+ 2 切换参数

  ⑴ 参数都可以省略，无动画直接显示。

  ⑵ speed: 三种预定速度之一的字符串（'slow', 'normal', 'fast'） 或表示动画市场的毫秒数值

  ⑶ easing: (Optional) 用来指定切换效果，默认是 'waing', 可选参数 'liner'。

  ⑷ fn: 回调函数，在动画完成时执行的函数，每个元素执行一次。

  建议：平时一般不带参数，直接显示影藏即可

**代码演示**

```html
<body>
<button>显示</button>
<button>隐藏</button>
<button>切换</button>
<div></div>
<script>
  $(function () {
    $('button').eq(0).click(function () {
      $('div').show(1000, function () {
        console.log('显示动画演示完毕')
      })
    })
    $('button').eq(1).click(function () {
      $('div').hide(1000, function () {
        console.log('影藏动画演示完毕')
      })
    })
    $('button').eq(2).click(function () {
      $('div').toggle(1000)
      console.log('切换动画演示完毕')
    })
    // 一般情况下，我们都不加参数直接显示隐藏就可以了
  })
</script>
</body>
```

#### 滑入滑出

滑入滑出动画，常见有三个方法：slideDown() / slideUp() / slideToggle() ; 

语法规范如下:

+ **1. 下滑效果语法规范**

  ```
  slideDown([speed, [easing] , [fn]])
  ```
  
+ **2.下滑效果参数**

  (1) 参数都可以省略。

  (2) speed:三种预定速度之一的字符串( “slow”, "normal”, or“fast”)或表示动画时长的毫秒数值(如:1000),

  (3) easing:(Optional)用来指定切换效果，默认是“swing”，可用参数“linear”。

  (4) fn:回调函数，在动画完成时执行的函数，每个元素执行一次。

+ **1.上滑效果语法规范**

  ```
  slideUp([speed,[easing],[fn]])
  ```
  
+ **2.上滑效果参数**

  (1）参数都可以省略。

  (2) speed:三种预定速度之一的字符串(“slow”, "normal”,or“fast”)或表示动画时长的毫秒数值(如:1000)。

  (3) easing: (Optional)用来指定切换效果，默认是“swing”，可用参数“linear”。

  (4) fn:回调函数，在动画完成时执行的函数，每个元素执行一次。

+ **1.滑动切换效果语法规范**

  ```
  slideToggle([speed,[easing], [fn]])
  ```
  
+ **2.滑动切换效果参数**

  (1) 参数都可以省略。

  (2) speed:三种预定速度之一的字符串(“slow”, "normal”,or“fast”)或表示动画时长的毫秒数值(如:1000).

  (3) easing:(Optional)用来指定切换效果，默认是“swing”，可用参数“linear”。

  (4) fn:回调函数，在动画完成时执行的函数，每个元素执行一次。

**代码演示**

```html
<body>
<button>下拉滑动</button>
<button>上拉滑动</button>
<button>切换滑动</button>
<div></div>
<script>
  $(function () {
    $('button').eq(0).click(function () {
      // 下滑动 slideDown()
      $('div').slideDown()
    })
    $('button').eq(1).click(function () {
      // 上滑动 slideUp()
      $('div').slideUp(500)
    })
    $('button').eq(2).click(function () {
      // 滑动切换 slideToggle()
      $('div').slideToggle(500)
    })

  })
</script>
</body>
```

### jQuery 属性操作

能够操作  jQuery 属性 
能够操作  jQuery 元素
能够操作  jQuery 元素尺寸、位置

jQuery 常用属性操作有三种：prop() / attr() / data() ;

#### 元素固有属性值 prop()

所谓元素固有属性就是元素本身自带的属性，比如 <a> 元素里面的 href ，比如 <input> 元素里面的 type。 

**语法** 

1.获取属性语法

```
prop("属性")
```

2.设置属性语法

```
prop("尾性",”属性值")
```

注意：prop() 除了普通属性操作，更适合操作表单属性：disabled / checked / selected 等。

#### 元素自定义属性值 attr()

用户自己给元素添加的属性，我们称为自定义属性。 比如给 div 添加 index =“1”。 

**语法**

1.获取属性语法

```
attr("属性")  // 类似原生 getAttribute()
```

2.设置属性语法

```
attr("属性"，“属性值") // 类似原生 setAttribute()
```

该方法也可以获取H5自定义属性

注意：attr() 除了普通属性操作，更适合操作自定义属性。（该方法也可以获取 H5 自定义属性）

#### 数据缓存 data()

data() 方法可以在指定的元素上存取数据，并不会修改 DOM 元素结构。一旦页面刷新，之前存放的数据都将被移除。 

**语法**

1.附加数据语法

```
data("name","value") // 向被选元素附加数据
```

2.获取数据语法

```
date("name") // 向被选元素获取数据
```

注意：同时，还可以读取 HTML5 自定义属性  data-index ，得到的是数字型。

**演示代码**

```html
<body>
<a href="http://www.baidu.com" title="都挺好">都挺好</a>
<input type="checkbox" name="input" checked="checked">
<div index="1" data-index="2">我是div</div>
<span>123</span>
<script>
  $(function () {
    // 1. element.prop("属性名") 获取元素固有的属性值
    console.log('a.href:\t', $('a').prop('href'))
    // 两个值会就给元素设置值
    $('a').prop('title', '我们都挺好')
    console.log('a:\t', $('a').get(0))

    // 监听按钮切换
    $('input').change(function () {
      console.log('input.checked:\t' + $(this).prop('checked'))
    })

    // 2. attr 元素的自定义属性
    $('div').attr('index', 2)
    console.log('div.index:\t', $('div').get(0))

    // 3. 数据缓存 data() 这个里面的数据是存放在元素的内存里面
    $('div').data('index', 4)
    console.log('div.data-index: ', $('div').get(0))

    $('span').data('uname', 'andy')
    console.log('span.uname: ', $('span').get(0), $('span').data('uname'))
  })
</script>
</body>
```

#### 案例：购物车案例模块-全选

案例源码见课件

1. 全选思路：里面3个小的复选框按钮（j-checkbox）选中状态（checked）跟着全选按钮（checkall）走。
2. 因为checked 是复选框的固有属性，此时我们需要利用prop()方法获取和设置该属性。
3. 把全选按钮状态赋值给3小复选框就可以了。
4. 当我们每次点击小的复选框按钮，就来判断：
5. 如果小复选框被选中的个数等于3 就应该把全选按钮选上，否则全选按钮不选。
6. :checked 选择器      :checked 查找被选中的表单元素。

```JavaScript
        /* 1. 全选 全不选功能模块 */
        // 就是把全选按钮（checkall）的状态赋值给 三个小的按钮（j-checkbox）就可以了
        // 事件可以使用change
        $(".checkall").change(function () {
            // console.log($(this).prop("checked"));
            $(".j-checkbox, .checkall").prop("checked", $(this).prop("checked"));
            if ($(this).prop("checked")) {
                // 让所有的商品添加 check-cart-item 类名
                $(".cart-item").addClass("check-cart-item");
            } else {
                // check-cart-item 移除
                $(".cart-item").removeClass("check-cart-item");
            }
        });
        /*2. 如果小复选框被选中的个数等于3 就应该把全选按钮选上，否则全选按钮不选。*/
        $(".j-checkbox").change(function () {
            // if(被选中的小的复选框的个数 === 3) {
            //     就要选中全选按钮
            // } else {
            //     不要选中全选按钮
            // }
            // console.log($(".j-checkbox:checked").length);
            // $(".j-checkbox").length 这个是所有的小复选框的个数
            if ($(".j-checkbox:checked").length === $(".j-checkbox").length) {
                $(".checkall").prop("checked", true);
            } else {
                $(".checkall").prop("checked", false);
            }
            if ($(this).prop("checked")) {
                // 让当前的商品添加 check-cart-item 类名
                $(this).parents(".cart-item").addClass("check-cart-item");
            } else {
                // check-cart-item 移除
                $(this).parents(".cart-item").removeClass("check-cart-item");
            }
        });
```



### jQuery 文本属性值

jQuery的文本属性值常见操作有三种：html() / text() / val() ; 分别对应JS中的 innerHTML 、innerText 和 value 属性。

**jQuery内容文本值** 

常见操作有三种：html() / text() / val() ; 分别对应JS中的 innerHTML 、innerText 和 value 属性，主要针对元素的内容还有表单的值操作。

**语法**

1.普通元素内容html0 ( 相当于原生inner HTML)

```JavaScript
html() //获取元素的内容
html("内容") // 设置元素的内容
```

2.普通元素文本内容text( (相当与原生 innerText)

```JavaScript
text()   //获取元素的文本内容
text("文本内容") // 设置元素的文本内容
```

3.表单的值val()  (相当于原生value)

```JavaScript
val()  //获取表单的值
val("内容") // 设置表单的值
```

注意：html() 可识别标签，text() 不识别标签。

**演示代码**

```html
<body>
<div>
    <span>正心老师</span>
</div>
<input type="text" value="请输入内容">
<script>
  // 1. 获取设置元素内容 html()
  console.log('div.html:\t', [$('div').html()])
  $('div').html('123')
  // console.log('div.html:\t', [$('div').html()])

  // 2. 获取设置元素文本内容 text()
  console.log('div.text:\t', [$('div').text()])
  $('div').text('123')
  console.log('div.text:\t', [$('div').text()])

  // 3. 获取设置表单值 val()
  console.log('input.value:\t', [$('input').val()])
  $('input').val('123')

  // 数据同步
  $('input').change(function () {
      $('div').text($(this).val())
  })
</script>
</body>
```

#### 案例：增减商品数量

1. 核心思路：首先声明一个变量，当我们点击+号（increment），就让这个值++，然后赋值给文本框。
2. 注意1： 只能增加本商品的数量， 就是当前+号的兄弟文本框（itxt）的值。 
3. 修改表单的值是val() 方法
4. 注意2： 这个变量初始值应该是这个文本框的值，在这个值的基础上++。要获取表单的值
5. 减号（decrement）思路同理，但是如果文本框的值是1，就不能再减了。



#### 案例：修改商品小计

1. 核心思路：每次点击 + 号或者 - 号，根据文本框的值 乘以 当前商品的价格  就是 商品的小计
2. 注意1： 只能增加本商品的小计， 就是当前商品的小计模块（p-sum）  
3. 修改普通元素的内容是text() 方法
4. 注意2： 当前商品的价格，要把￥符号去掉再相乘 截取字符串 substr(1)
5. parents(‘选择器’) 可以返回指定祖先元素  
6. 最后计算的结果如果想要保留2位小数 通过 toFixed(2)  方法
7. 用户也可以直接修改表单里面的值，同样要计算小计。 用表单change事件
8. 用最新的表单内的值 乘以 单价即可  但是还是当前商品小计

```JavaScript
        /*3. 增减商品数量模块 首先声明一个变量，当我们点击+号（increment），就让这个值++，然后赋值给文本框。*/
        $(".increment").click(function () {
            // 得到当前兄弟文本框的值
            var n = $(this).siblings(".itxt").val();
            // console.log(n);
            n++;
            $(this).siblings(".itxt").val(n);
            // 3. 计算小计模块 根据文本框的值 乘以 当前商品的价格  就是 商品的小计
            // 当前商品的价格 p
            var p = $(this).parents(".p-num").siblings(".p-price").html();
            // console.log(p);  ￥25.20 去掉第一个字符
            p = p.substr(1);
            console.log(p);
            var price = (p * n).toFixed(2);
            // 小计模块
            // toFixed(2) 可以让我们保留2位小数
            $(this).parents(".p-num").siblings(".p-sum").html("￥" + price);
            getSum();
        });
        $(".decrement").click(function () {
            // 得到当前兄弟文本框的值
            var n = $(this).siblings(".itxt").val();
            if (n == 1) {
                return false;
            }
            // console.log(n);
            n--;
            $(this).siblings(".itxt").val(n);
            // var p = $(this).parent().parent().siblings(".p-price").html();
            // parents(".p-num") 返回指定的祖先元素
            var p = $(this).parents(".p-num").siblings(".p-price").html();
            // console.log(p);
            p = p.substr(1);
            console.log(p);
            // 小计模块
            $(this).parents(".p-num").siblings(".p-sum").html("￥" + (p * n).toFixed(2));
            getSum();
        });
```



### jQuery 元素操作

jQuery 元素操作主要讲的是用jQuery方法，操作标签的遍历、创建、添加、删除等操作。

#### 遍历元素

jQuery 隐式迭代是对同一类元素做了同样的操作。 如果想要给同一类元素做不同操作，就需要用到遍历。

**语法1** 


```JavaScript
$("div").each(function(index, domE1e) { xxx; })
```

1. each() 方法遍历匹配的每一个元素。 主要用DOM处理。each 每一个
2. 里面的回调函数有2个参数: index 是每个元素的索引号; demEle 是每个DOM元素对象，不是jquery对象
3. 所以要想使用jquery方法，需要给这个dom元素转换为jquery对象$(domEle)



注意：此方法用于遍历 jQuery 对象中的每一项，回调函数中元素为 DOM 对象，想要使用 jQuery 方法需要转换。

**语法2** 

```JavaScript
$.each(object,function(index,element){xx;})
```

1. $.each0方法可用于遍历任何对象。主要用于数据处理，比如数组，对象
2. 里面的函数有2个参数:index是每个元素的索引号;element遍历内容

注意：此方法用于遍历 jQuery 对象中的每一项，回调函数中元素为 DOM 对象，想要使用 jQuery 方法需要转换。

**演示代码**

```html
<body>
<div>1</div>
<div>2</div>
<div>3</div>
<script>
  $(function () {
    // $("div").css("color", "red");
    // 如果针对于同一类元素做不同操作，需要用到遍历元素（类似 for ，但是比 for 强大）
    var sum = 0
    // 1. each() 方法遍历元素
    var arr = ['red', 'green', 'blue']
    $('div').each(function (index, domEle) {
      // 回调函数第一个参数一定是索引号  可以自己指定索引号号名称
      // 回调函数第二个参数一定是 dom 元素对象 也是自己命名
      console.log('index:\t', index, domEle)

      // domEle.css("color"); dom 对象没有 css 方法
      $(domEle).css('color', arr[index])
      sum += parseInt($(domEle).text())
    })

    console.log('sum:\t', sum)

    // 2. $.each() 方法遍历元素 主要用于遍历数据，处理数据
    console.log('遍历数据')
    $.each($('div'), function (i, ele) {
      console.log(i, ele)
    })

    $.each(arr, function (i, ele) {
      console.log(i, ele)
    })

    console.log('遍历对象')
    $.each({
      name: 'andy',
      age: 18,
    }, function (i, ele) {
      console.log(i, ele) // 输出的是 key value
    })
  })
</script>
</body>
```

#### 案例：计算总计和总额

1. 把所有文本框中的值相加就是总额数量，总计同理。
2. 文本框里面的值不同，如果想要相加需要用 each() 遍历，声明一个变量做计数器，累加即可。

```JavaScript
		/*4. 用户修改文本框的值 计算 小计模块  */
        $(".itxt").change(function () {
            // 先得到文本框的里面的值 乘以 当前商品的单价
            var n = $(this).val();
            // 当前商品的单价
            var p = $(this).parents(".p-num").siblings(".p-price").html();
            // console.log(p);
            p = p.substr(1);
            $(this).parents(".p-num").siblings(".p-sum").html("￥" + (p * n).toFixed(2));
            getSum();
        });

        /*5. 计算总计和总额模块*/
        getSum();

        function getSum() {
            var count = 0; // 计算总件数
            var money = 0; // 计算总价钱
            $(".itxt").each(function (i, ele) {
                count += parseInt($(ele).val());
            });
            $(".amount-sum em").text(count);
            $(".p-sum").each(function (i, ele) {
                money += parseFloat($(ele).text().substr(1));
            });
            $(".price-sum em").text("￥" + money.toFixed(2));
        }
```



#### 创建、添加、删除

jQuery方法操作元素的创建、添加、删除方法很多，则重点使用部分，如下：

**语法总和**

**1. 创建**

```javascript
$("<li></li>");
```

动态的创建了一个 `<li>` 

2.1. 内部添加

```javascript
element.append("内容")
```

把内容放入匹配元素内部最后面，类似原生appendChild.

```javascript
  element.prepend("内容' ")
```

  把内容放入匹配元素内部最前面。

2.2 外部添加

```javascript
element.after("内容") //把内容放入目标元素后面

element.before("内容") // 把内容放入目标元素前面
```

① 内部添加元素，生成之后，它们是父子关系。

② 外部添加元素，生成之后，他们是兄弟关系。

3 删除元素

```javascript
element.remove() // 删除匹配的元素(本身)
element.empty() // 删除匹配的元素集合中所有的子节点
element.htm("") // 清空匹配的元素内容
```

①remove 删除元素本身。

②empt() 和 html("") 作用等价，都可以删除元素里面的内容，只不过html还可以设置内容。



注意：以上只是元素的创建、添加、删除方法的常用方法，其他方法请参详API。

**案例代码**

```html
<body>
<ul>
    <li style="color: red"> 原先的 li 1</li>
</ul>
<div class="test">我是原先的 div 1</div>
<script>
  $(function () {
    // 1. 创建元素
    var li0 = $('<li>我是后来创建的 li 0</li>')
    var li2 = $('<li>我是后来创建的 li 2</li>')
    // 2. 添加元素
    // 2.1 内部添加
    $("ul").append(li0);  // 内部添加并且放到内容的最后面
    $('ul').prepend(li2) // 内部添加并且放到内容的最前面

    // 2.2 外部添加
    var div0 = $('<div>我是后妈生的 div 0</div>')
    var div2 = $('<div>我是后妈生的 div 2</div>')
    $('.test').before(div0)
    $(".test").after(div2);

    // 3. 删除元素
    // $("ul").remove();  // 可以删除匹配的元素 自杀
    // $('ul').empty() // 可以删除匹配的元素里面的子节点 孩子
    // $("ul").html(""); // 可以删除匹配的元素里面的子节点 孩子
  })
</script>
</body>
```



#### 案例：删除商品模块

1. 核心思路：把商品remove() 删除元素即可
2. 有三个地方需要删除： 1. 商品后面的删除按钮 2. 删除选中的商品 3. 清理购物车
3. 商品后面的删除按钮： 一定是删除当前的商品，所以从 $(this) 出发
4. 删除选中的商品： 先判断小的复选框按钮是否选中状态，如果是选中，则删除对应的商品
5. 清理购物车： 则是把所有的商品全部删掉



#### 案例：选中商品添加背景

1. 核心思路：选中的商品添加背景，不选中移除背景即可
2. 全选按钮点击：如果全选是选中的，则所有的商品添加背景，否则移除背景
3. 小的复选框点击： 如果是选中状态，则当前商品添加背景，否则移除背景
4. 这个背景，可以通过类名修改，添加类和删除类



## 事件

### jQuery 事件注册

jQuery 为我们提供了方便的事件注册机制，是开发人员抑郁操作优缺点如下：

- 优点: 操作简单，且不用担心事件覆盖等问题。
- 缺点: 普通的事件注册不能做事件委托，且无法实现事件解绑，需要借助其他方法。

**语法** 

```JavaScript
element.事件(function() {})

$("div").click(function(){事件处理程序 })
```

其他事件和原生基本一致

比如 mouseover、mouseout、 blur、 focus、change、 keydown、 keyup、resize、scroll 等

**演示代码** 

```html
<body>
    <div></div>
    <script>
        $(function() {
            // 1. 单个事件注册
            $("div").click(function() {
                $(this).css("background", "purple");
            });
            $("div").mouseenter(function() {
                $(this).css("background", "skyblue");
            });
        })
    </script>
</body>
```

### jQuery 事件处理

因为普通注册事件方法的不足，jQuery又开发了多个处理方法，重点讲解如下：

- on(): 用于事件绑定，目前最好用的事件绑定方法
- off(): 事件解绑
- trigger() / triggerHandler(): 事件触发

#### 事件处理 on() 绑定事件

因为普通注册事件方法的不足，jQuery又创建了多个新的事件绑定方法bind() / live() / delegate() / on()等，其中最好用的是: on()

**语法**

+ on() 方法优势1:

  可以绑定多个事件，多个处理事件处理

  ```javascript
  $("div").on({
  	mouseover: function(){},
  	mouseout: function(){},
  	click: functioni (){}
  });
  ```
  

如果事件处理程序相同

```javascript
  $("div").on("mouseover mouseout", function () {
      $(this).toggleClass("current");
  });
```

+ on() 方法优势2:

  可以事件委派操作。事件委派定义是，把原来加给子元素身上的事件绑定在父元素身上，就是把事件委派给父元素。

  ```javascript
  $('ul').on("click", "li"， function() {
      alert ( 'he1lo world!') ;
  });
  ```
  
  在此之前有bind(), live(),delegate()等方法来处理事件绑定或者事件委派，最新版本的请用on替代他们。
  
+ on() 方法优势3:

  动态创建的元素，click() 没有办法绑定事件。on()可以给动态生成的元素绑定事件

  ```javascript
  $("div" ).on("click"，"P", function(){ 
  	alert("俺可以给动态生成的元素绑定事件")
  }):
  ```
  
```javascript
  $("div").append($("<p>我是动态创建的p</p>"));
```

**演示代码** 

```html
<body>
    <div></div>
    <ul>
        <li>我们都是好孩子</li>
        <li>我们都是好孩子</li>
        <li>我们都是好孩子</li>
    </ul>
    <ol></ol>

    <script>
        $(function() {
            // (1) on可以绑定1个或者多个事件处理程序
            // $("div").on({
            //     mouseenter: function() {
            //         $(this).css("background", "skyblue");
            //     },
            //     click: function() {
            //         $(this).css("background", "purple");
            //     }
            // });
            $("div").on("mouseenter mouseleave", function() {
                $(this).toggleClass("current");
            });
  
            // (2) on可以实现事件委托（委派）
            // click 是绑定在ul 身上的，但是 触发的对象是 ul 里面的小li
            // $("ul li").click();
            $("ul").on("click", "li", function() {
                alert(11);
            });

            // (3) on可以给未来动态创建的元素绑定事件
            $("ol").on("click", "li", function() {
                alert(11);
            })
            var li = $("<li>我是后来创建的</li>");
            $("ol").append(li);
        })
    </script>
</body>
```

#### 案例：发布微博案例

1. 点击发布按钮， 动态创建一个小li，放入文本框的内容和删除按钮， 并且添加到ul 中。
2. 点击的删除按钮，可以删除当前的微博留言。

```css
* {margin: 0;padding: 0}
ul {list-style: none}
.box {width: 600px;margin: 100px auto;border: 1px solid #000;padding: 20px;}
textarea {width: 450px;height: 160px;outline: none;resize: none;}
ul {width: 450px;padding-left: 80px;}
ul li {line-height: 25px;border-bottom: 1px dashed #cccccc;display: none;}
input {float: right;}
ul li a {float: right;}
```



```html
<body>
<div class="box" id="weibo"><span>微博发布</span> 
    <textarea name="" class="txt" cols="30" rows="10"></textarea>
    <button class="btn">发布</button>
    <ul></ul>
</div>
</body>
```



```html
<script>
    $(function () {
        // 1.点击发布按钮， 动态创建一个小li，放入文本框的内容和删除按钮， 并且添加到ul 中        
        $(".btn").on("click", function () {
            var li = $("<li></li>");
            li.html($(".txt").val() + "<a href='javascript:;'> 删除</a>");
            $("ul").prepend(li);
            li.slideDown();
            $(".txt").val("");
        });
        // 2.点击的删除按钮，可以删除当前的微博留言li        
        // $("ul a").click(function() {  
        // 此时的click不能给动态创建的a添加事件        
        //     alert(11);        
        // })      
        // on可以给动态创建的元素绑定事件            
        $("ul").on("click", "a", function () {
            $(this).parent().slideUp(function () {
                $(this).remove();
            });
        });
    })
</script>
```



#### 事件处理 off() 解绑事件

当某个事件上面的逻辑，在特定需求下不需要的时候，可以把该事件上的逻辑移除，这个过程我们称为事件解绑。jQuery 为我们提供 了多种事件解绑方法：die() / undelegate() / off() 等，甚至还有只触发一次的事件绑定方法 one()，在这里我们重点讲解一下 off() ;

**语法**

off(方法可以移除通过on0方法添加的事件处理程序。

```javascript
$("p").off() // 解绑p元素所有事件处理程序
$("p").off("click") // 解绑p元素上面的点击事件后面的foo是监听函数名
$("ul").off("click", "li"); // 解绑事件委托
```

如果有的事件只想触发一次，可以使用one()来绑定事件。

**演示代码**

```html
<body>
    <div></div>
    <ul>
        <li>我们都是好孩子</li>
        <li>我们都是好孩子</li>
        <li>我们都是好孩子</li>
    </ul>
    <p>我是一个P标签</p>
	<script>
        $(function() {
  			// 事件绑定
            $("div").on({
                click: function() {
                    console.log("我点击了");
                },
                mouseover: function() {
                    console.log('我鼠标经过了');
                }
            });
            $("ul").on("click", "li", function() {
                alert(11);
            });
  
            // 1. 事件解绑 off 
            // $("div").off();  // 这个是解除了div身上的所有事件
            $("div").off("click"); // 这个是解除了div身上的点击事件
            $("ul").off("click", "li");
  
            // 2. one() 但是它只能触发事件一次
            $("p").one("click", function() {
                alert(11);
            })
        })
    </script>
</body>
```

#### 事件处理 trigger() 自动触发事件

有些时候，在某些特定的条件下，我们希望某些事件能够自动触发, 比如轮播图自动播放功能跟点击右侧按钮一致。可以利用定时器自动触发右侧按钮点击事件，不必鼠标点击触发。由此 jQuery 为我们提供了两个自动触发事件 trigger() 和 triggerHandler() ; 

**语法**

+ 第一种: trigger()

  ```JavaScript
  element.click() // 第一种简写形式
  element.trigger("type") //第二种自动触发模式
  ```
  
+ 第二种: triggerHandler()

  ```JavaScript
  element.triggerHandler(type) // 第三种自动触发模式
  ```
  

triggerHandler模式不会触发元素的默认行为，这是和前面两种的区别。

**演示代码**

```html
<body>
    <div></div>
    <input type="text">
      
    <script>
    $(function() {
      // 绑定事件
      $("div").on("click", function() {
        alert(11);
      });

      // 自动触发事件
      // 1. 元素.事件()
      // $("div").click();会触发元素的默认行为
      
      // 2. 元素.trigger("事件")
      // $("div").trigger("click");会触发元素的默认行为
      $("input").trigger("focus");
      
      // 3. 元素.triggerHandler("事件") 就是不会触发元素的默认行为
      $("input").on("focus", function() {
        $(this).val("你好吗");
      });
      // 一个会获取焦点，一个不会
      $("div").triggerHandler("click");
      // $("input").triggerHandler("focus");
    });
    </script>
</body>
```

### jQuery 事件对象

jQuery 对DOM中的事件对象 event 进行了封装，兼容性更好，获取更方便，使用变化不大。事件被触发，就会有事件对象的产生。

**语法**

```javascript
element.on(events, [selector], function(event) {})
```

阻止默认行为: event.preventDefault() 或者 return false

阻止冒泡: event.stopPropagation()

**演示代码**

```html
<body>
    <div></div>

	<script>
        $(function() {
            $(document).on("click", function() {
                console.log("点击了document");
            })
            $("div").on("click", function(event) {
                // console.log(event);
                console.log("点击了div");
                event.stopPropagation();
            })
        })
    </script>
</body>
```

注意：jQuery中的 event 对象使用，可以借鉴 API 和 DOM 中的 event 。

### jQuery 拷贝对象

jQuery中分别为我们提供了两套快速获取和设置元素尺寸和位置的API，方便易用，内容如下。

**语法**

```javascript
$.extend([deep]，target, object1， [objectN] )
```

1. deep:如果设为true为深拷贝，默认为false 浅拷贝
2. target:要拷贝的目标对象
3. object1:待拷贝到第一个对象的对象。
4. objectN:待拷贝到第N个对象的对象。
5. 浅拷贝目标对象引用的被拷贝的对象地址，修改目标对象会影响被拷贝对象。
6. 深拷贝，前面加true，完全克隆， 修改目标对象不会影响被拷贝对象。

**演示代码** 

```html
<script>
    $(function() {
        // 1.合并数据
        var targetObj = {};
        var obj = {
            id: 1,
            name: "andy"
        };
        // $.extend(target, obj);
        $.extend(targetObj, obj);
        console.log(targetObj);

        // 2. 会覆盖 targetObj 里面原来的数据
        var targetObj = {
            id: 0
        };
        var obj = {
            id: 1,
            name: "andy"
        };
        // $.extend(target, obj);
        $.extend(targetObj, obj);
        console.log(targetObj); 
    })
</script>
```

## Ajax

### Ajax基础

#### 传统网站中存在的问题

+ 网速慢的情况下，页面加载时间长，用户只能等待
+ 表单提交后，如果一项内容不合格，需要重新填写所有表单内容
+ 页面跳转，重新加载页面，造成资源浪费，增加用户等待时间


#### Ajax 概述

Ajax：标准读音 [ˈeɪˌdʒæks] ，中文音译：阿贾克斯

它是浏览器提供的一套方法，可以实现页面无刷新更新数据，提高用户浏览网站应用的体验。

![image-20201109001648004](../assets/image-20201109001648004.png)

#### Ajax 的应用场景

1. 页面上拉加载更多数据
2. 列表数据无刷新分页
3. 表单项离开焦点数据验证
4. 搜索框提示文字下拉列表

![image-20201109001735326](../assets/image-20201109001735326.png)

![image-20201109001741445](../assets/image-20201109001741445.png)

#### Ajax的运行环境

Ajax 技术  <span style="color:red;">需要运行在网站环境中才能生效</span> ，当前课程会使用 Flask 创建的服务器作为网站服务器。

### Ajax 运行原理

Ajax 相当于浏览器发送请求与接收响应的代理人，以实现在不影响用户浏览页面的情况下，局部更新页面数据，从而提高用户体验。

![image-20201109001851935](../assets/image-20201109001851935.png)


#### Ajax 的实现步骤

1. 创建 Ajax 对象

   ```javascript
   var xhr = new XMLHttpRequest();
   ```

2. 告诉 Ajax 请求地址以及请求方式

   ```javascript
   xhr.open('get', 'http://www.example.com');
   ```

3. 发送请求

   ```javascript
   xhr.send();
   ```

4. 获取服务器端给与客户端的响应数据

   ```javascript
   xhr.onload = function () {
       console.log(xhr.responseText);
   }
   ```

#### 服务器端响应的数据格式

在真实的项目中，服务器端 <span style="color:red;" data-comp="版权所有，青灯教育">大多数情况下会以 JSON 对象作为响应数据的格式</span>  。当客户<span> </span> 端拿到响应数据时，要将 JSON 数据和 HTML 字符串进行拼接，然后将拼接的结果展示在页面中。

在 http 请求与响应的过程中，无论是请求参数还是响应内容，如果是对象类型，最终都会被转换为对象字符串进行传输。

```javascript
JSON.parse()   // 将 json 字符串转换为json对象
```



#### 请求参数传递

传统网站表单提交

```html
<form method="get" action="http://www.example.com">
    <input type="text" name="username"/>
    <input type="password" name="password">
</form>

<!– http://www.example.com?username=zhangsan&password=123456 -->
```


+ GET 请求方式

  ```javascript
  xhr.open('get', 'http://www.example.com?name=zhangsan&age=20');
  ```

+ POST 请求方式

  ```javascript
  xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded') xhr.send('name=zhangsan&age=20');
  ```



#### 请求报文

在 HTTP 请求和响应的过程中传递的数据块就叫报文，包括要传送的数据和一些附加信息，这些数据和信息要遵守规定好的格式。

![image-20201110141635781](../assets/image-20201110141635781.png)

#### 请求参数的格式

1. application/x-www-form-urlencoded

   ```javascript
   name=zhangsan&age=20&sex=男
   ```

2. application/json

   ```javascript
   {name: 'zhangsan', age: '20', sex: '男'}
   ```

   在请求头中指定 Content-Type 属性的值是 application/json，告诉服务器端当前请求参数的格式是 json。

   ```javascript
   JSON.stringify() // 将json对象转换为json字符串
   ```

 <span style="color:red;">注意：get 请求是不能提交 json 对象数据格式的，传统网站的表单提交也是不支持 json 对象数据格式的。
</span> 



#### 获取服务器端的响应

##### Ajax 状态码

在创建ajax对象，配置ajax对象，发送请求，以及接收完服务器端响应数据，这个过程中的每一个步骤都会对应一个数值，这个数值就是ajax状态码。

0：请求未初始化(还没有调用open())
1：请求已经建立，但是还没有发送(还没有调用send())
2：请求已经发送
3：请求正在处理中，通常响应中已经有部分数据可以用了
4：响应已经完成，可以获取并使用服务器的响应了

```javascript
xhr.readyState // 获取Ajax状态码
```

##### Ajax 错误处理

1. 网络畅通，服务器端能接收到请求，服务器端返回的结果不是预期结果。
   <span style="color:red;">可以判断服务器端返回的状态码，分别进行处理。xhr.status 获取http状态码</span> 
2. 网络畅通，服务器端没有接收到请求，返回404状态码。
   <span style="color:red;">检查请求地址是否错误。</span> 
3. 网络畅通，服务器端能接收到请求，服务器端返回500状态码。
   <span style="color:red;">服务器端错误，找后端程序员进行沟通。</span> 
4. 网络中断，请求无法发送到服务器端。
   <span style="color:red;">会触发xhr对象下面的onerror事件，在onerror事件处理函数中对错误进行处理。</span> 



### $.ajax()

#### $.ajax()方法概述

作用：发送Ajax请求。

```javascript
$.ajax({
    type: 'get',
    url: 'http://www.example.com',
    data: { name: 'zhangsan', age: '20' },
    contentType: 'application/x-www-form-urlencoded',
    beforeSend: function () { 
        return false
    },
    success: function (response) {},
    error: function (xhr) {}
});
```

```javascript
{
    data: 'name=zhangsan&age=20'
}
```

```javascript
{
    contentType: 'application/json'
}
```

```javascript
JSON.stringify({name: 'zhangsan', age: '20'})
```



#### `$.get()`、`$.post()` 方法概述

作用：$.get方法用于发送get请求，$.post方法用于发送post请求。

```javascript
$.get('http://www.example.com', {name: 'zhangsan', age: 30}, function (response) {}) 
$.post('http://www.example.com', {name: 'lisi', age: 22}, function (response) {})
```

#### 案例：省市区联动

```html
<link rel="stylesheet" href="bootstrap.min.css">
<style type="text/css">
    .container {
        padding-top: 150px;
    }
</style>
```

```html
<div class="container">
    <div class="form-inline">
        <div class="form-group">
            <select class="form-control" id="province"></select>
        </div>
        <div class="form-group">
            <select class="form-control" id="city">
                <option>请选择城市</option>
            </select>
        </div>
        <div class="form-group">
            <select class="form-control" id="area">
                <option>请选择县城</option>
            </select>
        </div>
    </div>
</div>
```

```html
<script src="ajax.js"></script>
<script>
    // 获取省市区下拉框元素
    var province = document.getElementById('province');
    var city = document.getElementById('city');
    var area = document.getElementById('area');
    // 获取省份信息
    ajax({
        type: 'get',
        url: 'http://localhost:5000/province',
        success: function (data) {
            // 将服务器端返回的数据和html进行拼接
            // {#var html = template('provinceTpl', {province: data});#}
            html = "<option>请选择省份</option>"
            data.forEach(function (item) {
                html += "<option value=" + item.id + ">" + item.name + "</option>"
            })
            // 将拼接好的html字符串显示在页面中
            province.innerHTML = html;
        }
    });

    // 为省份的下拉框添加值改变事件
    province.onchange = function () {
        // 获取省份id
        var pid = this.value;

        // 清空县城下拉框中的数据
        var html = "<option>请选择县城</option>";
        area.innerHTML = html;

        // 根据省份id获取城市信息
        ajax({
            type: 'get',
            url: 'http://127.0.0.1:5000/cities',
            data: {
                id: pid
            },
            success: function (data) {
                var html = "<option>请选择县城</option>"
                data.forEach(function (item) {
                    html += '<option value="'+item.id+'">'+item.name+'</option>'
                })
                city.innerHTML = html;
            }
        })
    };
    // 当用户选择城市的时候
    city.onchange = function () {
        // 获取城市id
        var cid = this.value;
        // 根据城市id获取县城信息
        ajax({
            type: 'get',
            url: 'http://localhost:5000/areas',
            data: {
                id: cid
            },
            success: function (data) {
                var html = '<option>请选择县城</option>';
                data.forEach(function (item) {
                    html += '<option value="'+item.id+'">'+item.name+'</option>'
                })
                area.innerHTML = html;
            }
        })
    }
</script>
```

## 附录

restful 风格指南：http://www.ruanyifeng.com/blog/2014/05/restful_api.html

