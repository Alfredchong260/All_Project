### 查询页面与数据库表格样式

![在这里插入图片描述](assets/c244cc3b92fc7a18ed83e05ab573e113.png)
1）数据库表格样式前端layui代码如下所示：

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <link rel="stylesheet" href="../static/layui/css/layui.css">
</head>
<body>
<!--搜索条件开始-->

<div class="layui-fluid">
    <div class="layui-card" style="background-color: #fafafa;padding: 20px">
        <div class="layui-card-header">
            <h2 style="margin-left:50px ">表单查询</h2>
        </div>
        <div class="layui-card-body">
            <form class="layui-form" action="" method="post" id="formTest">
                <div class="layui-form-item">
                    <div class="layui-inline">
                        <label class="layui-form-label">学号</label>
                        <div class="layui-input-inline">
                            <input type="text" name="no" autocomplete="off" class="layui-input">
                        </div>
                    </div>
                    <div class="layui-inline">
                        <label class="layui-form-label">姓名</label>
                        <div class="layui-input-inline">
                            <input type="text" name="username" autocomplete="off" class="layui-input">
                        </div>
                    </div>
                    <div class="layui-inline">
                        <label class="layui-form-label">邮箱</label>
                        <div class="layui-input-inline">
                            <input type="text" name="email" autocomplete="off" class="layui-input">
                        </div>
                    </div>
                </div>

                <div class="layui-form-item">
                    <div class="layui-inline">
                        <label class="layui-form-label">开始时间</label>
                        <div class="layui-input-inline">
                            <input type="text" class="layui-input" name="start_time" readonly="readonly" id="start_time"
                                   placeholder="yyyy-MM-dd">
                        </div>
                    </div>
                    <div class="layui-inline">
                        <label class="layui-form-label">结束时间</label>
                        <div class="layui-input-inline">
                            <input type="text" class="layui-input" name="endtime" readonly="readonly" id="endtime"
                                   placeholder="yyyy-MM-dd">
                        </div>
                    </div>
                    <div class="layui-inline">
                        <label class="layui-form-label">单选框</label>
                        <div class="layui-input-block">
                            <input type="radio" name="gender" value="男" title="男" checked="">
                            <input type="radio" name="gender" value="女" title="女">
                        </div>
                    </div>
                </div>

                <div class="layui-form-item" style="text-align: center;margin-top: 50px;">
                    <div class="layui-input-block">
                        <button type="submit"
                                class="layui-btn layui-btn-sm layui-icon layui-icon-search"
                                id="doSubmit" lay-submit="" lay-filter="form-query">&nbsp;查询
                        </button>
                        <button type="reset" class="layui-btn layui-btn-sm layui-icon layui-icon-refresh"
                                id="doReset">&nbsp;重置
                        </button>
                    </div>
                </div>

            </form>
        </div>
    </div>
</div>


<!--数据表格开始-->
<div class="layui-fluid">
    <table class="layui-hide" id="userTable" lay-filter="userTable"></table>
</div>
<div type="text/html" style="display: none" id="userToolBar">
    <a type="submit" class="layui-btn layui-btn-xs" lay-event="toolbar-add">添加</a>
    <a type="submit" class="layui-btn layui-btn-xs" lay-event="toolbar-del">批量删除</a>
</div>

<div id="userBar" style="display: none;">
    <a class="layui-btn layui-btn-xs" lay-event="tool-edit" id="modify">编辑</a>
    <a class="layui-btn layui-btn-danger layui-btn-xs" lay-event="tool-del">删除</a>
</div>

<form class="layui-form" action="" method="post" lay-filter="editForm" id="editForm"
      style="display: none;margin-top: 50px;">
    <div class="layui-form-item">
        <div class="layui-inline" style="display: none;">
            <label class="layui-form-label">ID</label>
            <div class="layui-input-inline">
                <input type="text" name="id" autocomplete="off" class="layui-input">
            </div>
        </div>
        <div class="layui-inline">
            <label class="layui-form-label">学号</label>
            <div class="layui-input-inline">
                <input type="text" name="no" autocomplete="off" class="layui-input">
            </div>
        </div>
        <div class="layui-inline">
            <label class="layui-form-label">姓名</label>
            <div class="layui-input-inline">
                <input type="text" name="name" autocomplete="off" class="layui-input">
            </div>
        </div>
    </div>
    <div class="layui-form-item">
        <div class="layui-inline">
            <label class="layui-form-label">邮箱</label>
            <div class="layui-input-inline">
                <input type="text" name="email" autocomplete="off" class="layui-input">
            </div>
        </div>

        <div class="layui-inline">
            <label class="layui-form-label">城市</label>
            <div class="layui-input-inline">
                <input type="text" name="city" autocomplete="off" class="layui-input">
            </div>
        </div>
    </div>

    <div class="layui-form-item">
        <label class="layui-form-label">性别</label>
        <div class="layui-input-block">
            <input type="radio" name="gender" value="男" title="男" checked="">
            <input type="radio" name="gender" value="女" title="女">
        </div>
    </div>

    <div class="layui-form-item" style="text-align: center;">
        <div class="layui-input-block">
            <button type="button" class="layui-btn layui-btn-sm" lay-submit lay-filter="edit-submit">
                <i class="layui-icon layui-icon-release"></i>
                &nbsp;提交
            </button>
            <button type="reset" class="layui-btn layui-btn-sm">
                <i class="layui-icon layui-icon-refresh"></i>
                &nbsp;重置
            </button>
        </div>
    </div>
</form>

<script src="/static/layui/layui.js"></script>
</body>
</html>
```

2）数据库表格样式
建表语句如下

```sql
use python;

create table `student_info`
(
    `id`           int(11)     NOT NULL AUTO_INCREMENT,
    `student_id`   varchar(30) NOT NULL DEFAULT '',
    `student_name` varchar(30) NOT NULL DEFAULT '',
    `email`        varchar(30) NOT NULL DEFAULT '',
    `sex`          varchar(10) NOT NULL DEFAULT '',
    `city`         varchar(30) NOT NULL DEFAULT '',
    `insert_time`  datetime             DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`)
);
truncate student_info;
insert into student_info (`student_id`, `student_name`, `email`, `sex`, `city`)
values ('000001', '杨斌', 'hejun@example.net', '女', '东市'),
       ('000002', '邓洋', 'xianglei@example.net', '男', '佛山县'),
       ('000003', '刘勇', 'qiujing@example.com', '男', '志强县'),
       ('000004', '王萍', 'qiang72@example.org', '女', '红梅市'),
       ('000005', '李成', 'ldeng@example.net', '女', '西宁市'),
       ('000006', '陈玉华', 'ukong@example.net', '女', '澳门市'),
       ('000007', '谭帆', 'gkong@example.com', '女', '柳州市'),
       ('000008', '张健', 'xiuying93@example.org', '男', '杨县'),
       ('000009', '李楠', 'huangjie@example.org', '男', '兰州市'),
       ('000010', '曾佳', 'yan89@example.com', '男', '北京县'),
       ('000011', '杨桂芳', 'atian@example.com', '女', '淑英市'),
       ('000012', '张红霞', 'xuqiang@example.org', '男', '梧州县'),
       ('000013', '孟桂花', 'sdu@example.net', '女', '石家庄县'),
       ('000014', '欧阳淑兰', 'ugu@example.net', '男', '石家庄县'),
       ('000015', '高萍', 'wenqiang@example.com', '男', '淑珍市'),
       ('000016', '周洁', 'jun39@example.com', '女', '淑兰市'),
       ('000017', '任帆', 'dengxia@example.com', '女', '海燕市'),
       ('000018', '郭玉英', 'cxu@example.net', '女', '桂芝市'),
       ('000019', '钟欢', 'ming06@example.net', '女', '北镇市'),
       ('000020', '姜玉梅', 'ping91@example.net', '女', '玉梅市'),
       ('000021', '岳艳', 'qxie@example.net', '男', '荆门市'),
       ('000022', '李秀云', 'wumin@example.net', '女', '凤英县'),
       ('000023', '黄成', 'ping45@example.net', '男', '凤英市'),
       ('000024', '余婷婷', 'changfang@example.com', '女', '马鞍山县'),
       ('000025', '潘岩', 'taona@example.org', '女', '佳市'),
       ('000026', '李鹏', 'molei@example.com', '男', '勇市'),
       ('000027', '王洁', 'dxie@example.com', '男', '丽娟县'),
       ('000028', '孙雪', 'uyan@example.org', '女', '宁德县'),
       ('000029', '徐莹', 'liangguiying@example.com', '女', '秀兰市'),
       ('000030', '杨丹', 'chaosu@example.net', '男', '南京县');
```

### 添加数据![在这里插入图片描述](assets/14fff57d10dd59b2cfc31dd646e10bc1.png)

前端layui代码如下所示：

```JavaScript
    //  头工具栏事件
    table.on('toolbar(userTable)', function(obj) {
      switch (obj.event) {
        case 'toolbar-add':
          window.openAddUser(obj);
          break;
        case 'toolbar-del':
          window.batch_del(obj);
          break;
      }
    });

    window.openAddUser = function() {
      layer.open({
        type: 2,
        title: '添加用户',
        shade: 0.1,
        content: '/student_add',
        area: ['800px', '400px'],
      });
    };
```

后端flask代码如下所示：

```python
@app.route('/student_add')
def student_add():
    return render_template('student_add.html')



class StudentAPI(MethodView):

    def post(self):
        # 创建一个新用户
        print(request.json)
        no = request.json.get('no')
        name = request.json.get('name')
        email = request.json.get('email')
        gender = request.json.get('gender')
        city = request.json.get('city')
        sql = f"insert into student_info (`student_id`, `student_name`, `email`, `sex`, `city`) values ('{no}', '{name}', '{email}', '{gender}', '{city}');"
        db.cursor.execute(sql)
        db.conn.commit()
        return {
            "code": 1,
            "message": "获取数据成功",
        }


student_view = StudentAPI.as_view('student_api')
app.add_url_rule('/student/', view_func=student_view, methods=['POST', ])
```



**薪资数据页面**

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <link rel="stylesheet" href="/static/layui/css/layui.css">
</head>
<body>

<div style="margin-top: 50px">
    <form class="layui-form" action="" method="post" lay-filter="dataFrm" id="dataFrm">
        <div class="layui-form-item">
            <div class="layui-inline">
                <label class="layui-form-label">学号</label>
                <div class="layui-input-inline">
                    <input type="text" name="no" autocomplete="off" class="layui-input">
                </div>
            </div>
            <div class="layui-inline">
                <label class="layui-form-label">姓名</label>
                <div class="layui-input-inline">
                    <input type="text" name="name" autocomplete="off" class="layui-input">
                </div>
            </div>
        </div>
        <div class="layui-form-item">
            <div class="layui-inline">
                <label class="layui-form-label">邮箱</label>
                <div class="layui-input-inline">
                    <input type="text" name="email" autocomplete="off" class="layui-input">
                </div>
            </div>

            <div class="layui-inline">
                <label class="layui-form-label">城市</label>
                <div class="layui-input-inline">
                    <input type="text" name="city" autocomplete="off" class="layui-input">
                </div>
            </div>
        </div>

        <div class="layui-form-item">
            <label class="layui-form-label">性别</label>
            <div class="layui-input-block">
                <input type="radio" name="gender" value="男" title="男" checked="">
                <input type="radio" name="gender" value="女" title="女">
            </div>
        </div>

        <div class="layui-form-item" style="text-align: center;">
            <div class="layui-input-block">
                <button type="button" class="layui-btn layui-btn-sm layui-icon layui-icon-release"
                        id="submit" lay-submit lay-filter="submit">&nbsp;提交
                </button>
                <button type="reset" class="layui-btn layui-btn-sm layui-icon layui-icon-refresh"
                        id="doclose" lay-submit="" lay-filter="doclose" lay-event="doclose">&nbsp;重置
                </button>
            </div>
        </div>
    </form>
</div>
<script src="/static/layui/layui.js"></script>
<script>
  layui.use(function() {
    let form = layui.form;
    let $ = layui.$;

    form.on('submit(submit)', function(message) {
      $.ajax({
        url: '/student/',
        type: 'POST',
        dataType: 'json',
        contentType: 'application/json',
        data: JSON.stringify(message.field),
        beforeSend: function() {
          layer.load({
            shade: [0.1, '#fff'], // 0.1透明度的白色背景
          });
        },
        success: function(res) {
          let returnCode = res.code;
          if (returnCode === 1) {
            layer.closeAll('loading');
            layer.msg('修改成功', {icon: 6});
            parent.layer.close(parent.layer.getFrameIndex(window.name))//关闭当前页
            parent.layui.table.reload('userTable')

          } else {
            layer.closeAll('loading');
            layer.msg('修改失败', {icon: 5});
            parent.layui.table.reload('userTable')
          }
        },
      });
      return false;
    });
  });
</script>
</body>
</html>
```



### 删除单条数据

删除单条数据，实现数据库删除和页面更新
![在这里插入图片描述](assets/29b826d169f19582905cce1064cb64e8.png)
页面同步更新
![在这里插入图片描述](assets/20c663d5f33180b5eac3b79cdd33dcb4.png)

前端layui代码如下所示：

```JavaScript
    //  监听工具条
    table.on('tool(userTable)', function(obj) {
      // 注：tool 是工具条事件名，test 是 table 原始容器的属性 lay-filter="对应的值"
      var data = obj.data; // 获得当前行数据
      var layEvent = obj.event; // 获得 lay-event 对应的值（也可以是表头的 event 参数对应的值）

      if (layEvent === 'tool-del') {
        layer.confirm('真的删除这行数据么', {icon: 3, title: '提示'},
            function(index) {
              $.ajax({
                url: '/student/' + obj.data['id'],
                type: 'DELETE',
                dataType: 'json',
                contentType: 'application/json',
                success: function(res) {
                  let returnCode = res.code;
                  if (returnCode === 1) {
                    layer.msg('删除成功', {icon: 6});
                    setTimeout(function() {table.reload('userTable');}, 1000);
                  }
                },
              });
              layer.close(index);
            });
      }
      else if (layEvent === 'tool-edit') {
        // 编辑修改数据
        window.openUpdateUser(obj.data);
      }
    });

```

后端flask代码如下所示：

```python
class StudentAPI(MethodView):
	def get(self, stu_id):
        if stu_id is None:
            rets = db.fetch_students()
            return {
                "code": 0,
                "message": "获取数据成功",
                "data": rets,
                "count": len(rets)
            }
        else:
            # 显示一个用户
            sql = "select * from student_info where id='" + str(stu_id) + "';"
            db.cursor.execute(sql)
            student = db.cursor.fetchone()
            return {
                "code": 0,
                "message": "获取数据成功",
                "data": {
                    'id': student[0],
                    'no': student[1],
                    'name': student[2],
                    'email': student[3],
                    'gender': student[4],
                    'city': student[5],
                },
            }


    def delete(self, stu_id):
        # 删除一个用户
        sql = "DELETE FROM student_info WHERE id='" + str(stu_id) + "';"
        db.cursor.execute(sql)
        db.conn.commit()
        return {
            "code": 1,
            "message": "删除数据成功",
        }

    def put(self, stu_id):
        # update a single user
        # `student_id`, `student_name`, `email`, `sex`, `city`
        print(request.json)
        no = request.json.get('no')
        name = request.json.get('name')
        email = request.json.get('email')
        gender = request.json.get('gender')
        city = request.json.get('city')
        sql = f"UPDATE student_info SET student_id='{no}',student_name='{name}',email='{email}',sex='{gender}',city='{city}' WHERE id='{stu_id}';"
        db.cursor.execute(sql)
        db.conn.commit()
        return {
            "code": 1,
            "message": "修改数据成功",
        }

student_view = StudentAPI.as_view('student_api')
app.add_url_rule('/student/', defaults={'stu_id': None}, view_func=student_view, methods=['GET', ])
app.add_url_rule('/student/<int:stu_id>', view_func=student_view, methods=['GET', 'PUT', 'DELETE'])

```





### 编辑数据

点击编辑，编辑的数据自动加载到弹出层
![在这里插入图片描述](assets/590c28bb67470ba0133d34baf997c3fb.png)
数据修改成功
![在这里插入图片描述](assets/f75b4959c4f58c26833caef8d076b477.png)

前端layui代码如下所示：

```JavaScript
    //  打开修改页面，并把数据发送到后端
    window.openUpdateUser = function(data) {
      layer.open({
        type: 1,
        title: '修改用户',
        content: $('#editForm'),
        area: ['800px', '400px'],
        success: function() {
          form.val('editForm', data);
        },
      });
    };

    window.edit_student = function(obj) {
      $.ajax({
        url: '/student/' + obj.field['id'],
        type: 'PUT',
        dataType: 'json',
        contentType: 'application/json',
        data: JSON.stringify(obj.field),
        success: function(res) {
          let returnCode = res.code;
          if (returnCode === 1) {
            layer.msg('修改成功', {icon: 6});
            layer.closeAll();
            setTimeout(function() {table.reload('userTable');}, 1000);
          }
        },
      });

    };

```

后端flask代码如下所示：

```python
class StudentAPI(MethodView):

    def put(self, stu_id):
        # update a single user
        # `student_id`, `student_name`, `email`, `sex`, `city`
        print(request.json)
        no = request.json.get('no')
        name = request.json.get('name')
        email = request.json.get('email')
        gender = request.json.get('gender')
        city = request.json.get('city')
        sql = f"UPDATE student_info SET student_id='{no}',student_name='{name}',email='{email}',sex='{gender}',city='{city}' WHERE id='{stu_id}';"
        db.cursor.execute(sql)
        db.conn.commit()
        return {
            "code": 1,
            "message": "修改数据成功",
        }
```



### 指定条件查询数据

指定条件查出数据，未指定条件时随机查询数据
![在这里插入图片描述](assets/800f6b9d210c86ff9963f921df67f7d0.png)
前端layui代码如下所示：

```javascript
    // 表单查询
    form.on('submit(form-query)', function(obj) {
      table.reload('userTable', {where: obj.field});
      return false;
    });
```

后端flask代码如下所示：

```python

@app.route('/students', methods=['GET', 'DELETE'])
def students():  # put application's code here
    if request.method == 'GET':
        username = request.args.get('username')
        rets = []
        if username:
            sql = "select * from student_info where student_name like '%" + username + "%';"
            db.cursor.execute(sql)
            students = db.cursor.fetchall()
            for student in students:
                rets.append({
                    'id': student[0],
                    'no': student[1],
                    'name': student[2],
                    'email': student[3],
                    'gender': student[4],
                    'city': student[5],
                })
        else:
            rets = db.fetch_students()
        return {
            "code": 0,
            "message": "获取数据成功",
            "data": rets,
            "count": len(rets)
        }
    if request.method == 'DELETE':
        ids = request.json.get('ids')
        print(ids)
        rets = db.fetch_students()
        return {
            "code": 0,
            "message": "获取数据成功",
            "data": rets,
            "count": len(rets)
        }


```

### 批量删除数据

![在这里插入图片描述](assets/a468f4ada5ff37321dec77fa46119a0a.png)
删除后回显数据
![在这里插入图片描述](assets/832fc0c9f829bb233866bf0c59f9fa59.png)
前端layui代码如下所示：

```javascript
    //  头工具栏事件
    table.on('toolbar(userTable)', function(obj) {
      switch (obj.event) {
        case 'toolbar-add':
          window.openAddUser(obj);
          break;
        case 'toolbar-del':
          window.batch_del(obj);
          break;
      }
    });
    
    window.batch_del = function(obj) {
      let data = table.checkStatus(obj.config.id).data;
      console.log(data);
      if (data.length === 0) {
        alert('请选择要删除的数据');
      }
      let ids = [];

      for (let i = 0; i < data.length; i++) {
        ids.push(data[i].no);
      }

      $.ajax({
        url: '/students',
        data: JSON.stringify({'ids': ids.toString()}),
        type: 'delete',
        dataType: 'json',
        contentType: 'application/json',
        success: function(res) {
          if (res.code === 1) {
            layer.msg('删除成功');
            table.reload('userTable');
          } else {
            layer.msg('删除失败');
          }
        },
      });
    };

```

后端flask代码如下所示：

```python
@app.route('/students', methods=['GET', 'DELETE'])
def students():  # put application's code here
    
    if request.method == 'DELETE':
        ids = request.json.get('ids')
        print(ids)
        rets = db.fetch_students()
        # 实现删除逻辑
        return {
            "code": 0,
            "message": "获取数据成功",
            "data": rets,
            "count": len(rets)
        }

```

### 重置按钮清空页面和弹出层数据

![在这里插入图片描述](assets/ee38c837ac0e5e12ac4fce1682fbd674.png)

```javascript
    form.on('#doReset', function(data) {
      $('#formTest')[0].reset();
      return false;
    });
```

### 选择显示的字段

![在这里插入图片描述](assets/aee6ba6f990fcc8514741960c182d3d4.png)

### 双击页面行数据只从页面删除数据

![在这里插入图片描述](assets/9edc347e477a263bff9a5fcbf547a777.png)
双击后页面如下所示
![在这里插入图片描述](assets/6ebc6ad3e7f7f07558e90c40176b8778.png)

```
    table.on('rowDouble(userTable)', function(obj) {
      console.log(obj.tr); //得到当前行元素对象
      console.log(obj.data); //得到当前行数据
      obj.del(); //删除当前行
      //obj.update(fields) //修改当前行数据
    });
```

