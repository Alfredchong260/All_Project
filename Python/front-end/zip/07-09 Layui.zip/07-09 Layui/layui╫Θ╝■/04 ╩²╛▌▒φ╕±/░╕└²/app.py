from flask import Flask, jsonify, request
from flask_cors import CORS
from db import students

app = Flask(__name__)
CORS().init_app(app)


@app.get('/users')
def users():
    # 分页信息获取
    page = request.args.get('page', type=int, default=1)
    limit = request.args.get('limit', type=int, default=10)
    start = (page - 1) * limit
    data = students[start:start + limit]
    ret = {"code": 0, "message": "", "count": len(students), "data": data, 'success': True}
    return jsonify(ret)


@app.post('/users/add')
def users_add():
    # 分页信息获取
    address = request.json.get('address')
    birth = request.json.get('birth')
    phone = request.json.get('phone')
    username = request.json.get('username')
    students.append({'address': address, 'birth': birth,
                     'phone': phone, 'username': username})
    ret = {"code": 200, "message": "数据添加成功", 'success': True}
    return jsonify(ret)


@app.get('/user/<int:user_id>')
def user_(user_id):
    # 分页信息获取
    for student in students:
        if student['id'] == user_id:
            ret = {"message": "获取数据成功", "user_info": student, 'success': True}
            return jsonify(ret)
    return jsonify({"message": "获取数据失败", "user_info": "", 'success': True})


@app.put('/user/<int:user_id>')
def user_put(user_id):
    # 分页信息获取
    for student in students:
        if student['id'] == user_id:
            print(request.json)
            student.update(request.json)
            ret = {"message": "数据修改成功", "user_info": student, 'success': True}
            return jsonify(ret)
    return jsonify({"message": "数据修改失败", "user_info": "", 'success': True})


@app.delete('/user/<int:user_id>')
def user_delete(user_id):
    # 分页信息获取
    for student in students:
        if student['id'] == user_id:
            students.remove(student)
            ret = {"message": "数据删除成功", 'success': True}
            return jsonify(ret)
    return jsonify({"message": "数据删除失败", 'success': True})


if __name__ == '__main__':
    app.run()
