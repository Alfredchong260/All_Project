## 下拉菜单

官方文档：https://v5.bootcss.com/docs/5.1/components/dropdowns/ 

+ 使用一个 class="dropdown" 的 div 包裹整个下拉框

+ 使用一个 class="dropdown-toggle" data-bs-toggle="dropdown" 的按钮作为父菜单
  + 给父菜单后设置一个下拉箭头

+ 使用一个 class="dropdown-menu" 的 ul 列表作为下拉菜单项 

  + 使用 class="dropdown-header" 的 li 作为分组的标题

  + 使用 class="driver" 的 li 作为下拉分割线

```html
<div class="dropdown">
    <button class="btn btn-secondary dropdown-toggle"
            type="button"
            id="dropdownMenuButton1"
            data-bs-toggle="dropdown"
            aria-expanded="false">
        Dropdown button
    </button>
    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
        <li><a class="dropdown-item" href="#">Action</a></li>
        <li><a class="dropdown-item" href="#">Another action</a></li>
        <!--dropdown-divider 分割线-->
        <li>
            <hr class="dropdown-divider">
        </li>
        <li><a class="dropdown-item" href="#">Something else here</a></li>
    </ul>
</div>
```

## 模态框

+ 使用方式一：通过 data 属性：在控制器元素（比如按钮或者链接）上设置属性data-toggle="modal" ，同时设置 data-target="#identifier" 或href="#identifier" 来指定要切换的特定的模态框(带有 id ="identifier" )
+ 使用方式二：通过 JavaScript：使用这种技术，可以通过简单的一行 JavaScript 来调用带有 id="identifier" 的模态框：

### 方式一

