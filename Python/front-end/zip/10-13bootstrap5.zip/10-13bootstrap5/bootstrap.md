popper 弹窗教程： https://www.jiyik.com/w/popperjs/popper-prevent-overflow 





bootstarp5 插件：

表格：https://github.com/wenzhixin/bootstrap-table 

bootstrap-select： https://github.com/snapappointments/bootstrap-select

社交icon: https://github.com/lipis/bootstrap-social



https://github.com/petk/awesome-jquery

https://github.com/js-cookie/js-cookie

https://github.com/jquery-validation/jquery-validation

https://github.com/jquery-form/form

https://github.com/kylefox/jquery-modal

https://github.com/flesler/jquery.scrollTo

https://github.com/DataTables/DataTables

https://github.com/davidstutz/bootstrap-multiselect