"""
输入两个数字（input）,相加之后打印输出
"""
# 数据类型

number1 = input('请输入第一个数字:')
print(type(number1))
number2 = input('请输入第二个数字:')
print(type(number2))
sum1 = int(number1) + int(number2)  # 字符串的拼接

print(sum1)

# 一定要注意当前操作的数据类型



