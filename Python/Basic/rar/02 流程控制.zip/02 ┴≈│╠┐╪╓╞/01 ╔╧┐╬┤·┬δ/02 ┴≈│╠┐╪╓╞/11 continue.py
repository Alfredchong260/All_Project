

i = 0
while i < 5:
    i += 1
    if i == 3:
        continue  # 结束当前循环, 执行下一次循环
    print(i)


