
"""
    and  -->   条件1 and 条件2  两个条件都成立, 返回True, 否则返回False
    or   -->   条件1 and 条件2  两个条件只要有一个满足, 那么就会返回True, 两个都不满足就返回False
    not  -->   not 条件 , 取反<根据布尔值取反>
"""

print( 5 > 4 and 5 < 4 )
print( 5 > 4 and 3 < 4 )

print(True or False)
print(False or False)

print(not True)
print(not False)