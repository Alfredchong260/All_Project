r = 4 > 2 ** 4 or True is 1 and '4' in "345"

# 指数运算: 4 > 16 or True is 1 and '4' in "345"
# 比较运算: False or True is 1 and '4' in "345"
# 身份运算: False or False and '4' in "345"
# 成员运算: False or False and True
# 逻辑运算: False and True

print(r)
