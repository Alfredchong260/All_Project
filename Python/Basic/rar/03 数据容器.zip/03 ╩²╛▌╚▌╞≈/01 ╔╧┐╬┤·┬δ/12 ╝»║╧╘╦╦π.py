

set1 = {'a', 'b', 'cc'}
set2 = {'b', 'cc', 'd'}


# & 交集 两集合相同的元素
print(set1 & set2)

# | 并集 两集合中不重复的数据
print(set1 | set2)

# 差集
print(set1 - set2)  # 集合1 比 集合2 多的


# 异或集  与交集取反的内容
print(set1 ^ set2)


#
l = [1, 2, 3, 4]  # 有序

print(tuple(l))

