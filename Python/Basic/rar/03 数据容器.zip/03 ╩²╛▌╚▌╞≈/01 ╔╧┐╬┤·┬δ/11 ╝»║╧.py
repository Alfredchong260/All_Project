set1 = {1, 1, 2, 2, 3, 3, 4, 4, 5, 5}

# {}  主要的用于数据的去重
print(set1)
print(type(set1))

# 集合（set）是一种无序的、可变的、不可重复的数据类型。
# 不能用索引取值
set1.add('a')
print(set1)


