

i = 0
if i == 0:
    pass
