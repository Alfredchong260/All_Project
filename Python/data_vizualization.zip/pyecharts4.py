from pyecharts.charts import Calendar
from snapshot_selenium import snapshot
from pyecharts.render import make_snapshot


