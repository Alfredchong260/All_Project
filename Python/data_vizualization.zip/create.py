import os
file_name = 'Lesson'
for i in range(2, 15):
    os.mkdir(file_name + '_' + str(i))
