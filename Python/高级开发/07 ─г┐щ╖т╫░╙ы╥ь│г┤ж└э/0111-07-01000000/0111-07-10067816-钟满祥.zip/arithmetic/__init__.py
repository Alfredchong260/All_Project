from .plus import add
from .divide import div
from .multiply import mul
from .decrease import sub
