"""
球球大作战

球的属性
    半径
    周长
    面积

需要实现的行为：
    大球吃小球，面积相加，返回一个新的球


r 为半径，D 为直径
面积：S=πr²; S=π(d/2）^2
周长：C=πD=2πR
"""
import math

class Ball:
    def __init__(self, radius):
        self.radius = radius
        self.pie = 3.141592654
        self.diameter = 2 * self.radius
        self.peri = self.pie * self.diameter
        self.area = self.pie * self.radius ** 2

    def update(self):
        self.diameter = 2 * self.radius
        self.peri = self.pie * self.diameter

    def eat(self, other):
        if self.area > other.area:
            self.area += other.area
            other.radius = 0
            other.update()
            return 'Area 1 > Area 2'
        else:
            other.area += self.area
            self.radius = 0
            self.update()
            return 'Area 1 < Area 2'

    def __str__(self):
        return f"<Area {self.area}>"

ball1 = Ball(3)
ball2 = Ball(5)
ball3 = Ball(2)
print(ball1)
print(ball2)
print(ball1.eat(ball2))
print(ball1.peri)
print(ball2.peri)
