print('db文件:\t', __name__)


class Person:
    pass
