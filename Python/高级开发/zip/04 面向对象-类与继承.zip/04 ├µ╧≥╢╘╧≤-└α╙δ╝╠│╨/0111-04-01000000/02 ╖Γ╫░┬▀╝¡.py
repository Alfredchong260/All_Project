""""""
import json

"""
    将基础课的学生信息管理系统中的数据操作抽象为一个类

    类名：MySqlDB
    属性：students
    方法：insert、delete、change、search、save
    
    
    1. 启动程序，加载 students.json 文件里面的数据
    2. 实现增删改查
    3. 退出系统之前保存数据
"""


# 只要操作数据就行了
class MySqlDB:

    def __init__(self):
        pass

# db = MySqlDB('students.json')
# print(db.all())
# print(db.search('李四'))
# print(db.change({'name': '李四', 'chinese': 100, 'math': 100, 'english': 100, 'total': 100}))
# print(db.search('李四'))
