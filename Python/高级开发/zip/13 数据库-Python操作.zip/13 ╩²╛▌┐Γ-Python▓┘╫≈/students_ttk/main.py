import tkinter as tk
from LoginPage import *

root = tk.Tk()
root.title('小程序')
LoginPage(root)
# MainPage(root)
root.mainloop()
