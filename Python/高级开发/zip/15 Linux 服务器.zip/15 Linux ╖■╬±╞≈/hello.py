print('hello python !')
print('hello world !')
