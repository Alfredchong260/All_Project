Ubuntu16.04版本中使用终端安装MySQL5.7：

```shell
 sudo apt-get install mysql-server
```

检查MySQL是否运行：

```shell
sudo netstat -tap | grep mysql
```


如果成功安装，我的会显示如下内容：

```shell
tcp        0      0 localhost:mysql         *:*                     LISTEN      82135/mysqld
```

PS：重启/打开/关闭MySQL的方法是：sudo service mysql restart/start/stop

在安装过程中并没有出现要我写用户名和密码的地方，完成后在终端输入mysql -u root -p之后，输入root密码，显示被静止访问。

```shell
python@ubuntu:~$ mysql -uroot -p
Enter password: 
ERROR 1045 (28000): Access denied for user 'root'@'localhost' (using password: YES)
```

原因是MySQL默认禁止使用root账户登录数据库，如果想登入mysql修改可使用root登录，则需要找到MySQL默认设置的用户与密码进行登录：

```shell
 sudo cat /etc/mysql/debian.cnf
```

在这个文件里面有着MySQL默认的用户名和用户密码， 
最重要的是：用户名默认的不是root，而是debian-sys-maint，如下所示

```shell
  1 # Automatically generated for Debian scripts. DO NOT TOUCH!
  2 [client]
  3 host     = localhost
  4 user     = debian-sys-maint
  5 password = 0gN5MHQbWSmMVyPo
  6 socket   = /var/run/mysqld/mysqld.sock
  7 [mysql_upgrade]
  8 host     = localhost
  9 user     = debian-sys-maint
 10 password = 0gN5MHQbWSmMVyPo
 11 socket   = /var/run/mysqld/mysqld.sock
```

密码会随即给一个很复杂的，这个时候，要进入MySQL的话，就是需要在终端把root更改为debian-sys-maint，如下代码

```shell
python@ubuntu:~$ mysql -u debian-sys-maint -p
Enter password: 
Welcome to the MySQL monitor.  Commands end with ; or \g.
Your MySQL connection id is 12
Server version: 5.7.25-0ubuntu0.16.04.2 (Ubuntu)

Copyright (c) 2000, 2019, Oracle and/or its affiliates. All rights reserved.

Oracle is a registered trademark of Oracle Corporation and/or its
affiliates. Other names may be trademarks of their respective
owners.

Type 'help;' or '\h' for help. Type '\c' to clear the current input statement.

mysql> 
```

这是输入文件中的密码即可成功登陆。 
当然了，这之后就要修改密码了，毕竟密码太难记。

使用grant语句赋予权限   里面的windows就是我们的连接名，可以随意更改， 123456是连接的密码 

```sql
mysql> grant all privileges on *.* to  windows@"%" identified by "123456" with grant option;
Query OK, 0 rows affected, 1 warning (0.00 sec)

-- windows@"%" 这里的%是指除了localhost以外的host，然后刷新一下就能看到我们创建的新用户

mysql> select user, host from user;
+------------------+-----------+
| user             | host      |
+------------------+-----------+
| windows          | %         |
| debian-sys-maint | localhost |
| mysql.session    | localhost |
| mysql.sys        | localhost |
| root             | localhost |
+------------------+-----------+
5 rows in set (0.00 sec)
```

重启生效

```shell
python@ubuntu:~$ sudo service mysql restart
```

