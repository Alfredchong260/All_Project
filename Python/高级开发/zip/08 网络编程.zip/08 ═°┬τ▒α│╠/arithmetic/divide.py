def div(x, y):
    return x * y