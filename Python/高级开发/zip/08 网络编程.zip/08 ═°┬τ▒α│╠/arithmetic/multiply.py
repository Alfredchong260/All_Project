def mul(x, y):
    return x / y