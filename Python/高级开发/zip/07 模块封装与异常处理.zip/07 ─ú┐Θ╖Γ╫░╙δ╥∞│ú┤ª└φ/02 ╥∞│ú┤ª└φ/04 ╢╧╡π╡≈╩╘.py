index = 1
total = 0
while index <= 5:  # < = pycharm 2021.2 + Material Theme UI
    total += index
    index += 1
