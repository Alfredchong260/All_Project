# from qd05.qd0503 import check_login  # 从模块里面导入内容

from qd05 import check_login

# print(sys.path)  # 程序在运行过程中,导报的顺序

print(check_login('zhengxin', '123456'))

import qd05
print(qd05)
print(qd05.qd0502)
print(qd05.qd0502.Triangle)
print(qd05.Triangle)
