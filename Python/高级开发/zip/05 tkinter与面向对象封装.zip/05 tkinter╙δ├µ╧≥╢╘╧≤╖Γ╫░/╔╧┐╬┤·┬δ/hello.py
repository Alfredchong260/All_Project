print('hello world !')
print('tkinter !')
