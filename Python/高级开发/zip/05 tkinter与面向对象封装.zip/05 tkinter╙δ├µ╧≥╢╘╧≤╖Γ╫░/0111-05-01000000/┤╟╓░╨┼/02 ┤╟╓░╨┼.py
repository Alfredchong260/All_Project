""""""
"""
    观看 辞职信.mp2 视频，完成页面布局及代码逻辑
    图片素材在 resignation 里面
"""
import tkinter as tk
from random import random
from tkinter import messagebox

root = tk.Tk()
root.geometry('500x300+100+100')
root['background'] = '#ffffff'
"""在这里实现具体的逻辑"""


# 关闭默认的退出事件
def on_exit():
    messagebox.showwarning(title='提示', message='此路不通')


root.protocol("WM_DELETE_WINDOW", on_exit)

root.mainloop()
