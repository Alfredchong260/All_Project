"""
    图片已经加载好了，请参考 `图片查看器.png` 实现图片查看器的逻辑
"""

import tkinter as tk
import glob

from PIL import Image, ImageTk

current_photo_no = 0

root = tk.Tk()
# 加载本地图片
photos = glob.glob('photo/*.jpg')
photos = [ImageTk.PhotoImage(Image.open(file)) for file in photos]

"""在下面实现代码"""

